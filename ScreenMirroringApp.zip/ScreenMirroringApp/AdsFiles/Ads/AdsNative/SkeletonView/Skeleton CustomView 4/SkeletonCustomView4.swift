//
//  SkeletonCustomView4.swift
//  Ai Email Writer
//
//  Created by 7SEASOL-2 on 02/05/24.
//

import UIKit

class SkeletonCustomView4: UIView {

    @IBOutlet weak var shimmerView: View!
    @IBOutlet weak var view1: View!
    @IBOutlet weak var view2: View!
    @IBOutlet weak var view3: View!
    @IBOutlet weak var view4: View!
    @IBOutlet weak var view5: View!
    @IBOutlet weak var view6: View!
    
}
