//
//  SkeletonCustomView5.swift
//  LiveCricketTV5
//
//  Created by 7SEASOL-1 on 15/06/24.
//

import UIKit

class SkeletonCustomView5: UIView {

    
    @IBOutlet weak var shimmerView: View!
    @IBOutlet weak var view1: View!
    @IBOutlet weak var view2: View!
    @IBOutlet weak var view3: View!
    @IBOutlet weak var view4: View!
    @IBOutlet weak var view5: View!
    
    
    
    

}
