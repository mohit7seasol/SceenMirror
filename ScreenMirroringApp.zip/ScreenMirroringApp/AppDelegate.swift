//
//  AppDelegate.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 15/12/25.
//

import UIKit
import IQKeyboardManagerSwift
import AWSS3
import AWSCore
import FirebaseCore
import Firebase
import FirebaseCrashlytics
import FirebasePerformance
import ConnectSDK
import CloudKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?
    let kDebugLoggingEnabled = true
    fileprivate var enableSDKLogging = true
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        Subscribe.save(true)
        appStart = true
        if !Subscribe.get() {
            initView()
        }
        setTimeZone()
//        FirebaseApp.configure()
//        Crashlytics.crashlytics().setCrashlyticsCollectionEnabled(true)
//        FirebaseApp.debugDescription()
//        Performance.sharedInstance().isInstrumentationEnabled = true
//        Performance.sharedInstance().isDataCollectionEnabled = true
//        FirebaseConfiguration.shared.setLoggerLevel(FirebaseLoggerLevel.min)
        
        return true
    }
    func applicationWillTerminate(_ application: UIApplication) {
        print("applicationWillTerminate")
        setSelectedTV(name: "")
        commonViewModel.StopCasting()
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(true)
            try session.overrideOutputAudioPort(.speaker)
        } catch {
            print("Error disconnecting AirPlay: \(error)")
        }
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }

}

extension AppDelegate {
    func setTimeZone() {
        let deviceTimeOffset =  -330 + getDeviceLocalTimeZone().secondsFromGMT() / 60
        
        print(deviceTimeOffset)
        
        let hours = deviceTimeOffset / 60
        let remainingMinutes = deviceTimeOffset % 60
        
        let formattedTime = String(format: "%02d:%02d", hours, remainingMinutes)
        Application.timeOffSet = formattedTime
        
    }
    func getDeviceLocalTimeZone() -> TimeZone {
        return TimeZone.current
    }
    func initView() {
        
        let adsModal = getAdsModal()
        
        Application.appopenId = adsModal.appopenId ?? ""
        Application.nativeId = adsModal.nativeId ?? ""
        
        delay(time: 1.5) {
            Task {
                await AppOpenAdManager.shared.loadAd()
            }
        }
        
        let credentials = AWSStaticCredentialsProvider(accessKey: ACCESS, secretKey: SECRET)
        let configuration = AWSServiceConfiguration(region: AWSRegionType.EUWest1, credentialsProvider: credentials)
        
        AWSServiceManager.default().defaultServiceConfiguration = configuration
        
        APIManager().GET_API(api: Application.getJSON, isShowLoader: true) { data in
            do {
                if let data = data {
                    let jsonDecoder = JSONDecoder()
                    let adsModal = try jsonDecoder.decode(AdsModal.self, from: data)
                    Application.appopenId = adsModal.appopenId ?? ""
                    Application.nativeId = adsModal.nativeId ?? ""
                    setAdsModal(modal: adsModal)
                }
            } catch {
            }
        }
    }
}
