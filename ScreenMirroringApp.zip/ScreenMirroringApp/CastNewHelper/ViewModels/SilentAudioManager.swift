//
//  SilentAudioManager.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import AVFoundation

final class SilentAudioManager {
    static let shared = SilentAudioManager()
    private var audioPlayer: AVAudioPlayer?
    
    private init() {}
    
    func start() {
        if audioPlayer?.isPlaying == true {
            print("Silent audio already running ✅")
            return
        }
        
        guard let url = Bundle.main.url(forResource: "silent", withExtension: "mp3") else {
            print("Silent audio file not found ⚠️")
            return
        }
        
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, options: [.mixWithOthers])
            try session.setActive(true, options: [])
            
            let player = try AVAudioPlayer(contentsOf: url)
            player.numberOfLoops = -1
            player.volume = 0.01
            player.prepareToPlay()
            player.play()
            
            audioPlayer = player
            
            print("Silent audio started ✅")
        } catch {
            print("Error starting silent audio: \(error.localizedDescription)")
        }
    }
    
    func stop() {
        guard let player = audioPlayer else {
            print("Silent audio not running, nothing to stop ⛔️")
            return
        }
        
        if player.isPlaying {
            player.stop()
        }
        audioPlayer = nil
        
        do {
            try AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
            print("Silent audio stopped ⛔️")
        } catch {
            print("Error stopping audio session: \(error.localizedDescription)")
        }
    }
}

