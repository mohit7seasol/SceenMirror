//
//  CastViewModel.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//


import GoogleCast
import MediaPlayer
import Combine

struct CastDetail{
    var titleStr : String
    var subtitleStr : String
}

class CastViewModel: NSObject, ObservableObject, GCKDiscoveryManagerListener {
    @Published var devices: [GCKDevice] = []
    @Published var selectedDevice: GCKDevice?
    @Published var isDiscovering: Bool = false
    @Published var isCastingInProgress = false
    @Published var isConnected = false

    static let shared = CastViewModel()
    var superVC : UIViewController?

    var discoveryManager: GCKDiscoveryManager?
    var castDetail: CastDetail?
    var onStartVideo: (() -> Void)?
    private var sessionCompletionHandler: ((Bool) -> Void)?
    private var pendingMediaToCast: (url: URL, mediaType: String)?
    override init() {
        super.init()
        GCKCastContext.sharedInstance().sessionManager.add(self)
        startDiscovery()
    }

    func startDiscovery() {
        isDiscovering = true

        let receiverAppID = kGCKDefaultMediaReceiverApplicationID
        let discoveryCriteria = GCKDiscoveryCriteria(applicationID: receiverAppID)
        let options = GCKCastOptions(discoveryCriteria: discoveryCriteria)
        GCKCastContext.setSharedInstanceWith(options)

        GCKLogger.sharedInstance().delegate = self

        discoveryManager = GCKCastContext.sharedInstance().discoveryManager
        discoveryManager?.add(self)
        discoveryManager?.passiveScan = true
        discoveryManager?.startDiscovery()

        DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
            self.isDiscovering = false
        }
    }

    func connectToDevice(_ device: GCKDevice,isShowPopup : Bool) {
        selectedDevice = device
        isConnected = true
        selectedTvType = .GcastTV
        setSelectedTV(name: "Gcast-\(device.friendlyName ?? "GcastTV")")
        if let sVC = self.superVC as? ListDeviceVc{
            DispatchQueue.main.async {
                sVC.tvDelegate?.setTvName(tvName: "\(device.friendlyName ?? "GcastTV")")
                sVC.showloader(isShow: false,isShowPopup: isShowPopup)
            }
        }
        setPlaceHolder(connectedTvType: .GcastTV)
        print("Connected to device: \(selectedDevice?.friendlyName ?? "Unknown")")
    }
    
    func disconnectFromDevice() {
        if let castSession = GCKCastContext.sharedInstance().sessionManager.currentCastSession {
            castSession.end(with: .stopCasting)
            selectedDevice = nil
            GCKCastContext.sharedInstance().sessionManager.remove(self)
            print("Disconnected from device")
        }
        selectedDevice = nil
        isConnected = false
    }

    func stopCastingSession() {
        if let castSession = GCKCastContext.sharedInstance().sessionManager.currentCastSession {
            castSession.end(with: .stopCasting)
            isCastingInProgress = false
            print("Disconnected from device")
        }
    }


    func isCastingSessionGoing() -> Bool {
        return GCKCastContext.sharedInstance().sessionManager.currentCastSession != nil
    }

    func setDefaultSessionOptions(for appID: String) {
        GCKCastContext.sharedInstance().sessionManager.setDefaultSessionOptions(
            ["gck_applicationID": NSString(string: appID)],
            forDeviceCategory: kGCKCastDeviceCategory
        )
    }

    func startDefaultMediaPlayerSession(with device: GCKDevice) {
        print("Starting default media session")
        setDefaultSessionOptions(for: kGCKDefaultMediaReceiverApplicationID)
        GCKCastContext.sharedInstance().sessionManager.startSession(with: device)
    }

    func startCustomReceiverSession(with device: GCKDevice) {
        setDefaultSessionOptions(for: AppStrings.kCustomReceiverAppID)
        GCKCastContext.sharedInstance().sessionManager.startSession(with: device)
    }
    
    func StopRemoteMediaCleint() {
        guard let remoteMediaClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient else {
            return
        }
        remoteMediaClient.stop()
    }
    
    func startCastSession() {
        GCKCastContext.sharedInstance().sessionManager.add(self)
        DispatchQueue.main.async {
            self.isCastingInProgress = true
            print("startCastSession: isCastingInProgress set to true")
        }

        guard let device = selectedDevice else {
            print("No device selected to start casting session.")
            return
        }
        startDefaultMediaPlayerSession(with: device)
    }

    
    func castMedia(_ url: URL, mediaType: String) {
        print("castMedia called")
        if mediaType == "video/mp4" || mediaType == "audio/m4a"{
            isSplashCasting = false
        }
        StopRemoteMediaCleint()
        pendingMediaToCast = (url, mediaType)
        onStartVideo?()
        if isCastingSessionGoing() {
            executeMediaCasting(url, mediaType: mediaType)
        } else {
            startCastSession()
        }
    }
    

    private func executeMediaCasting(_ url: URL, mediaType: String) {
        guard let remoteMediaClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient else {
            print("executeMediaCasting: No cast session found.")
            startCastSession()
            return
        }
        
        if let mediaStatus = remoteMediaClient.mediaStatus, mediaStatus.playerState == .playing {
            print("executeMediaCasting: Stopping current media before casting new media...")
            remoteMediaClient.stop()
        }
        
        print("executeMediaCasting: Casting media...")
        
        let metaData = GCKMediaMetadata()
        metaData.setString(castDetail?.titleStr ?? "\(APP_NAME)", forKey: kGCKMetadataKeyTitle)
        metaData.setString(castDetail?.subtitleStr ?? "", forKey: kGCKMetadataKeySubtitle)
        if mediaType != "image/jpeg"{
            metaData.addImage(GCKImage(url: URL(string: "https://buffer.com/library/content/images/library/wp-content/uploads/2017/09/13-Places-to-Find-Background-Music-for-Video-Cover-Image-2.jpg")!, width: 480, height: 360))
        }
        let mediaInformation = GCKMediaInformation(
            contentID: url.absoluteString,
            streamType: .buffered,
            contentType: mediaType,
            metadata: metaData,
            streamDuration: 0,
            mediaTracks: nil,
            textTrackStyle: nil,
            customData: nil
        )

        let mediaLoadOptions = GCKMediaLoadOptions()
        mediaLoadOptions.autoplay = true

        remoteMediaClient.loadMedia(mediaInformation, with: mediaLoadOptions)

        DispatchQueue.main.async {
            if isFromSplash == false{
                isFromSplash = true
//                setIsCastOne(status: true)
            }
            self.isCastingInProgress = false
            print("executeMediaCasting: isCastingInProgress set to false")
        }
    }

    func seekMedia(to time: Float) {
        guard let remoteMediaClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient else {
            return
        }
        
        let mediaSeekOptions = GCKMediaSeekOptions()
        mediaSeekOptions.interval = TimeInterval(time)
        mediaSeekOptions.resumeState = .unchanged
        remoteMediaClient.seek(with: mediaSeekOptions)
    }

    // MARK: - GCKDiscoveryManagerListener

    func didUpdateDeviceList() {
        guard let discoveryManager = discoveryManager else { return }
        DispatchQueue.main.async {
            self.devices = (0..<discoveryManager.deviceCount).compactMap { discoveryManager.device(at: $0) }
            print("Google Cast TV : \(self.devices)")
           
        }
    }

    func didAddDevice(_ device: GCKDevice) {
        DispatchQueue.main.async {
            if !self.devices.contains(device) {
                self.devices.append(device)
                print("Google Cast TV : \(self.devices)")
                
            }
        }
    }

    func didRemoveDevice(_ device: GCKDevice) {
        DispatchQueue.main.async {
            self.devices.removeAll { $0 == device }
            print("Google Cast TV : \(self.devices)")
        }
    }
    
    private func attemptCastingPendingMedia(_ pendingMedia: (url: URL, mediaType: String), retries: Int, delay: TimeInterval) {
        guard retries > 0 else {
            print("executeMediaCasting: failed after retries, remoteMediaClient not ready ❌")
            return
        }
        
        if let remoteMediaClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient {
            print("executeMediaCasting: remoteMediaClient ready, casting ✅")
            self.executeMediaCasting(pendingMedia.url, mediaType: pendingMedia.mediaType)
            self.pendingMediaToCast = nil
        } else {
            print("executeMediaCasting: remoteMediaClient not ready, retrying...")
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                self.attemptCastingPendingMedia(pendingMedia, retries: retries - 1, delay: delay)
            }
        }
    }

}

extension CastViewModel: GCKLoggerDelegate {
    func logMessage(_ message: String, fromFunction function: String, location: String) {
        print("\(location): \(function) - \(message)")
    }
}


extension CastViewModel: GCKSessionManagerListener {
    func sessionManager(_ sessionManager: GCKSessionManager, didStart session: GCKSession) {
        print("sessionManager: didStart session")
        
        self.isCastingInProgress = false
        
        guard let pendingMedia = self.pendingMediaToCast else {
            print("sessionManager: no pending media to cast")
            return
        }
        
        attemptCastingPendingMedia(pendingMedia, retries: 3, delay: 1.0)
    }

    func sessionManager(_ sessionManager: GCKSessionManager, didFailToStart session: GCKSession, withError error: Error) {
        print("Failed to start session: \(error.localizedDescription)")
    }

    func sessionManager(_ sessionManager: GCKSessionManager, didEnd session: GCKSession, withError error: Error?) {
        print("Session ended: \(error?.localizedDescription ?? "No error")")
        self.isCastingInProgress = false
    }
}
