//
//  CommonViewModel.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//


import Foundation
import GoogleCast
import Combine
import AVFoundation
import MediaPlayer

class CommonViewModel: ObservableObject {
    @Published var castViewModel: CastViewModel
    @Published var connectSDKDiscoveryModel: ConnectSDKDiscoveryModel
    
    @Published var connectedTvType: TVType?
    @Published var tvName: String?
    
//    @Published var selectedQuality = 0
    @Published var isLoading = true
    @Published var isUploading = false
    
    @Published var isPlaying: Bool = false
    @Published var duration: Float = 0.0
    @Published var playbackPosition: Float = 0.0
    @Published var volume: Float = 0.5
    @Published var isSeeking = false
    @Published var playbackTimer: Timer?
    
    private var cancellables = Set<AnyCancellable>()
    let volumeController = GCKUIDeviceVolumeController.init()
   
    
    init() {
        self.castViewModel = CastViewModel()
        self.connectSDKDiscoveryModel = ConnectSDKDiscoveryModel()
        
        observeAllTvManagersChanges()
    }
    
    private func observeAllTvManagersChanges() {
        castViewModel.objectWillChange
            .sink { [weak self] _ in
                DispatchQueue.main.async {
                    self?.objectWillChange.send()
                }
            }
            .store(in: &cancellables)
        
        
        connectSDKDiscoveryModel.objectWillChange
            .sink { [weak self] _ in
                DispatchQueue.main.async {
                    self?.objectWillChange.send()
                }
            }
            .store(in: &cancellables)
    }

    
    func setConnectedTv(tvType: TVType) {
        self.connectedTvType = tvType
        configureConnection(for: tvType)
    }
    

    func disconnectTv() {
        self.connectedTvType = nil
        tvName = nil
        
        castViewModel.disconnectFromDevice()
        connectSDKDiscoveryModel.disconnectFromTV()
    }
    

    func getConnectedTvType() -> TVType? {
        if castViewModel.selectedDevice != nil {
            return .GcastTV
        } else if connectSDKDiscoveryModel.isConnectedToLG {
            return .LGTV
        }
        return nil
    }

    
    var isDeviceConnected: Bool {
        return
            castViewModel.selectedDevice != nil ||
            connectSDKDiscoveryModel.isConnectedToLG != false
    }
    
    
    private func configureConnection(for tvType: TVType) {
        switch tvType {
        case .GcastTV:
            connectedTvType = .GcastTV
        case .LGTV:
            connectedTvType = .LGTV
        case .AirPlay:
            break
        case .noneTV:
            break
        }
    }
    
    
    func StopCasting() {
        if connectedTvType == .GcastTV {
            castViewModel.stopCastingSession()
        } else if connectedTvType == .LGTV {
            connectSDKDiscoveryModel.stopMediaCasting()
        }
    }
    
    
    // MARK: - Start Playback
    func startPlaybackUpdates() {
        playbackTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            guard !self.isSeeking else { return }
            self.updatePlayback()
        }
    }
    
    
    // MARK: - Stop Playback
    func stopPlaybackUpdates() {
        playbackTimer?.invalidate()
        playbackTimer = nil
    }
    
    func checkAirPlayStatus() -> (String,Bool){
        let audioSession = AVAudioSession.sharedInstance()
        let currentRoute = audioSession.currentRoute
        for output in currentRoute.outputs {
            if output.portType == .airPlay {
                selectedTvType = .AirPlay
                return (output.portName,true)
            }else{
                
            }
        }
        return ("",false)
    }
    
    // MARK: - Update Playback
    func updatePlayback() {
        if castViewModel.selectedDevice != nil {
            guard let remoteMediaClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient else {
                return
            }
        
            if let mediaStatus = remoteMediaClient.mediaStatus {
                self.isPlaying = mediaStatus.playerState == .playing
                let newTime = Float(mediaStatus.streamPosition)
                if !isSeeking {
                    self.playbackPosition = newTime
                }
                self.playbackPosition = Float(remoteMediaClient.approximateStreamPosition())
                self.duration = Float(mediaStatus.mediaInformation?.streamDuration ?? 0)
            }
        } else if connectSDKDiscoveryModel.selectedLGDevice != nil {
            connectSDKDiscoveryModel.getCurrentMediaPosition(completion: { position in
                if let position = position {
                    self.playbackPosition = Float(position)
                }
            })
            
            connectSDKDiscoveryModel.getMediaDuration(completion: { duration in
                if let duration = duration {
                    self.duration = Float(duration)
                }
            })

            connectSDKDiscoveryModel.isMediaPlaying { isPlaying in
                if isPlaying {
                    self.isPlaying = isPlaying
                }
            }
        }
    }

    func IPTVCast(mediaUrl: URL, title: String, des: String){
//        if isScreenMirroringActive() {
//          return
//        }
        if getConnectedTvType() == .GcastTV {
          CastMedia(url: mediaUrl, mediaType: "video/mp4", imgHei: 1024, imgWid: 1024)
          //      compressAndUploadImage(from: mediaUrl, mediaType: "video/mp4", title: title, des: "", imgHei: 1024, imgWid: 1024, selectedQuality: 2)
        } else {
          connectSDKDiscoveryModel.sendMediaToLGTVWeb(mediaUrl: mediaUrl,mimeType: "video/mp4")
        }
      }
    
    // MARK: - Seek Media
   func seek(to time: Float) {
        if getConnectedTvType() == .GcastTV {
            castViewModel.seekMedia(to: time)
        } else if connectSDKDiscoveryModel.selectedLGDevice != nil {
            connectSDKDiscoveryModel.seekMedia(to: TimeInterval(time))
        }
        
        isSeeking = false
    }
    
    
    // MARK: - Set Media Volume
    func setVolume(_ volume: Float) {
        if castViewModel.selectedDevice != nil {
            volumeController.setVolume(volume)
        }
    }
    
    
    // MARK: - Formate SeekBar Timer
    func formatTime(_ time: Float) -> String {
        guard !time.isNaN, time.isFinite, time >= 0 else { return "00:00" }

        let minutes = Int(time) / 60
        let seconds = Int(time) % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    
    // MARK: - Toggle Pause & Resume
    func togglePauseResume() {
        if castViewModel.selectedDevice != nil {
            guard let remoteMediaClient = GCKCastContext.sharedInstance().sessionManager.currentCastSession?.remoteMediaClient else {
                return
            }
            if isPlaying {
                isPlaying = false
                remoteMediaClient.pause()
            } else {
                isPlaying = true
                remoteMediaClient.play()
            }
        } else if connectSDKDiscoveryModel.selectedLGDevice != nil {
            if isPlaying{
                isPlaying = false
                connectSDKDiscoveryModel.pauseMedia()
            } else {
                isPlaying = true
                connectSDKDiscoveryModel.playMedia()
            }
        }
    }
    
    // MARK: - Cast Media
    func CastMedia(url: URL, mediaType: String, imgHei : Int, imgWid : Int) {
        switch getConnectedTvType() {
        case .GcastTV:
            castViewModel.castMedia(url, mediaType: mediaType)
        case .LGTV:
            connectSDKDiscoveryModel.sendMediaToLGTV(mediaUrl: url, mimeType: mediaType,imgHei: imgHei, imgWid: imgWid)
        case .AirPlay:
            print("AirPlay")
        case .noneTV:
            print("noneTV")
        case .none:
            print("none")
        }
    }
    
    
    func stopRemoteMediaClient() {
        if getConnectedTvType() == .GcastTV {
            castViewModel.StopRemoteMediaCleint()
        }
    }
    
    
    // MARK: - Stop Casting Media
    func stopMediaCasting() {
        switch getConnectedTvType() {
        case .GcastTV:
            castViewModel.stopCastingSession()
        case .LGTV:
            connectSDKDiscoveryModel.stopMediaCasting()
        case .AirPlay:
            print("AirPlay")
        case .noneTV:
            print("noneTV")
        case .none:
            print("none")
        }
       
        isPlaying = false
        stopPlaybackUpdates()
    }
    
    func resetMediaControl() {
        duration = 0.0
        playbackPosition = 0.0
        volume = 0.0
    }
    
    // MARK: - Photo casting
    func compressAndUploadImage(from url: URL, mediaType: String, imgHei : Int, imgWid : Int,selectedQuality : Int) {
        guard let image = UIImage(contentsOfFile: url.path) else {
            print("Unable to load image from URL")
            return
        }

        let targetSize: CGSize
        switch selectedQuality {
        case 0:
            targetSize = CGSize(width: 1280, height: 720)
        case 1:
            targetSize = CGSize(width: 1920, height: 1080)
        case 2:
            targetSize = CGSize(width: 3840, height: 2160)
        default:
            targetSize = CGSize(width: 1280, height: 720)
        }

        let compressionQuality: CGFloat
        switch selectedQuality {
        case 0:
            compressionQuality = 0.2
        case 1:
            compressionQuality = 0.6
        case 2:
            compressionQuality = 1.0
        default:
            compressionQuality = 0.6
        }
        
        let resizedImage = resizeImage(image: image, targetSize: targetSize)
        if let compressedImageData = resizedImage.jpegData(compressionQuality: compressionQuality) {
            let compressedURL = FileManager.default.temporaryDirectory.appendingPathComponent("compressed_image.jpg")
            do {
                try compressedImageData.write(to: compressedURL)
                    uploadFile(compressedURL, mediaType: mediaType,imgHei: imgHei, imgWid: imgWid)
            } catch {
                print("Error writing compressed image to temporary URL: \(error)")
            }
        } else {
            print("Failed to compress image")
        }
    }
    
    // MARK: - Video casting
    func compressAndUploadVideo(_ url: URL,selectedQuality : Int) {
        let asset = AVAsset(url: url)
        let presetName: String

        switch selectedQuality {
        case 0:
            presetName = AVAssetExportPreset1280x720
        case 1:
            presetName = AVAssetExportPreset1920x1080
        case 2:
            presetName = AVAssetExportPreset3840x2160
        default:
            presetName = AVAssetExportPreset1280x720
        }

        guard let exportSession = AVAssetExportSession(asset: asset, presetName: presetName) else {
            print("Failed to create export session")
            return
        }

        let compressedURL = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent(UUID().uuidString)
            .appendingPathExtension("mp4")
        
        exportSession.outputURL = compressedURL
        exportSession.outputFileType = .mp4

        DispatchQueue.main.async {
            self.isUploading = true
        }

        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                switch exportSession.status {
                case .completed:
                    print("Video compressed successfully")
                    self.uploadFile(compressedURL, mediaType: "video/mp4",imgHei: 1024, imgWid: 1024)
                case .failed:
                    self.isUploading = false
                    if let error = exportSession.error {
                        print("Video compression failed: \(error.localizedDescription)")
                    }
                case .cancelled:
                    self.isUploading = false
                    print("Video compression cancelled")
                default:
                    break
                }
            }
        }
    }

    // MARK: - Audio casting
    func exportAndUploadMusic(track: MPMediaItem) {
        self.castViewModel.castDetail = CastDetail(titleStr: track.title ?? "\(APP_NAME)", subtitleStr: track.artist ?? "")
        guard let url = track.value(forProperty: MPMediaItemPropertyAssetURL) as? URL else {
            print("No URL for selected track.")
            return
        }
        
        let uniqueFileName = UUID().uuidString + ".m4a"
        let temporaryDirectory = FileManager.default.temporaryDirectory
        let temporaryFileURL = temporaryDirectory.appendingPathComponent(uniqueFileName)
        
        if FileManager.default.fileExists(atPath: temporaryFileURL.path) {
            do {
                try FileManager.default.removeItem(at: temporaryFileURL)
            } catch {
                print("Failed to remove existing file: \(error)")
            }
        }
        
        exportMusic(from: url, to: temporaryFileURL) { success in
            if success {
                DispatchQueue.main.async {
                    self.uploadFile(temporaryFileURL, mediaType: "audio/m4a", imgHei: 1024, imgWid: 1024)
                }
            } else {
                print("Failed to export music")
            }
        }
    }

    // MARK: - Audio casting function
    private func exportMusic(from url: URL, to destinationURL: URL, completion: @escaping (Bool) -> Void) {
        let asset = AVAsset(url: url)
        guard let assetExportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            print("Failed to create export session")
            completion(false)
            return
        }
        
        assetExportSession.outputURL = destinationURL
        assetExportSession.outputFileType = .m4a
        
        assetExportSession.exportAsynchronously {
            switch assetExportSession.status {
            case .completed:
                completion(true)
            case .failed:
                print("Failed to export asset: \(String(describing: assetExportSession.error))")
                completion(false)
            default:
                print("Export session status: \(assetExportSession.status)")
                completion(false)
            }
        }
    }
    
    // MARK: - Photo resizing to the quality selected
    func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size

        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height

        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio, height: size.height * widthRatio)
        }

        let rect = CGRect(origin: .zero, size: newSize)

        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
    
    // MARK: - upload to local server and then serve the tv
    func uploadFile(_ url: URL, mediaType: String, imgHei : Int, imgWid : Int) {
        guard var serverUrl = CastingServer.shared.serverURL else {
            print("Invalid server URL")
//            uploadFile(url, mediaType: mediaType)
            DispatchQueue.main.async { self.isUploading = false }
            return
        }

        serverUrl.appendPathComponent("upload")

        var request = URLRequest(url: serverUrl)
        request.httpMethod = "POST"
        request.setValue(mediaType, forHTTPHeaderField: "Content-Type")
        DispatchQueue.main.async {
            do {
                let fileData = try Data(contentsOf: url)
                
                // Ensure UI update
                DispatchQueue.main.async { self.isUploading = true }
                
                let task = URLSession.shared.uploadTask(with: request, from: fileData) { data, response, error in
                    DispatchQueue.main.async { self.isUploading = false }
                    
                    if let error = error {
                        print("Upload error: \(error)")
                        return
                    }
                    
                    guard
                        let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200,
                        let data = data,
                        let responseUrl = String(data: data, encoding: .utf8),
                        let mediaUrl = URL(string: responseUrl)
                    else {
                        print("Invalid response")
                        return
                    }
                    
                    print("Media uploaded to: \(mediaUrl)")
                    DispatchQueue.main.async {
                        if self.isDeviceConnected {
                            self.CastMedia(url: mediaUrl, mediaType: mediaType,imgHei: imgHei, imgWid: imgWid)
                        }
                    }
                }
                
                task.resume()
            } catch {
                print("Error reading file data: \(error)")
                DispatchQueue.main.async { self.isUploading = false }
            }
        }
    }
}
