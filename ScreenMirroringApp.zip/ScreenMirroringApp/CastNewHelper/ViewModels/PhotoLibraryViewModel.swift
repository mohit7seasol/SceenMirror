//
//  PhotoLibraryViewModel.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//


import SwiftUI
import Photos
import Combine


class PhotoLibraryViewModel: ObservableObject {
    @Published var photoAssets: [PHAsset] = []
    @Published var videoAssets: [PHAsset] = []
    @Published var selectedIndex: Int = 0
    
    func requestAuthorizationAndFetchAllAssets(completion: @escaping (Bool) -> Void) {
        PHPhotoLibrary.requestAuthorization { status in
            DispatchQueue.main.async {
                if status == .authorized || status == .limited {
                    self.fetchAllPhotoAssets()
                    self.fetchAllVideoAssets()
                    completion(true)
                } else {
                    print("Photo Library access denied")
                    completion(false)
                }
            }
        }
    }

    func fetchAllPhotoAssets() {
        let fetchOptions = PHFetchOptions()
        fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        fetchOptions.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.image.rawValue)
        
        let allPhotoAssets = PHAsset.fetchAssets(with: fetchOptions)
        var photos: [PHAsset] = []
        allPhotoAssets.enumerateObjects { (asset, _, _) in
            photos.append(asset)
        }

        DispatchQueue.main.async {
            self.photoAssets = photos
        }
    }

    func fetchAllVideoAssets() {
        let fetchOptions = PHFetchOptions()
        fetchOptions.sortDescriptors = [NSSortDescriptor(key: "creationDate", ascending: false)]
        fetchOptions.predicate = NSPredicate(format: "mediaType == %d", PHAssetMediaType.video.rawValue)
        
        let allVideoAssets = PHAsset.fetchAssets(with: fetchOptions)
        var videos: [PHAsset] = []
        allVideoAssets.enumerateObjects { (asset, _, _) in
            videos.append(asset)
        }

        DispatchQueue.main.async {
            self.videoAssets = videos
        }
    }
}

extension PHAsset {
    func getMediaFileURL(completion: @escaping (URL?) -> Void) {
        let resources = PHAssetResource.assetResources(for: self)
        guard let resource = resources.first else {
            completion(nil)
            return
        }

        let ext = (resource.uniformTypeIdentifier as NSString).pathExtension
        let fileName = resource.originalFilename.isEmpty ? UUID().uuidString + "." + ext : resource.originalFilename
        
        let tempURL = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent(fileName)

        try? FileManager.default.removeItem(at: tempURL)

        PHAssetResourceManager.default().writeData(for: resource, toFile: tempURL, options: nil) { error in
            if let error = error {
                print("Error exporting asset: \(error)")
                completion(nil)
            } else {
                completion(tempURL)
            }
        }
    }
}

extension PHAsset: Identifiable {
    public var id: String { localIdentifier }
}
