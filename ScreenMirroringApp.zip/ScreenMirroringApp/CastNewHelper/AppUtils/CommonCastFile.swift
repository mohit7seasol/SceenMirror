//
//  CommonCastFile.swift
//  ScreenMirroringApp
//
//   Created by DREAMWORLD on 17/12/25.
//

import Foundation
import UIKit
import AVFAudio
import Photos
import MediaPlayer
import GoogleCast


var isCastType : RecentTabType = .none
enum RecentTabType {
    case castImages
    case casVideo
    case castMusic
    case castIPTV
    case castYTvideo
    case none
}

var recentImageThumb = UIImage()
var recentTYThumb = String()
var castAssetName = String()
var photoArray = [PHAsset]()
var publicVideoAsset = PHAsset()
var publicMusicAsset = MPMediaItem()
var castAssetURL = String()
var recentPlayPause = Bool()
var selectedPhotoCastIndex = Int()

func clearRecentData(){
    isCastType = .none
    recentImageThumb = UIImage()
    recentTYThumb = String()
    castAssetName = String()
    photoArray = [PHAsset]()
    publicVideoAsset = PHAsset()
    publicMusicAsset = MPMediaItem()
    castAssetURL = String()
    recentPlayPause = Bool()
    selectedPhotoCastIndex = -1
}

func updateConnectionUI() -> String{
    let selectedDevice = getSelectedTV()
    if selectedDevice.contains("Gcast"){
        selectedTvType = .GcastTV
        return "\(getSelectedTV().replacingOccurrences(of: "Gcast-", with: ""))"
    }else if selectedDevice.contains("Airplay") && checkAirPlayStatus().1{
        selectedTvType = .AirPlay
        return "\(checkAirPlayStatus().0)"
    }else if selectedDevice.contains("LG"){
        selectedTvType = .LGTV
        return "\(getSelectedTV().replacingOccurrences(of: "LG-", with: ""))"
    }else {
        setSelectedTV(name: "")
        selectedTvType = .noneTV
        return "Tap to Connect".localized()
    }
}

func checkAirPlayStatus() -> (String,Bool){
    let audioSession = AVAudioSession.sharedInstance()
    let currentRoute = audioSession.currentRoute
    for output in currentRoute.outputs {
        if output.portType == .airPlay {
            selectedTvType = .AirPlay
            return (output.portName,true)
        }else{
            
        }
    }
    return ("",false)
}

var isFromSplash : Bool = false
var isSplashCasting : Bool = false

func setPlaceHolder(connectedTvType: TVType){
    if isSplashCasting == false{
        isFromSplash = true
        isSplashCasting = true
        if connectedTvType == .GcastTV{
            commonViewModel.CastMedia(url: URL(string: "https://7seasol-application.s3.ap-south-1.amazonaws.com/Smart+View/vs_screen.png" /* "https://firebasestorage.googleapis.com/v0/b/test-a4397.appspot.com/o/new_banner.png?alt=media&token=daf32152-8353-40c2-9a6c-f959c669f0c1" */)!, mediaType: "image/jpeg",imgHei: 4096, imgWid: 2280)
        }else if connectedTvType == .LGTV{
            //        commonViewModel.CastMedia(url: URL(string: "http://d2is1ss4hhk4uk.cloudfront.net/Screen+Cast/Connection+TV+Banner.png")!, mediaType: "image/jpeg")
            guard let asset = UIImage(named: "new_banner") else { return }
            if let imageData = asset.jpegData(compressionQuality: 1.0) {
                let tempDirectory = FileManager.default.temporaryDirectory
                let fileName = "Splash" + ".jpg"
                let fileURL = tempDirectory.appendingPathComponent(fileName)
                do {
                    try imageData.write(to: fileURL)
                    print("✅ Image saved temporarily at: \(fileURL)")
                    commonViewModel.compressAndUploadImage(from: fileURL, mediaType: "image/jpeg",imgHei: 4096, imgWid: 2280, selectedQuality: 2)
                } catch {
                    print("❌ Failed to save image to temp file: \(error)")
                }
            }
        }
    }
}
