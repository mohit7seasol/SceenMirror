//
//  Enums.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import Foundation
import ConnectSDK
import GoogleCast
import Photos

//enum TVType {
//    case android
//    case lg
//}

var ConnectableLGDevice: ConnectableDevice?
var lgdiscoveryManager: DiscoveryManager?
var discoveredDevices: [ConnectableDevice] = []
var discoveredAirplayDevices: [ConnectableDevice] = []

enum TVType {
    case GcastTV
    case LGTV
    case AirPlay
    case noneTV
}
var selectedTvType : TVType = .noneTV
var selectedTV : TVType = .noneTV

enum DeviceType {
    case lg(ConnectableDevice)
    case cast(GCKDevice)
    
    var name: String {
        switch self {
        case .lg(let device): return device.friendlyName ?? "Unknown LG TV"
        case .cast(let device): return device.friendlyName ?? "Unknown Android TV"
        }
    }
    
    var id: String {
        switch self {
        case .lg(let device): return device.address ?? UUID().uuidString
        case .cast(let device): return device.deviceID
        }
    }
}
