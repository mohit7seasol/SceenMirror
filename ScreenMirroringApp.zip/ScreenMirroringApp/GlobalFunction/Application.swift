import Foundation
import UIKit
//import Nuke

/// Application
struct Application {
    
    /// Privacy & Terms
    static let privacyPolicy  =  "https://mmdfj.blogspot.com/2024/05/privacy.html"
    static let termsOfUse     =  "https://mmdfj.blogspot.com/2024/05/terms.html"
    static let eula           =  "https://mmdfj.blogspot.com/2024/05/eula.html"
    static let REVIEW_LINK    =  "https://itunes.apple.com/in/app/id\(APP_ID)?mt=8"
    
    /// General flags
    static let isDevelopmentMode = true
    static let debug: Bool = true
    static let enableTestPremium = false    //To enable for testing set true
    static let hideBanerAdIfNotAvailable = true
    
    static let iTunesAppId   =  "com.casttoscreen.castplay"
    static let appStoreLink = "https://apps.apple.com/app/id\(APP_ID)"
    static let appBundleID  = "com.casttoscreen.castplay"
    static let developerAppsLink = ""
    
    static var timeOffSet = ""
    
    static var APPNAME = "Screen Mirroring"
    static var APP_ID = "6499521218"
    static var instaAPI = ""
    
    static var addButtonColor = ""
    static var bannerId = ""
    static var nativeId = ""
    static var small_native = ""
    static var nativeId2 = ""
    static var interstialId = ""
    static var interstialId2 = ""
    static var appopenId = ""
    static var rewardId = ""
    static var SM_IAP_ProductID = ""
    
    static var adsCount = 0
    static var adsPlus = 0
    static var adsCountNative = 0
    static var adsPlusNative = 0
    
    static var adsFramDownCount = 0
    static var adsFramShareCount = 0
    static var addImageDownCount = 0
    static var addImageShareCount = 0
    static var addTranslateCount = 0
    static let SERVER_ERROR = "Something went wrong please try agin sometime."
    static var isInterShow:Bool = false
    static var fromChannel:Bool = false
    static var firstTime:Bool = false
    static var interFaild:Bool = false
    static var IPAURL:String?
    
    static var isConnected :Bool = false
    static var TVname:String?
    static var secondTime:Bool = false
    
    static var openPremium:Bool = false
    static var showRate:Bool = false

    static var playNum = 0
    
    static var showint = 0
    static var loadint = 0
    static var sessionId = ""
    static var appopenClose:Bool = false
    static var daysDiffrent = 0
    
    static var grated: Bool = false
    static var installDate: String?

    //live json
//    static let getJSON : String = "https://7seasol-application.s3.amazonaws.com/admin_prod/pbz-pnfggbfperra-pnfgcynl.json"

//    test json
    static let getJSON : String = "https://7seasol-application.s3.amazonaws.com/admin_prod/grfg.json"
    
    ///In app purchase
    static let enableSandboxInApp = false
    static let appShrSec = ""
    
    static let GOOGLE_API_KEY   =   ""
    static let googleClientId = ""
    static let defaultIntervalToRemindAgo = 30
    static let viewTabBottomInsertHeightIphone: CGFloat = 130
    static let viewTabBottomInsertHeightIpad: CGFloat = 200
    
    /// Application Mode
    static let mode = Mode.sendbox
    
    /// Application in production or sendbox
    enum Mode {
        case sendbox
        case production
    }
    
    struct Device {
        static let version = UIDevice.current.systemVersion
    }
    
    //    struct CountryCode {
    //        static let code = isDevelopmentMode ? "+65" : "+65"
    //    }
}

extension Notification.Name {

    static let startListClose = Notification.Name("startListClose")
   
    static let splashOpenClose = Notification.Name("splashOpenClose")
    static let splashOpenNill = Notification.Name("splashOpenNill")
    static let closeInter = Notification.Name("closeInter")
    
    static let step2Next = Notification.Name("step2Next")
    static let step3Next = Notification.Name("step3Next")
    static let step4Next = Notification.Name("step4Next")
    static let step5Next = Notification.Name("step5Next")

}

