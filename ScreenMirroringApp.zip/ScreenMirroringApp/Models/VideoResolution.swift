//
//  VideoResolution.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 13/01/26.
//

import Foundation
import UIKit

class VideoResolution: NSObject {

  var id = String()
  var videoName =  String()
  var videoURL = String()
  var videothumImage  = String()
  var videoAuthor = String()
  var videoResolution = String()
  
  override init() {
    
  }
  
  init(id:String,videoName:String,videoURL:String,videothumImage:String,videoAuthor:String,videoResolution:String) {
    self.id = id
    self.videoName = videoName
    self.videoURL = videoURL
    self.videothumImage = videothumImage
    self.videoAuthor = videoAuthor
    self.videoResolution = videoResolution
  }
}
