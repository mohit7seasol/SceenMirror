//
//  LoadingVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 15/12/25.
//

import UIKit
import Lottie
import AWSCore

class LoadingVC: UIViewController {

    @IBOutlet weak var lottieAnimatedView: UIView!
    @IBOutlet weak var screenLabel: UILabel!
    @IBOutlet weak var mirroringLabel: UILabel!
    
    var lottieFileName = "Splash Loading"
    private var animationView: LottieAnimationView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startAnimation()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopLottieAnimation()
    }
    
    func setUpUI() {
        setLoca()
        setupAnimationView()
    }
    
    func setLoca() {
        self.screenLabel.text = "Screen".localized(LocalizationService.shared.language)
        self.mirroringLabel.text = "Mirroring".localized(LocalizationService.shared.language)
    }
    
    private func setupAnimationView() {
        // Initialize Lottie animation view
        animationView = LottieAnimationView(name: lottieFileName)
        animationView?.frame = lottieAnimatedView.bounds
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.animationSpeed = 1.0
        
        if let animationView = animationView {
            lottieAnimatedView.addSubview(animationView)
            
            // Add constraints to fill the parent view
            animationView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                animationView.topAnchor.constraint(equalTo: lottieAnimatedView.topAnchor),
                animationView.bottomAnchor.constraint(equalTo: lottieAnimatedView.bottomAnchor),
                animationView.leadingAnchor.constraint(equalTo: lottieAnimatedView.leadingAnchor),
                animationView.trailingAnchor.constraint(equalTo: lottieAnimatedView.trailingAnchor)
            ])
        }
    }
    
    func startAnimation() {
        animationView?.play()
        fetchRemoteConfig()
    }
    
    private func stopLottieAnimation() {
        animationView?.stop()
    }
    
    func fetchRemoteConfig() {
        NetworkManager.shared.fetchRemoteConfig(from: self) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let json):
                    if let json = json as? [String: Any] {
                        self.processRemoteConfig(json)
                    }
                case .failure(let error):
                    print("❌ Failed to fetch config:", error.localizedDescription)
                    self.fallbackNavigation()
                }
            }
        }
    }
    
    private func processRemoteConfig(_ jsonDict: [String: Any]) {
        // Process your remote config data
        bannerId = (jsonDict["bannerId"] as AnyObject).stringValue ?? ""
        nativeId = (jsonDict["nativeId"] as AnyObject).stringValue ?? ""
        interstialId = (jsonDict["interstialId"] as AnyObject).stringValue ?? ""
        appopenId = (jsonDict["appopenId"] as AnyObject).stringValue ?? ""
        rewardId = (jsonDict["rewardId"] as AnyObject).stringValue ?? ""
        
        addButtonColor = (jsonDict["addButtonColor"] as AnyObject).stringValue ?? "#7462FF"
        let customInterstial = (jsonDict["customInterstial"] as AnyObject).intValue ?? 0
        
        adsCount = (jsonDict["afterClick"] as AnyObject).intValue ?? 4
        adsPlus = customInterstial == 0 ? adsCount - 1 : adsCount
        
        let extraFields = (jsonDict["extraFields"] as AnyObject)
        smallNativeBannerId = (extraFields["small_native"] as AnyObject).stringValue ?? ""
        
        isIAPON = (extraFields["plan"] as AnyObject).stringValue ?? ""
        IAPRequiredForTrailor = (extraFields["play"] as AnyObject).stringValue ?? ""
        prefixUrl = (extraFields["appjson"] as AnyObject).stringValue ?? ""
        NewsAPI = (extraFields["story"] as AnyObject).stringValue ?? ""
        
        // Stop animation and navigate
        self.stopLottieAnimation()
        self.navigateBasedOnStatus()
    }
    
    private func fallbackNavigation() {
        HelperManager.setupInitialLanguage()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            self.stopLottieAnimation()
            self.navigateBasedOnStatus()
        }
    }
    
    private func navigateBasedOnStatus() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let sceneWindow = sceneDelegate.window else { return }

        // ✅ Prevent white flash
        sceneWindow.backgroundColor = .black
        sceneWindow.subviews.forEach { $0.removeFromSuperview() }

        let initialVC: UIViewController

        if !AppStorage.contains(UserDefaultKeys.selectedLanguage) {

            initialVC = UIStoryboard(name: StoryboardName.language, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.languageVC)

        } else if !(AppStorage.get(forKey: UserDefaultKeys.hasLaunchedBefore) ?? false) {

            initialVC = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.o1VC)

            AppStorage.set(true, forKey: UserDefaultKeys.hasLaunchedBefore)

        } else {

            initialVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.homeVC)
        }

        // ✅ IMPORTANT: No NavigationController
        sceneWindow.rootViewController = initialVC
        sceneWindow.makeKeyAndVisible()

        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.window = sceneWindow
        }
    }
}
