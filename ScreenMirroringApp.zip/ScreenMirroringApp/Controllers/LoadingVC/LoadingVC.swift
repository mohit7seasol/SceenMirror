//
//  LoadingVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 15/12/25.
//

import UIKit
import Lottie
import AWSCore

class LoadingVC: UIViewController {

    @IBOutlet weak var lottieAnimatedView: UIView!
    @IBOutlet weak var screenLabel: UILabel!
    @IBOutlet weak var mirroringLabel: UILabel!
    
    var lottieFileName = "Splash Loading"
    private var animationView: LottieAnimationView?
    
    // Dispatch group to track all API calls
    private let apiDispatchGroup = DispatchGroup()
    private var remoteConfigSuccess = false
    private var countryDataSuccess = false
    private var categoryDataSuccess = false
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        startAnimation()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopLottieAnimation()
    }
    
    // MARK: - UI Setup
    func setUpUI() {
        setLoca()
        setupAnimationView()
    }
    
    func setLoca() {
        self.screenLabel.text = "Screen".localized(LocalizationService.shared.language)
        self.mirroringLabel.text = "Mirroring".localized(LocalizationService.shared.language)
    }
    
    private func setupAnimationView() {
        animationView = LottieAnimationView(name: lottieFileName)
        animationView?.frame = lottieAnimatedView.bounds
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.animationSpeed = 1.0
        
        if let animationView = animationView {
            lottieAnimatedView.addSubview(animationView)
            
            animationView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                animationView.topAnchor.constraint(equalTo: lottieAnimatedView.topAnchor),
                animationView.bottomAnchor.constraint(equalTo: lottieAnimatedView.bottomAnchor),
                animationView.leadingAnchor.constraint(equalTo: lottieAnimatedView.leadingAnchor),
                animationView.trailingAnchor.constraint(equalTo: lottieAnimatedView.trailingAnchor)
            ])
        }
    }
    
    func startAnimation() {
        animationView?.play()
        // Start all API calls with dispatch group
        startAllAPICalls()
    }
    
    private func stopLottieAnimation() {
        animationView?.stop()
    }
    
    // MARK: - API Calls with Dispatch Group
    private func startAllAPICalls() {
        print("🔄 Starting all API calls...")
        
        // Enter dispatch group for remote config
        apiDispatchGroup.enter()
        fetchRemoteConfig()
        
        // Enter dispatch group for IPTV country data
        apiDispatchGroup.enter()
        fetchIPTVCountryData()
        
        // Enter dispatch group for IPTV category data
        apiDispatchGroup.enter()
        fetchIPTVCateData()
        
        // Notify when all API calls are complete
        apiDispatchGroup.notify(queue: .main) { [weak self] in
            guard let self = self else { return }
            
            print("✅ All API calls completed")
            print("📊 Results - Remote Config: \(self.remoteConfigSuccess ? "✅" : "❌"), " +
                  "Country Data: \(self.countryDataSuccess ? "✅" : "❌"), " +
                  "Category Data: \(self.categoryDataSuccess ? "✅" : "❌")")
            
            // Check for cached data as fallback
            self.checkForCachedDataAndNavigate()
        }
    }
    
    func fetchRemoteConfig() {
        print("🔄 Fetching Remote Config...")
        NetworkManager.shared.fetchRemoteConfig(from: self) { [weak self] result in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                switch result {
                case .success(let json):
                    if let json = json as? [String: Any] {
                        self.processRemoteConfig(json)
                        self.remoteConfigSuccess = true
                        print("✅ Remote Config fetched successfully")
                    } else {
                        print("❌ Invalid JSON format for Remote Config")
                        self.remoteConfigSuccess = false
                    }
                case .failure(let error):
                    print("❌ Failed to fetch Remote Config:", error.localizedDescription)
                    self.remoteConfigSuccess = false
                }
                // Leave dispatch group
                self.apiDispatchGroup.leave()
            }
        }
    }
    
    private func processRemoteConfig(_ jsonDict: [String: Any]) {
        // Process your remote config data
        bannerId = (jsonDict["bannerId"] as AnyObject).stringValue ?? ""
        nativeId = (jsonDict["nativeId"] as AnyObject).stringValue ?? ""
        interstialId = (jsonDict["interstialId"] as AnyObject).stringValue ?? ""
        appopenId = (jsonDict["appopenId"] as AnyObject).stringValue ?? ""
        rewardId = (jsonDict["rewardId"] as AnyObject).stringValue ?? ""
        
        addButtonColor = (jsonDict["addButtonColor"] as AnyObject).stringValue ?? "#7462FF"
        let customInterstial = (jsonDict["customInterstial"] as AnyObject).intValue ?? 0
        
        adsCount = (jsonDict["afterClick"] as AnyObject).intValue ?? 4
        adsPlus = customInterstial == 0 ? adsCount - 1 : adsCount
        
        let extraFields = (jsonDict["extraFields"] as AnyObject)
        smallNativeBannerId = (extraFields["small_native"] as AnyObject).stringValue ?? ""
        
        isIAPON = (extraFields["plan"] as AnyObject).stringValue ?? ""
        IAPRequiredForTrailor = (extraFields["play"] as AnyObject).stringValue ?? ""
        prefixUrl = (extraFields["appjson"] as AnyObject).stringValue ?? ""
        NewsAPI = (extraFields["story"] as AnyObject).stringValue ?? ""
    }
    
    func fetchIPTVCountryData() {
        print("🔄 Fetching IPTV Country Data...")
        guard let url = URL(string: "http://d2is1ss4hhk4uk.cloudfront.net/iptv/iptv_grouped_by_country.json") else {
            print("❌ Invalid URL for country data")
            self.countryDataSuccess = false
            self.apiDispatchGroup.leave()
            return
        }
        
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Error fetching country data:", error.localizedDescription)
                    self.countryDataSuccess = false
                    self.apiDispatchGroup.leave()
                    return
                }
                
                guard let data = data else {
                    print("❌ No data received for country data")
                    self.countryDataSuccess = false
                    self.apiDispatchGroup.leave()
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode([IPTVGroup].self, from: data)
                    if let encoded = try? JSONEncoder().encode(result) {
                        UserDefaults.standard.set(encoded, forKey: "iptv_grouped_by_country")
                        self.countryDataSuccess = true
                        print("✅ IPTV Country Data saved successfully")
                    }
                } catch {
                    print("❌ Decoding error for country data:", error)
                    self.countryDataSuccess = false
                }
                
                // Leave dispatch group
                self.apiDispatchGroup.leave()
            }
        }.resume()
    }
    
    func fetchIPTVCateData() {
        print("🔄 Fetching IPTV Category Data...")
        guard let url = URL(string: "http://d2is1ss4hhk4uk.cloudfront.net/iptv/iptv_grouped_by_category.json") else {
            print("❌ Invalid URL for category data")
            self.categoryDataSuccess = false
            self.apiDispatchGroup.leave()
            return
        }
        
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard let self = self else { return }
            
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ Error fetching category data:", error.localizedDescription)
                    self.categoryDataSuccess = false
                    self.apiDispatchGroup.leave()
                    return
                }
                
                guard let data = data else {
                    print("❌ No data received for category data")
                    self.categoryDataSuccess = false
                    self.apiDispatchGroup.leave()
                    return
                }
                
                do {
                    let decoder = JSONDecoder()
                    let result = try decoder.decode([IPTVCategory].self, from: data)
                    
                    if let encoded = try? JSONEncoder().encode(result) {
                        UserDefaults.standard.set(encoded, forKey: "iptv_grouped_by_category")
                        self.categoryDataSuccess = true
                        print("✅ IPTV Category Data saved successfully")
                    }
                } catch {
                    print("❌ Decoding error for category data:", error)
                    self.categoryDataSuccess = false
                }
                
                // Leave dispatch group
                self.apiDispatchGroup.leave()
            }
        }.resume()
    }
    
    private func checkForCachedDataAndNavigate() {
        // Check if we have cached data
        let hasCountryData = UserDefaults.standard.data(forKey: "iptv_grouped_by_country") != nil
        let hasCategoryData = UserDefaults.standard.data(forKey: "iptv_grouped_by_category") != nil
        
        print("📊 Cached Data Status - Country: \(hasCountryData ? "✅" : "❌"), Category: \(hasCategoryData ? "✅" : "❌")")
        
        // If no category data is cached from API, check if we have old cached data
        if !hasCategoryData {
            if let cachedData = UserDefaults.standard.data(forKey: "iptv_grouped_by_category"),
               let _ = try? JSONDecoder().decode([IPTVCategory].self, from: cachedData) {
                print("✅ Using previously cached category data")
            } else {
                print("❌ No category data available (API failed and no cache)")
            }
        }
        
        // Stop animation and navigate
        self.stopLottieAnimation()
        self.navigateBasedOnStatus()
    }
    
    private func fallbackNavigation() {
        HelperManager.setupInitialLanguage()
        
        // Even in fallback, try to fetch IPTV data
        print("🔄 Fallback: Fetching IPTV data...")
        startAllAPICalls()
    }
    
    // MARK: - Navigation
    private func navigateBasedOnStatus() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let sceneWindow = sceneDelegate.window else { return }
        
        let initialVC: UIViewController
        
        if !AppStorage.contains(UserDefaultKeys.selectedLanguage) {
            // No language set → languageVC
            initialVC = UIStoryboard(name: StoryboardName.language, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.languageVC)
        } else if !(AppStorage.get(forKey: UserDefaultKeys.hasLaunchedBefore) ?? false) {
            // First launch → Onboarding introVC1
            initialVC = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.o1VC)
            AppStorage.set(true, forKey: UserDefaultKeys.hasLaunchedBefore)
        } else {
            // Language already set → homeVC
            initialVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.homeVC)
        }
        
        // Always wrap in navigation controller
        let navController = UINavigationController(rootViewController: initialVC)
        
        // Customize navigation bar
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(named: "#111111")
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        navController.navigationBar.standardAppearance = appearance
        navController.navigationBar.scrollEdgeAppearance = appearance
        navController.navigationBar.tintColor = .white
        
        // Hide nav bar only for HomeVC
        if initialVC is HomeVC {
            navController.isNavigationBarHidden = true
        }
        
        sceneWindow.rootViewController = navController
        sceneWindow.makeKeyAndVisible()
        
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.window = sceneWindow
            print("✅ AppDelegate window set successfully")
        }
    }
}
