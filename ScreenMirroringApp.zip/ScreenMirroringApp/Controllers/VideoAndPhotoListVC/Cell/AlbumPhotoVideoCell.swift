//
//  AlbumPhotoVideoCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 18/12/25.
//

import UIKit

class AlbumPhotoVideoCell: UICollectionViewCell {
    @IBOutlet weak var photoOrVideoImagePreview: UIImageView!
    @IBOutlet weak var videoDurationView: UIView!
    @IBOutlet weak var durationLabel: UILabel!
    @IBOutlet weak var parentView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    private func setupUI() {
        // Set image view properties
        photoOrVideoImagePreview.contentMode = .scaleAspectFill
        photoOrVideoImagePreview.clipsToBounds = true
        
        // Style the video duration view
        videoDurationView.layer.cornerRadius = 4
        videoDurationView.clipsToBounds = true
        videoDurationView.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        
        // Style duration label
        durationLabel.textColor = .white
        durationLabel.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        
        // No corner radius for parentView
        parentView.layer.cornerRadius = 0
        parentView.clipsToBounds = false
    }
}
