//
//  AlbumListCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 18/12/25.
//

import UIKit

class AlbumListCell: UICollectionViewCell {
    @IBOutlet weak var albumThumImageView: UIImageView!
    @IBOutlet weak var albumNameLabel: UILabel!
    @IBOutlet weak var totalAssetsCountLabel: UILabel!
    @IBOutlet weak var albumSelectedView: UIView!
    @IBOutlet weak var thumbImageHeightConstant: NSLayoutConstraint!
    
    @IBOutlet weak var albumSelectedHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var albumSelectedWidthConstraint: NSLayoutConstraint!

    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        // Update corner radius after layout is complete
        updateCircularLayout()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        // Reset UI elements
        albumSelectedView.isHidden = true
    }
    
    private func setupUI() {
        // Set selected view properties
        albumSelectedView.backgroundColor = .clear
        albumSelectedView.layer.borderWidth = 0.5
        albumSelectedView.layer.borderColor = UIColor(hex: "#3F8FFF")?.cgColor
        albumSelectedView.isHidden = true
        
        // Set image view properties
        albumThumImageView.contentMode = .scaleAspectFill
        albumThumImageView.clipsToBounds = true
        albumThumImageView.backgroundColor = .systemGray6
        
        // Apply corner radius
        albumThumImageView.layer.cornerRadius = thumbImageHeightConstant.constant / 2
        albumSelectedView.layer.cornerRadius = (thumbImageHeightConstant.constant) / 2 // Add extra for border
        
        // Make albumSelectedView width same as height
        if let heightConstraint = thumbImageHeightConstant {
            // Remove any existing width constraint
            albumSelectedView.constraints.forEach { constraint in
                if constraint.firstAttribute == .width && constraint.secondItem == nil {
                    albumSelectedView.removeConstraint(constraint)
                }
            }
            
            // Add new width constraint equal to height
            let widthConstraint = NSLayoutConstraint(
                item: albumSelectedView,
                attribute: .width,
                relatedBy: .equal,
                toItem: albumSelectedView,
                attribute: .height,
                multiplier: 1.0,
                constant: 0
            )
            albumSelectedView.addConstraint(widthConstraint)
        }
    }
    
    private func updateCircularLayout() {
        // Ensure circular layout with thumbImageHeightConstant
        albumThumImageView.layer.cornerRadius = thumbImageHeightConstant.constant / 2
        albumSelectedView.layer.cornerRadius = (thumbImageHeightConstant.constant) / 2
    }
    
    func configure(with albumName: String, assetCount: Int) {
        albumNameLabel.text = albumName
        
        // Format the count based on the requirement
        if assetCount >= 100 {
            totalAssetsCountLabel.text = "(100+)"
        } else {
            totalAssetsCountLabel.text = "(\(assetCount))"
        }
    }
}
