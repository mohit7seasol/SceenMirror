//
//  VideoAndPhotoListVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 18/12/25.
//

//
//  VideoAndPhotoListVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 18/12/25.
//

import UIKit
import Photos
import AVKit

class VideoAndPhotoListVC: UIViewController {
    @IBOutlet weak var albumCV: UICollectionView!
    @IBOutlet weak var albumListCV: UICollectionView!
    @IBOutlet weak var titleLabel: UILabel!
    
    var MEDIA_TYPE: mediaType = .Photos
    
    // MARK: - Variables
    private var SMART_ALBUM = PHFetchResult<PHAssetCollection>()
    private var OTHER_ALBUM = PHFetchResult<PHAssetCollection>()
    private var ALL_ASSETS = [[String: PHFetchResult<PHAsset>]]()
    private var selectedAlbumAssets = PHFetchResult<PHAsset>()
    private var selectedAlbumIndex = 0
    var selectedAssetIndex = 0
    
    // Cache for image sizes to avoid repeated calculations
    private var imageSizeCache: [IndexPath: CGSize] = [:]
    // Cache for album thumbnails
    private var thumbnailCache: [Int: UIImage] = [:]
    // Track image requests to cancel them when needed
    private var imageRequestIDs: [Int: PHImageRequestID] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        MEDIA_TYPE == .Photos ? (titleLabel.text = "Cast Image".localized(LocalizationService.shared.language)) : (titleLabel.text = "Video Library".localized(LocalizationService.shared.language))
        setupCollectionViews()
        fetchAlbums()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Update layout after view layout
        albumCV.collectionViewLayout.invalidateLayout()
        albumListCV.collectionViewLayout.invalidateLayout()
    }
    
    @IBAction func backButtonTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    // MARK: - Setup Methods
    private func setupCollectionViews() {
        // Setup albumCV (horizontal scrolling for albums)
        let albumLayout = UICollectionViewFlowLayout()
        albumLayout.scrollDirection = .vertical
        albumLayout.minimumLineSpacing = 0 // Changed from 10 to 0
        albumLayout.minimumInteritemSpacing = 0 // Changed from 10 to 0
        
        // Set zero spacing on all sides
        albumLayout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) // Changed from (0, 10, 0, 10)
        
        // Set explicit item size for albumCV to fix sizing issues
        albumLayout.itemSize = CGSize(width: 80, height: 138)
        
        albumCV.collectionViewLayout = albumLayout
        
        albumCV.delegate = self
        albumCV.dataSource = self
        albumCV.register(UINib(nibName: "AlbumListCell", bundle: nil), forCellWithReuseIdentifier: "AlbumListCell")
        albumCV.showsHorizontalScrollIndicator = false
        
        // Setup albumListCV with custom waterfall layout
        let waterfallLayout = CustomWaterfallLayout()
        waterfallLayout.delegate = self
        
        albumListCV.collectionViewLayout = waterfallLayout
        
        albumListCV.delegate = self
        albumListCV.dataSource = self
        albumListCV.register(UINib(nibName: "AlbumPhotoVideoCell", bundle: nil), forCellWithReuseIdentifier: "AlbumPhotoVideoCell")
    }
    
    // MARK: - Fetch Albums
    private func fetchAlbums() {
        PHPhotoLibrary.requestAuthorization { [weak self] (status) in
            guard let self = self else { return }
            
            switch status {
            case .authorized:
                DispatchQueue.main.async {
                    self.fetchAlbumCollections()
                }
            case .denied, .restricted:
                DispatchQueue.main.async {
                    self.showPermissionAlert()
                }
            case .limited, .notDetermined:
                print("Limited or Not Determined authorization")
            @unknown default:
                break
            }
        }
    }
    
    private func fetchAlbumCollections() {
        let fetchOptions = PHFetchOptions()
        if MEDIA_TYPE == .Videos {
            fetchOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.video.rawValue)
        } else if MEDIA_TYPE == .Photos {
            fetchOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.image.rawValue)
        }
        
        SMART_ALBUM = PHAssetCollection.fetchAssetCollections(with: .smartAlbum, subtype: .any, options: nil)
        OTHER_ALBUM = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: nil)
        
        var fetchedAssets = PHFetchResult<PHAsset>()
        ALL_ASSETS.removeAll()
        
        // Fetch from SMART albums
        for i in 0..<SMART_ALBUM.count {
            fetchedAssets = PHAsset.fetchAssets(in: SMART_ALBUM[i], options: fetchOptions)
            if fetchedAssets.count > 0 {
                let albumName = SMART_ALBUM[i].localizedTitle ?? "Smart Album"
                let temp = [albumName : fetchedAssets]
                ALL_ASSETS.append(temp)
            }
        }
        
        // Fetch from OTHER albums
        for i in 0..<OTHER_ALBUM.count {
            fetchedAssets = PHAsset.fetchAssets(in: OTHER_ALBUM[i], options: fetchOptions)
            if fetchedAssets.count > 0 {
                let albumName = OTHER_ALBUM[i].localizedTitle ?? "Album"
                let temp = [albumName : fetchedAssets]
                ALL_ASSETS.append(temp)
            }
        }
        
        DispatchQueue.main.async {
            self.albumCV.reloadData()
            if self.ALL_ASSETS.count > 0 {
                // Select first album by default with zero index
                self.selectAlbumAtIndex(0)
            }
        }
    }
    
    private func selectAlbumAtIndex(_ index: Int) {
        selectedAlbumIndex = index
        if let albumDict = ALL_ASSETS[safe: index],
           let assets = albumDict.values.first {
            selectedAlbumAssets = assets
        }
        
        // Clear cache when album changes
        imageSizeCache.removeAll()
        
        // Reload albumCV to update selection UI
        albumCV.reloadData()
        
        // Scroll to selected cell with zero spacing
        let indexPath = IndexPath(item: index, section: 0)
        albumCV.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        
        // Reload albumListCV with new assets
        albumListCV.reloadData()
    }
    
    // MARK: - Load Album Thumbnail
    private func loadAlbumThumbnail(for cell: AlbumListCell, at indexPath: IndexPath) {
        // Cancel any previous request for this cell
        if let previousRequestID = imageRequestIDs[indexPath.item] {
            PHImageManager.default().cancelImageRequest(previousRequestID)
            imageRequestIDs.removeValue(forKey: indexPath.item)
        }
        
        guard indexPath.item < ALL_ASSETS.count else {
            cell.albumThumImageView.image = UIImage(systemName: "photo.on.rectangle")
            return
        }
        
        let albumDict = ALL_ASSETS[indexPath.item]
        guard let albumName = albumDict.keys.first,
              let assets = albumDict.values.first,
              assets.count > 0 else {
            cell.albumThumImageView.image = UIImage(systemName: "photo.on.rectangle")
            return
        }
        
        // Configure cell with album name and count
        cell.configure(with: albumName, assetCount: assets.count)
        
        // Check cache first
        if let cachedImage = thumbnailCache[indexPath.item] {
            cell.albumThumImageView.image = cachedImage
            cell.albumThumImageView.contentMode = .scaleAspectFill
            cell.albumThumImageView.clipsToBounds = true
            return
        }
        
        let firstAsset = assets.firstObject!
        let targetSize = CGSize(width: 80 * UIScreen.main.scale,
                               height: 80 * UIScreen.main.scale)
        
        let options = PHImageRequestOptions()
        options.deliveryMode = .opportunistic
        options.isNetworkAccessAllowed = true
        options.resizeMode = .fast
        
        // Store current cell reference
        let cellIdentifier = indexPath.item
        
        let requestID = PHImageManager.default().requestImage(for: firstAsset,
                                                            targetSize: targetSize,
                                                            contentMode: .aspectFill,
                                                            options: options) { [weak self] (image, info) in
            DispatchQueue.main.async {
                guard let self = self else { return }
                
                if let image = image {
                    // Cache the image
                    self.thumbnailCache[cellIdentifier] = image
                    
                    // Update the cell if it's still visible and hasn't been reused
                    if let visibleCell = self.albumCV.cellForItem(at: indexPath) as? AlbumListCell {
                        visibleCell.albumThumImageView.image = image
                        visibleCell.albumThumImageView.contentMode = .scaleAspectFill
                        visibleCell.albumThumImageView.clipsToBounds = true
                    }
                } else if let error = info?[PHImageErrorKey] as? Error {
                    print("Error loading image: \(error)")
                    if let visibleCell = self.albumCV.cellForItem(at: indexPath) as? AlbumListCell {
                        visibleCell.albumThumImageView.image = UIImage(systemName: "photo.on.rectangle")
                    }
                }
                
                // Clean up request ID
                self.imageRequestIDs.removeValue(forKey: cellIdentifier)
            }
        }
        
        // Store request ID for cancellation
        imageRequestIDs[indexPath.item] = requestID
    }
    
    // Calculate image height based on aspect ratio
    private func calculateImageHeight(for asset: PHAsset, withWidth width: CGFloat) -> CGFloat {
        let aspectRatio = CGFloat(asset.pixelHeight) / CGFloat(asset.pixelWidth)
        
        // Add extra height for video duration label if it's a video
        let extraHeight: CGFloat = MEDIA_TYPE == .Videos ? 30 : 0
        
        return (width * aspectRatio) + extraHeight
    }
    
    private func showPermissionAlert() {
        let alert = UIAlertController(
            title: "Can not access Photos and Videos!",
            message: "You have not given permission for access Photos and Videos. \nGoto settings and give permission 'ALL Photos' to access all Photos and Videos.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: { _ in
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(alert, animated: true)
    }
}

// MARK: - UICollectionViewDataSource
extension VideoAndPhotoListVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == albumCV {
            return ALL_ASSETS.count
        } else {
            return selectedAlbumAssets.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == albumCV {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AlbumListCell", for: indexPath) as! AlbumListCell
            
            let name = ALL_ASSETS[indexPath.item].keys.first!
            let assets = ALL_ASSETS[indexPath.item][name]!
            
            // Configure cell with formatted count
            cell.configure(with: name, assetCount: assets.count)
            
            // Set selection state
            cell.albumSelectedView.isHidden = (indexPath.item != selectedAlbumIndex)
            
            // Load thumbnail
            loadAlbumThumbnail(for: cell, at: indexPath)
            
            return cell
            
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AlbumPhotoVideoCell",
                                                         for: indexPath) as! AlbumPhotoVideoCell
            
            let asset = selectedAlbumAssets[indexPath.item]
            
            // Fetch and set image preview
            cell.photoOrVideoImagePreview.fetchImageAsset(asset,
                                                          targetSize: CGSize(width: 300, height: 300),
                                                          completionHandler: nil)
            
            // Configure for video if needed
            if MEDIA_TYPE == .Videos {
                cell.videoDurationView.isHidden = false
                let duration = Int(asset.duration)
                let minutes = duration / 60
                let seconds = duration % 60
                cell.durationLabel.text = String(format: "%02d:%02d", minutes, seconds)
            } else {
                cell.videoDurationView.isHidden = true
                cell.durationLabel.text = ""
            }
            
            return cell
        }
    }
}

// MARK: - UICollectionViewDelegate
extension VideoAndPhotoListVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == albumCV {
            selectAlbumAtIndex(indexPath.item)
        } else {
            // Handle selection of photo/video - Based on AlbumsListVc implementation
            print("Selected asset at index: \(indexPath.item)")
            
            // Set the selected index
            selectedAssetIndex = indexPath.row
            
            // Check if device is connected
            let isConnected = commonViewModel?.getConnectedTvType() != .noneTV || checkAirPlayStatus()
            
            if selectedTvType == .LGTV || selectedTvType == .GcastTV || checkAirPlayStatus() {
                DispatchQueue.main.asyncAfter(deadline: .now()) { [self] in
                    if MEDIA_TYPE == .Photos {
                        openImageCast()
                    } else {
                        openVideoCast()
                    }
                }
            } else {
                // If not connected, show device list (popup)
                let vc: ListDeviceVc = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
                
                // Prepare assets array for passing to ListDeviceVc
                var assetsArray: [PHAsset] = []
                for i in 0..<selectedAlbumAssets.count {
                    assetsArray.append(selectedAlbumAssets[i])
                }
                
                // Set the properties that ListDeviceVc expects
//                vc.selectedIndex = selectedAssetIndex
//                vc.mediaType = MEDIA_TYPE
//                vc.assets = assetsArray
//                vc.albumName = getSelectedAlbumName()
                
                self.navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if collectionView == albumCV {
            // Cancel image request when cell goes off screen
            if let requestID = imageRequestIDs[indexPath.item] {
                PHImageManager.default().cancelImageRequest(requestID)
                imageRequestIDs.removeValue(forKey: indexPath.item)
            }
        }
    }
    
    // MARK: - Helper Methods
    
    private func getSelectedAlbumName() -> String? {
        guard selectedAlbumIndex < ALL_ASSETS.count else { return nil }
        let albumDict = ALL_ASSETS[selectedAlbumIndex]
        return albumDict.keys.first
    }
    
    private func checkAirPlayStatus() -> Bool {
        let audioSession = AVAudioSession.sharedInstance()
        let currentRoute = audioSession.currentRoute
        
        for output in currentRoute.outputs {
            if output.portType == .airPlay {
                return true
            }
        }
        return false
    }
    
    private func openImageCast() {
        if checkAirPlayStatus() {
            // AirPlay casting for photos
            let selectedImage = selectedAlbumAssets[selectedAssetIndex]
            DispatchQueue.main.async {
                self.playPHAssetImage(selectedImage)
            }
        } else {
            // Regular casting for photos
            let vc: PhotoCastVC = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "PhotoCastVC") as! PhotoCastVC
            
            // Convert PHFetchResult to array
            var assetsArray: [PHAsset] = []
            for i in 0..<selectedAlbumAssets.count {
                assetsArray.append(selectedAlbumAssets[i])
            }
            
            vc.assets = assetsArray
            vc.currentCastingImage = selectedAssetIndex
            vc.selectedPhotos = Array(0..<assetsArray.count)
            
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    
    private func openVideoCast() {
        if checkAirPlayStatus() {
            // AirPlay casting for videos
            let selectedVideo = selectedAlbumAssets[selectedAssetIndex]
            DispatchQueue.main.async {
                self.playPHAssetVideo(selectedVideo)
            }
        } else {
            // Regular casting for videos
            let vc: VideoCastVC = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "VideoCastVC") as! VideoCastVC
            
            // Convert PHFetchResult to array and pass selected video and all videos
            var assetsArray: [PHAsset] = []
            for i in 0..<selectedAlbumAssets.count {
                assetsArray.append(selectedAlbumAssets[i])
            }
            
            vc.videoAssets = assetsArray
            vc.mediatype = .Videos
            vc.selectedIndex = selectedAssetIndex
            
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    // MARK: - AirPlay Methods
    
    private func playPHAssetImage(_ asset: PHAsset) {
        // Implement AirPlay image casting
        // This should include the image processing and AirPlay setup from your reference code
        print("AirPlay casting image at index: \(selectedAssetIndex)")
        
        // You'll need to add the actual AirPlay implementation here
        // Based on your reference code, you'd need to:
        // 1. Get the image from PHAsset
        // 2. Convert it to video if needed for AirPlay
        // 3. Set up the player for AirPlay
        
        // Placeholder implementation:
        let options = PHImageRequestOptions()
        options.deliveryMode = .highQualityFormat
        options.isNetworkAccessAllowed = true
        
        PHImageManager.default().requestImage(for: asset, targetSize: PHImageManagerMaximumSize, contentMode: .aspectFit, options: options) { [weak self] image, info in
            guard let self = self, let image = image else { return }
            
            // Process and cast the image via AirPlay
            // This is where you'd implement the actual AirPlay casting logic
            print("Image loaded for AirPlay casting: \(image.size)")
        }
    }
    
    private func playPHAssetVideo(_ asset: PHAsset) {
        let options = PHVideoRequestOptions()
        options.deliveryMode = .highQualityFormat
        options.isNetworkAccessAllowed = true
        
        PHImageManager.default().requestAVAsset(forVideo: asset, options: options) { [weak self] avAsset, audioMix, info in
            guard let self = self, let avAsset = avAsset as? AVURLAsset else { return }
            
            DispatchQueue.main.async {
                // Play via AirPlay
                let player = AVPlayer(url: avAsset.url)
                let playerViewController = AVPlayerViewController()
                playerViewController.player = player
                
                // Enable AirPlay
                playerViewController.allowsPictureInPicturePlayback = true
                playerViewController.player?.allowsExternalPlayback = true
                playerViewController.player?.usesExternalPlaybackWhileExternalScreenIsActive = true
                
                self.present(playerViewController, animated: true) {
                    player.play()
                }
            }
        }
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension VideoAndPhotoListVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        if collectionView == albumCV {
            return CGSize(width: 80, height: 138)
        }
        
        return CGSize.zero
    }
    
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == albumCV {
            return 0 // Changed from 10 to 0
        }
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == albumCV {
            return 0 // Changed from 10 to 0
        }
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       insetForSectionAt section: Int) -> UIEdgeInsets {
        if collectionView == albumCV {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0) // Changed from (0, 10, 0, 10)
        }
        return UIEdgeInsets.zero
    }
}

// MARK: - CustomWaterfallLayoutDelegate
extension VideoAndPhotoListVC: CustomWaterfallLayoutDelegate {
    func collectionView(_ collectionView: UICollectionView,
                       heightForItemAt indexPath: IndexPath,
                       withWidth width: CGFloat) -> CGFloat {
        
        if let cachedSize = imageSizeCache[indexPath] {
            return cachedSize.height
        }
        
        guard indexPath.item < selectedAlbumAssets.count else {
            return 200
        }
        
        let asset = selectedAlbumAssets[indexPath.item]
        let height = calculateImageHeight(for: asset, withWidth: width)
        
        imageSizeCache[indexPath] = CGSize(width: width, height: height)
        
        return height
    }
    
    func columnCountForCollectionView(_ collectionView: UICollectionView) -> Int {
        if UIDevice.current.userInterfaceIdiom == .pad {
            return collectionView.bounds.width > 600 ? 3 : 2
        }
        return 2
    }
}

// MARK: - Helper Extensions
extension UIColor {
    convenience init?(hex: String) {
        var hexString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if hexString.hasPrefix("#") {
            hexString.remove(at: hexString.startIndex)
        }
        
        guard hexString.count == 6 else { return nil }
        
        var rgbValue: UInt64 = 0
        Scanner(string: hexString).scanHexInt64(&rgbValue)
        
        self.init(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: 1.0
        )
    }
}

extension Array {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
