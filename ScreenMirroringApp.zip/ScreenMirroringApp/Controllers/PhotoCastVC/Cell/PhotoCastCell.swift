//
//  PhotoCastCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 01/01/26.
//

import UIKit

class PhotoCastCell: UICollectionViewCell {

    @IBOutlet weak var imgPreview: UIImageView!
    @IBOutlet weak var parentView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
