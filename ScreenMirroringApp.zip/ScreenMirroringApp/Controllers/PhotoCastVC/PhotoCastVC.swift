//
//  PhotoCastVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 01/01/26.
//

//
//  PhotoCastVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 01/01/26.
//

import UIKit
import Photos
import AVKit
import SVProgressHUD
import GoogleCast
import AWSS3
import AWSAuthCore
import AVFoundation
import ConnectSDK
import SwiftPopup

class PhotoCastVC: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var imgPreview: UIImageView!
    @IBOutlet weak var imageListCV: UICollectionView!{
        didSet{
            imageListCV.delegate = self
            imageListCV.dataSource = self
            imageListCV.register(UINib.init(nibName: PhotoCastCell.className, bundle: nil), forCellWithReuseIdentifier: PhotoCastCell.className)
        }
    }
    @IBOutlet weak var playButton: UIButton!
    
    var assets = [PHAsset]()
    var selectedPhotos = [Int]()
    var isDone = false
    var previousCastingImage = 0
    var currentCastingImage = 0 {
        willSet {
            if newValue != currentCastingImage && !selectedPhotos.isEmpty {
                if newValue < self.assets.count {
                    self.titleLabel.text = assets[selectedPhotos[newValue]].originalFilename
                }
            }
        }
    }
    var timer = Timer()
    let imageManager = PHCachingImageManager()
    let option = PHImageRequestOptions()
    private var credentials: String? = nil
    
    var playImageCount = Int()
    var isPlaying: Bool = false
    
    private var playerViewController: AVPlayerViewController?
    private var player: AVPlayer?
    private var playerItem: AVPlayerItem?
    
    var selectedQuality: CGFloat = 1.0 // 1.0 = original, 0.7 = high, 0.5 = medium
    var selectedSlideShowTime: Int = 7 // Default to 7 seconds
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        videoCastImageDummy = self.imgPreview.image!
        photoArray = self.assets
        selectedPhotoCastIndex = currentCastingImage
        isImageCast = true
        isCastType = .casVideo
        // Stop slideshow when leaving the screen
        stopSlideshow()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if !isDone {
            isDone = true
            DispatchQueue.main.async {
                self.imageListCV.scrollToItem(at: IndexPath(item: self.currentCastingImage, section: 0), at: .centeredHorizontally, animated: false)
            }
        }
    }
    
    func initView(){
        NotificationCenter.default.addObserver(self, selector: #selector(castSessionStarted), name: Notification.Name("CAST_SESSION_STARTED"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(castSessionEnded), name: Notification.Name("CAST_SESSION_ENDED"), object: nil)
        
        if !selectedPhotos.isEmpty && currentCastingImage < selectedPhotos.count {
            self.titleLabel.text = assets[selectedPhotos[currentCastingImage]].originalFilename
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now()+1.0, execute: {
            if !self.selectedPhotos.isEmpty && self.currentCastingImage < self.selectedPhotos.count {
                self.playPhotos(with: self.assets[self.selectedPhotos[self.currentCastingImage]])
            }
        })
        
        if currentCastingImage < assets.count {
            self.imgPreview.fetchImageAsset1(assets[currentCastingImage], targetSize: CGSize(width: assets[currentCastingImage].pixelWidth, height: assets[currentCastingImage].pixelHeight), completionHandler: nil)
        }
        self.imgPreview.contentMode = .scaleAspectFit
        
        photoArray.removeAll()
        photoArray = self.assets
    }
    
    func showAlert(withTitle title: String, message: String) {
        let alertvc = UIAlertController.init(title: title, message: message, preferredStyle: .alert)
        alertvc.addAction(UIAlertAction.init(title: "OK", style: .cancel, handler: nil))
        self.present(alertvc, animated: true, completion: nil)
    }
    
    // MARK: Start Preview
    func playPhotos(with asset: PHAsset) {
        playImageCount += 1
        
        let imageManager = PHImageManager.default()
        let option = PHImageRequestOptions()
        option.isSynchronous = true
        option.deliveryMode = .opportunistic
        
        imageManager.requestImage(for: asset, targetSize: CGSize(width: 500, height: 500), contentMode: .aspectFill, options: option, resultHandler: { [weak self] (image, info) in
            
            guard let self = self, let newImage = image else { return }
            
            // Use the same casting logic as ImageVC
            if self.checkAirPlayStatus() {
                self.ProgressViewShow(uiView: self.view)
                self.castImageDirectlyToAirPlay(image: newImage)
            } else {
                // Use commonViewModel casting for Google Cast or LG
                self.castImageUsingCommonViewModel(asset: asset, image: newImage)
            }
        })
    }
    
    private func castImageUsingCommonViewModel(asset: PHAsset, image: UIImage) {
        asset.getMediaFileURL { url in
            if let url = url {
                isSplashCasting = false
                
                // Convert quality from CGFloat to Int percentage
                let qualityPercentage = Int(self.selectedQuality * 100)
                
                commonViewModel.compressAndUploadImage(from: url,
                                                      mediaType: "image/jpeg",
                                                      imgHei: asset.pixelHeight,
                                                      imgWid: asset.pixelWidth,
                                                      selectedQuality: qualityPercentage)
            } else {
                // Fallback: Use the image directly if URL fails
                if let imageData = image.jpegData(compressionQuality: self.selectedQuality) {
                    let tempDirectory = FileManager.default.temporaryDirectory
                    let fileName = "\(UUID().uuidString).jpg"
                    let fileURL = tempDirectory.appendingPathComponent(fileName)
                    do {
                        try imageData.write(to: fileURL)
                        isSplashCasting = false
                        
                        let qualityPercentage = Int(self.selectedQuality * 100)
                        commonViewModel.compressAndUploadImage(from: fileURL,
                                                              mediaType: "image/jpeg",
                                                              imgHei: asset.pixelHeight,
                                                              imgWid: asset.pixelWidth,
                                                              selectedQuality: qualityPercentage)
                    } catch {
                        print("❌ Failed to save image to temp file: \(error)")
                    }
                }
            }
        }
    }
    
    func displayToast(_ message: String) {
        // Implement toast display logic
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        present(alert, animated: true)
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) {
            alert.dismiss(animated: true)
        }
    }
    
    func startSlideShow(second: Int) {
        isPlaying = true
        updatePlayButtonState()
        // Invalidate any existing timer
        timer.invalidate()
        
        // Start new timer
        self.timer = Timer.scheduledTimer(timeInterval: TimeInterval(second),
                                        target: self,
                                        selector: #selector(slideShowOn),
                                        userInfo: nil,
                                        repeats: true)
        
        // Immediately play the first image
        self.slideShowOn()
    }
    
    func stopSlideshow() {
        timer.invalidate()
        isPlaying = false
        updatePlayButtonState()
    }
    
    @objc func slideShowOn() {
        if currentCastingImage < assets.count - 1 {
            currentCastingImage += 1
        } else {
            // If we reached the end, stop the slideshow
            stopSlideshow()
            return
        }
        
        // Update UI and play the image
        DispatchQueue.main.async {
            self.imageListCV.scrollToItem(at: IndexPath(item: self.currentCastingImage, section: 0),
                                        at: .centeredHorizontally,
                                        animated: true)
            self.imageListCV.reloadData()
            if self.currentCastingImage < self.assets.count {
                self.playPhotos(with: self.assets[self.currentCastingImage])
                self.imgPreview.fetchImageAsset1(self.assets[self.currentCastingImage],
                                               targetSize: CGSize(width: self.assets[self.currentCastingImage].pixelWidth,
                                                                height: self.assets[self.currentCastingImage].pixelHeight),
                                               completionHandler: nil)
                self.titleLabel.text = self.assets[self.currentCastingImage].originalFilename
            }
        }
    }
    func openQualityPickPopUP() {
        let vc : PhotoQualityPopUpVC =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "PhotoQualityPopUpVC") as! PhotoQualityPopUpVC
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        
        // Set callback for quality selection
        vc.onQualitySelected = { [weak self] quality in
            self?.selectedQuality = quality
            
            // Update casting with new quality
            if let self = self, !self.selectedPhotos.isEmpty && self.currentCastingImage < self.selectedPhotos.count {
                let assetIndex = self.selectedPhotos[self.currentCastingImage]
                if assetIndex < self.assets.count {
                    let asset = self.assets[assetIndex]
                    self.playPhotos(with: asset)
                }
            }
        }
        
        // Set current quality
        vc.currentQuality = selectedQuality
        
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        vc.showAnimation = showAnimation
        vc.dismissAnimation = dismissAnimation
        
        vc.show()
    }
    func openSlideShowTimePickPopUP() {
        let vc : PhotoCastSlideTimmerPopUpVC =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "PhotoCastSlideTimmerPopUpVC") as! PhotoCastSlideTimmerPopUpVC
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        
        // Set callback for time selection
        vc.onTimeSelected = { [weak self] timeInSeconds in
            self?.selectedSlideShowTime = timeInSeconds
            self?.isPlaying = true
            self?.updatePlayButtonState()
            // Start slideshow with selected time
            self?.startSlideShow(second: timeInSeconds)
        }
        
        // Set current time
        vc.currentTime = selectedSlideShowTime
        
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        vc.showAnimation = showAnimation
        vc.dismissAnimation = dismissAnimation
        
        vc.show()
    }
}

// MARK: - Button Actions
extension PhotoCastVC {
    @IBAction func choosePhotoCastQualityButtonTap(_ sender: Any) {
        openQualityPickPopUP()
    }
    
    @IBAction func sliderTimePickButtonTap(_ sender: Any) {
        openSlideShowTimePickPopUP()
    }
    @IBAction func playButtonTap(_ sender: UIButton) {
        let generator = UIImpactFeedbackGenerator(style: .heavy)
        generator.impactOccurred()
        
        if isPlaying {
            // Pause the slideshow
            stopSlideshow()
            isPlaying = false
            updatePlayButtonState()
        } else {
            // Start slideshow with selected time
            // We'll get the time from the popup
            openSlideShowTimePickPopUP()
        }
    }
    
    @IBAction func backButtonTap(_ sender: Any) {
        let generator = UIImpactFeedbackGenerator(style: .heavy)
        generator.impactOccurred()
        self.timer.invalidate()
        self.navigationController?.popViewController(animated: true)
    }
    
    @objc func castSessionStarted() {
        // Update Google Cast button if needed
    }
    
    @objc func castSessionEnded() {
        // Update Google Cast button if needed
    }
    private func updatePlayButtonState() {
         if isPlaying {
             // Change to pause icon/title
             playButton.setTitle("Pause", for: .normal)
         } else {
             // Change to play icon/title
             playButton.setTitle("Play", for: .normal)
         }
     }
}

// MARK: - Extension of Collection View
extension PhotoCastVC : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    // MARK: - Number Of Section Function
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return assets.count
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: self.imageListCV.frame.height, height: self.imageListCV.frame.height)
    }
    
    // MARK: - Cell For Row At Function
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PhotoCastCell.className, for: indexPath) as! PhotoCastCell
        
        let asset = assets[indexPath.row]

        cell.imgPreview.fetchImageAsset(asset, targetSize: CGSize(width: asset.pixelWidth/10, height: asset.pixelHeight/10), completionHandler: nil)
        cell.imgPreview.layer.borderWidth = currentCastingImage == indexPath.row ? 3 : 0
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.currentCastingImage = indexPath.row
        self.imageListCV.reloadData()
        if indexPath.row < assets.count {
            self.playPhotos(with: assets[indexPath.row])
            self.imgPreview.fetchImageAsset1(assets[currentCastingImage], targetSize: CGSize(width: assets[currentCastingImage].pixelWidth, height: assets[currentCastingImage].pixelHeight), completionHandler: nil)
        }
    }
}

// MARK: - AirPlay Extension
extension PhotoCastVC {
    
    func checkAirPlayStatus() -> Bool {
        let audioSession = AVAudioSession.sharedInstance()
        let currentRoute = audioSession.currentRoute
        for output in currentRoute.outputs {
            if output.portType == .airPlay {
                return true
            }
        }
        return false
    }
    
    private func castImageDirectlyToAirPlay(image: UIImage) {
        let imageURL = saveImageToTemp(image: image)
        ImageToVideoConverter.convertImageToVideo(imageURL: imageURL) { result in
            switch result {
            case .success(let videoURL):
                print("Video URL: \(videoURL)")
                // Use the video URL
                self.prepareVideoForHTTPServer(localVideoURL: videoURL)
            case .failure(let error):
                self.ProgressViewHide(uiView: self.view)
                print("Error: \(error)")
            }
        }
    }
    
    func prepareVideoForHTTPServer(localVideoURL: URL) {
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let destinationURL = documentsDirectory.appendingPathComponent("rendered_video.mp4")
        
        try? FileManager.default.removeItem(at: destinationURL)
        do {
            try FileManager.default.copyItem(at: localVideoURL, to: destinationURL)
            print("📁 Copied video to HTTP Server root")
            DispatchQueue.main.async {
                let playerItem = AVPlayerItem(url: destinationURL)
                self.player = AVPlayer(playerItem: playerItem)
                self.configurePlayerForAirPlay()
                self.playerViewController = AVPlayerViewController()
                self.playerViewController?.player = self.player
                
                self.present(self.playerViewController!, animated: true) {
                    self.player?.play()
                    DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(2)) {
                        self.player?.pause()
                        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(9)) {
                            self.playerViewController?.player?.pause()
                        }
                    }
                }
            }
        } catch {
            SVProgressHUD.dismiss()
            print("❌ Failed to copy file: \(error.localizedDescription)")
        }
    }
    
    private func configurePlayerForAirPlay() {
        guard let player = player else { return }

        // Enable AirPlay
        player.allowsExternalPlayback = true
        player.usesExternalPlaybackWhileExternalScreenIsActive = true
        playerViewController?.allowsPictureInPicturePlayback = false
        playerViewController?.updatesNowPlayingInfoCenter = false

        // Optional: Observe if it's being routed externally
        NotificationCenter.default.addObserver(self,
                                              selector: #selector(handleRouteChange),
                                              name: AVAudioSession.routeChangeNotification,
                                              object: nil)
    }

    @objc private func handleRouteChange(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let reasonValue = userInfo[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: reasonValue) else { return }

        switch reason {
        case .oldDeviceUnavailable:
            print("AirPlay device disconnected.")
        case .newDeviceAvailable:
            print("AirPlay device connected.")
        default:
            break
        }
    }
    
    func saveImageToTemp(image: UIImage) -> URL {
        let tempDirectory = FileManager.default.temporaryDirectory
        let tempURL = tempDirectory.appendingPathComponent("\(UUID().uuidString).jpg")
        
        if let imageData = image.jpegData(compressionQuality: 0.8) {
            try? imageData.write(to: tempURL)
        }
        
        return tempURL
    }
    
    func cleanupPlayer() {
        player?.pause()
        player = nil
        playerItem = nil
        playerViewController = nil
    }
}

// MARK: - Loading Indicator Methods
extension PhotoCastVC {
    func progressViewShow(uiView: UIView) {
        SVProgressHUD.show()
        SVProgressHUD.setDefaultMaskType(.clear)
    }
    
    func progressViewHide(uiView: UIView) {
        SVProgressHUD.dismiss()
    }
}
