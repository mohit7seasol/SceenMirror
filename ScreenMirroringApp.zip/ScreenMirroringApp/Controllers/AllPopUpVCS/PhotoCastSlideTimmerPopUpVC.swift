//
//  PhotoCastSlideTimmerPopUpVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 02/01/26.
//

import UIKit
import SwiftPopup

class PhotoCastSlideTimmerPopUpVC: SwiftPopup {

    @IBOutlet weak var adjustLbl: UILabel!
    @IBOutlet weak var moveLbl: UILabel!
    @IBOutlet weak var SevenSecondsButton: UIButton!
    @IBOutlet weak var TenSecondsButton: UIButton!
    @IBOutlet weak var enterCustomSecondButton: UIButton!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var validationLbl: UILabel!
    
    // Callback for time selection
    var onTimeSelected: ((Int) -> Void)?
    var currentTime: Int = 7 // Default to 7 seconds
    
    private var customEnteredSeconds: Int = 0
    private var selectedTimeType: TimeType = .sevenSeconds
    
    enum TimeType {
        case sevenSeconds
        case tenSeconds
        case custom
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    func setUI() {
        validationLbl.isHidden = true
        validationLbl.alpha = 0
        
        // Set initial selection
        updateUIForSelectedTime()
    }
    
    private func updateUIForSelectedTime() {
        // Reset all buttons
        SevenSecondsButton.setTitleColor(UIColor(hex: "#A6A6AC"), for: .normal)
        TenSecondsButton.setTitleColor(UIColor(hex: "#A6A6AC"), for: .normal)
        enterCustomSecondButton.setTitleColor(UIColor(hex: "#A6A6AC"), for: .normal)
        
        // Set selected based on currentTime
        if currentTime == 7 {
            selectedTimeType = .sevenSeconds
            SevenSecondsButton.setTitleColor(.white, for: .normal)
        } else if currentTime == 10 {
            selectedTimeType = .tenSeconds
            TenSecondsButton.setTitleColor(.white, for: .normal)
        } else {
            selectedTimeType = .custom
            enterCustomSecondButton.setTitleColor(.white, for: .normal)
        }
    }
    
    private func showValidationError(message: String) {
        validationLbl.text = message
        validationLbl.textColor = .red
        validationLbl.isHidden = false
        
        // Make validation label blink/highlight
        blinkValidationLabel()
    }
    
    private func blinkValidationLabel() {
        // Stop any existing animations
        validationLbl.layer.removeAllAnimations()
        
        // Reset to visible
        validationLbl.alpha = 1
        
        // Blink animation
        UIView.animate(withDuration: 0.3, delay: 0, options: [.autoreverse, .repeat], animations: {
            // Repeat 3 times for good visibility
            UIView.setAnimationRepeatCount(3)
            self.validationLbl.alpha = 0.3
        }) { _ in
            // After blinking, keep it visible
            self.validationLbl.alpha = 1
        }
        
        // Add shake animation
        let shakeAnimation = CABasicAnimation(keyPath: "position")
        shakeAnimation.duration = 0.07
        shakeAnimation.repeatCount = 3
        shakeAnimation.autoreverses = true
        shakeAnimation.fromValue = NSValue(cgPoint: CGPoint(x: validationLbl.center.x - 5, y: validationLbl.center.y))
        shakeAnimation.toValue = NSValue(cgPoint: CGPoint(x: validationLbl.center.x + 5, y: validationLbl.center.y))
        validationLbl.layer.add(shakeAnimation, forKey: "position")
    }
    
    private func hideValidationError() {
        // Stop animations
        validationLbl.layer.removeAllAnimations()
        
        UIView.animate(withDuration: 0.3, animations: {
            self.validationLbl.alpha = 0
        }) { _ in
            self.validationLbl.isHidden = true
        }
    }
    
    private func showCustomTimeInputAlert() {
        let alert = UIAlertController(
            title: "Enter Custom Time",
            message: "Enter time in seconds (minimum 5 seconds)",
            preferredStyle: .alert
        )
        
        alert.addTextField { textField in
            textField.placeholder = "Enter seconds"
            textField.keyboardType = .numberPad
            textField.text = self.customEnteredSeconds > 0 ? "\(self.customEnteredSeconds)" : ""
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        alert.addAction(UIAlertAction(title: "Set", style: .default, handler: { [weak self] _ in
            guard let self = self,
                  let text = alert.textFields?.first?.text,
                  !text.isEmpty,
                  let seconds = Int(text) else {
                self?.showValidationError(message: "* Please enter a valid number.")
                return
            }
            
            if seconds < 5 {
                self.showValidationError(message: "* Min 5 seconds required.")
                return
            }
            
            self.customEnteredSeconds = seconds
            self.currentTime = seconds
            self.selectedTimeType = .custom
            self.hideValidationError()
            self.updateUIForSelectedTime()
        }))
        
        self.present(alert, animated: true, completion: nil)
    }
}

// MARK: - Button Actions
extension PhotoCastSlideTimmerPopUpVC {
    @IBAction func sevenSecondsBTTap(_ sender: Any) {
        selectedTimeType = .sevenSeconds
        currentTime = 7
        customEnteredSeconds = 0
        updateUIForSelectedTime()
        hideValidationError()
    }
    
    @IBAction func tenSecondsBTTap(_ sender: Any) {
        selectedTimeType = .tenSeconds
        currentTime = 10
        customEnteredSeconds = 0
        updateUIForSelectedTime()
        hideValidationError()
    }
    
    @IBAction func enterCustomBTTap(_ sender: Any) {
        showCustomTimeInputAlert()
    }
    
    @IBAction func startBTTap(_ sender: Any) {
        var selectedTime = 0
        
        switch selectedTimeType {
        case .sevenSeconds:
            selectedTime = 7
        case .tenSeconds:
            selectedTime = 10
        case .custom:
            if customEnteredSeconds == 0 {
                showValidationError(message: "* Please set custom time first.")
                return // Don't dismiss if validation fails
            }
            
            // Check if custom time is less than 5 seconds
            if customEnteredSeconds < 5 {
                showValidationError(message: "* Min 5 seconds required.")
                return // Don't dismiss if validation fails
            }
            
            selectedTime = customEnteredSeconds
        }
        
        // Only dismiss if all validations pass
        hideValidationError()
        onTimeSelected?(selectedTime)
        dismiss()
    }
    
    @IBAction func closePopUpBTTap(_ sender: Any) {
        dismiss()
    }
}
