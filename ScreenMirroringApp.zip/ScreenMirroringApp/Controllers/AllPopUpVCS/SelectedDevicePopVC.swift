//
//  SelectedDevicePopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import SwiftPopup

protocol SelectedDevice {
    func Device(isSelected:Bool)
}
class SelectedDevicePopVC: SwiftPopup {

    var delegate:SelectedDevice?
    var onDismiss: (() -> Void)?
    var tvSelect: (() -> Void)?
    var phoneSelect: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    
    @IBAction func tvDeviceButtonTap(_ sender: UIButton) {
        self.tvSelect?()
    }
    
    @IBAction func phoneButtonTap(_ sender: UIButton) {
        self.phoneSelect?()
    }
    
    @IBAction func closeButtonTap(_ sender: UIButton) {
        self.onDismiss?()
    }
}
