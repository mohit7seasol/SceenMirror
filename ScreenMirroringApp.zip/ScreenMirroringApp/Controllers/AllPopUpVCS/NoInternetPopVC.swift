//
//  NoInternetPopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import SwiftPopup

class NoInternetPopVC: SwiftPopup {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss()
    }
}
