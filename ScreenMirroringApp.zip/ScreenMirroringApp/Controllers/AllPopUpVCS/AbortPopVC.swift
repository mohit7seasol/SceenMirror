//
//  AbortPopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit

class AbortPopVC: UIViewController {
    var tvName : String = "TV"
    var onAbortTV: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
