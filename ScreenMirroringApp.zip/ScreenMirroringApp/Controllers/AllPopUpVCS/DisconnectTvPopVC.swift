//
//  DisconnectTvPopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import SwiftPopup
import Lottie

class DisconnectTvPopVC: SwiftPopup {
    @IBOutlet weak var lottieAnimatedView: UIView!
    
    var subTitle : String?
    var onDisconnect: (() -> Void)?
    var closeHandler: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playLottie()
    }
    
    func playLottie() {
        let animationView = LottieAnimationView()
        let animation = LottieAnimation.named("Disconnect")
        animationView.animation = animation
        animationView.frame = lottieAnimatedView.bounds
        animationView.loopMode = .loop
        self.lottieAnimatedView.addSubview(animationView)
        animationView.play()
    }
    @IBAction func closeButtonTap(_ sender: Any) {
        closeHandler?()
        dismiss()
    }
    
    @IBAction func disconnectButtonTap(_ sender: Any) {
        onDisconnect?()
        dismiss()
    }
    
}
