//
//  PhotoQualityPopUpVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 02/01/26.
//

import UIKit
import SwiftPopup

class PhotoQualityPopUpVC: SwiftPopup {

    @IBOutlet weak var pickLbl: UILabel!
    @IBOutlet weak var pickTheLbl: UILabel!
    @IBOutlet weak var origionalLbl: UILabel!
    @IBOutlet weak var mediumLbl: UILabel!
    @IBOutlet weak var highLbl: UILabel!
    
    @IBOutlet weak var origionalSelectedBGImageView: UIImageView!
    @IBOutlet weak var mediumSelectedBGImageView: UIImageView!
    @IBOutlet weak var highSelectedBGImageView: UIImageView!
    
    // Callback for quality selection
    var onQualitySelected: ((CGFloat) -> Void)?
    var currentQuality: CGFloat = 1.0 // Default to original
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    func setUI() {
        // Set initial selection based on currentQuality
        updateUIForSelectedQuality()
    }
    
    private func updateUIForSelectedQuality() {
        // Reset all to unselected first
        origionalSelectedBGImageView.image = UIImage(named: "quality_unselected")
        mediumSelectedBGImageView.image = UIImage(named: "quality_unselected")
        highSelectedBGImageView.image = UIImage(named: "quality_unselected")
        
        origionalLbl.textColor = UIColor(hex: "#A6A6AC")
        mediumLbl.textColor = UIColor(hex: "#A6A6AC")
        highLbl.textColor = UIColor(hex: "#A6A6AC")
        
        // Set selected based on currentQuality
        if currentQuality == 1.0 {
            origionalSelectedBGImageView.image = UIImage(named: "quality_selected")
            origionalLbl.textColor = .white
        } else if currentQuality == 0.7 { // Assuming 0.7 for high
            highSelectedBGImageView.image = UIImage(named: "quality_selected")
            highLbl.textColor = .white
        } else if currentQuality == 0.5 { // Assuming 0.5 for medium
            mediumSelectedBGImageView.image = UIImage(named: "quality_selected")
            mediumLbl.textColor = .white
        }
    }
}

// MARK: - Button Actions
extension PhotoQualityPopUpVC {
    
    @IBAction func closePopUpTap(_ sender: Any) {
        dismiss()
    }
    
    @IBAction func origionalQualityBTTap(_ sender: UIButton) {
        currentQuality = 1.0
        updateUIForSelectedQuality()
        onQualitySelected?(currentQuality)
        dismiss()
    }
    
    @IBAction func mediumQualityBTTap(_ sender: UIButton) {
        currentQuality = 0.5
        updateUIForSelectedQuality()
        onQualitySelected?(currentQuality)
        dismiss()
    }
    
    @IBAction func highQualityBTTap(_ sender: UIButton) {
        currentQuality = 0.7
        updateUIForSelectedQuality()
        onQualitySelected?(currentQuality)
        dismiss()
    }
}
