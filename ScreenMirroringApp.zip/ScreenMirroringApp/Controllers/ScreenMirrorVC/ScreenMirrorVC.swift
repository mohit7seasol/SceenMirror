//
//  ScreenMirrorVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import Lottie
import ReplayKit
import AVKit

var isMirrorOn: Bool = false

class ScreenMirrorVC: UIViewController {

    @IBOutlet weak var navigationTitleLabel: UILabel!
    @IBOutlet weak var connectedDeviceLabel: UILabel!
    @IBOutlet weak var connectButton: UIButton!
    @IBOutlet weak var mirrorScreenLabel: UILabel!
    @IBOutlet weak var mirroScreenTitleLabel: UILabel!
    @IBOutlet weak var playOrigionalLabel: UILabel!
    @IBOutlet weak var playOrigionalBackgroundSelectedImageView: UIImageView!
    @IBOutlet weak var playOrigionalSelectedDotImageView: UIImageView!
    @IBOutlet weak var playMediumBackgroundSelectedImageView: UIImageView!
    @IBOutlet weak var playMediumSelectedDotImageView: UIImageView!
    @IBOutlet weak var playMediumLabel: UILabel!
    @IBOutlet weak var playHeighLabel: UILabel!
    @IBOutlet weak var playHeighBackgroundSelectedImageView: UIImageView!
    @IBOutlet weak var playHeighSelectedDotImageView: UIImageView!
    @IBOutlet weak var lottieAnimatedView: UIView!
    @IBOutlet weak var displayTvButton: UIButton!
    @IBOutlet weak var playOrigionalButton: UIButton!
    @IBOutlet weak var playMediumButton: UIButton!
    @IBOutlet weak var playHighButton: UIButton!
    @IBOutlet weak var displayOnTvView: UIView!
    
    var lottieFileName = "Connect to tv"
    private var animationView: LottieAnimationView?
    
    // Enum for quality selection
    enum VideoQuality {
        case original
        case medium
        case high
    }
    
    private var selectedQuality: VideoQuality = .original
    
    // Add commonViewModel property
    var commonViewModel: CommonViewModel?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        setLoca()
        setupLottieAnimation()
        setupDefaultSelection()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateButtonState()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        animationView?.play()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        animationView?.pause()
    }
    
    func setUpUI() {
        // Initialize broadcast session manager if needed
        if getConnectedTvType() == .GcastTV {
            if let commonViewModel = commonViewModel {
                broadcastSessionManager = BroadcastSessionManager(commonViewModel: commonViewModel)
            }
        }
        
        // Save quality setting
        if let userDefaults = UserDefaults(suiteName: AppStrings.groupID) {
            let qualityString = selectedQuality == .original ? "Low" : (selectedQuality == .medium ? "Medium" : "High")
            userDefaults.set(qualityString, forKey: "selectedQuality")
        }
        
        // Screen capture notification observer - CORRECTED
        NotificationCenter.default.addObserver(
            forName: UIScreen.capturedDidChangeNotification,
            object: UIScreen.main,
            queue: OperationQueue.main
        ) { [weak self] notification in
            guard let self = self else { return }
            
            let isCaptured = UIScreen.main.isCaptured
            print("isCaptured - \(isCaptured)")
            
            if isCaptured {
                isMirrorOn = true
                self.displayTvButton.setTitle("Stop Screen Mirroring".localized(), for: .normal)
                self.displayTvButton.isUserInteractionEnabled = false
                
                if selectedTvType == .AirPlay || checkAirPlayStatus() {
                    // AirPlay handling
                    self.displayTvButton.isUserInteractionEnabled = true
                } else {
                    self.displayOnTvView.addSubview(self.addrecord())
                }
                
                if selectedTvType == .noneTV {
                    // Show device list if no TV connected
                    self.showDeviceList()
                } else {
                    // Start mirroring based on connected TV type
                    self.startMirroringBasedOnTVType()
                }
            } else {
                // Screen mirroring stopped
                isMirrorOn = false
                self.displayTvButton.setTitle("Display on TV".localized(), for: .normal)
                self.displayTvButton.isUserInteractionEnabled = true
                
                // Remove broadcast picker views
                for subview in self.displayOnTvView.subviews {
                    if let _ = subview as? RPSystemBroadcastPickerView {
                        subview.removeFromSuperview()
                    }
                }
            }
        }
    }
    
    func setLoca() {
        self.navigationTitleLabel.text = "Mirror Screen To TV".localized(LocalizationService.shared.language)
        self.connectButton.setTitle("Connect".localized(LocalizationService.shared.language), for: .normal)
        self.mirrorScreenLabel.text = "Mirror Screen To TV".localized(LocalizationService.shared.language)
        self.mirroScreenTitleLabel.text = "Mirror Screen To TV".localized(LocalizationService.shared.language)
        self.playOrigionalLabel.text = "Play Original Quality".localized(LocalizationService.shared.language)
        self.playMediumLabel.text = "Play Medium Quality".localized(LocalizationService.shared.language)
        self.playHeighLabel.text = "Play High Quality".localized(LocalizationService.shared.language)
        self.displayTvButton.setTitle("Display on TV".localized(LocalizationService.shared.language), for: .normal)
    }
    
    // MARK: - Lottie Animation Setup
    private func setupLottieAnimation() {
        animationView = LottieAnimationView(name: lottieFileName)
        animationView?.frame = lottieAnimatedView.bounds
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.animationSpeed = 1.0
        
        if let animationView = animationView {
            lottieAnimatedView.addSubview(animationView)
            
            animationView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                animationView.topAnchor.constraint(equalTo: lottieAnimatedView.topAnchor),
                animationView.bottomAnchor.constraint(equalTo: lottieAnimatedView.bottomAnchor),
                animationView.leadingAnchor.constraint(equalTo: lottieAnimatedView.leadingAnchor),
                animationView.trailingAnchor.constraint(equalTo: lottieAnimatedView.trailingAnchor)
            ])
            
            animationView.play()
        }
    }
    
    // MARK: - Quality Selection Setup
    private func setupDefaultSelection() {
        selectedQuality = .original
        updateQualitySelectionUI()
        saveSelectedQuality()
    }
    
    private func updateQualitySelectionUI() {
        playOrigionalBackgroundSelectedImageView.image = UIImage(named: "mirror_unselected")
        playOrigionalSelectedDotImageView.image = UIImage(named: "unselected_dot")
        
        playMediumBackgroundSelectedImageView.image = UIImage(named: "mirror_unselected")
        playMediumSelectedDotImageView.image = UIImage(named: "unselected_dot")
        
        playHeighBackgroundSelectedImageView.image = UIImage(named: "mirror_unselected")
        playHeighSelectedDotImageView.image = UIImage(named: "unselected_dot")
        
        switch selectedQuality {
        case .original:
            playOrigionalBackgroundSelectedImageView.image = UIImage(named: "mirror_selected")
            playOrigionalSelectedDotImageView.image = UIImage(named: "selected_dot")
            
        case .medium:
            playMediumBackgroundSelectedImageView.image = UIImage(named: "mirror_selected")
            playMediumSelectedDotImageView.image = UIImage(named: "selected_dot")
            
        case .high:
            playHeighBackgroundSelectedImageView.image = UIImage(named: "mirror_selected")
            playHeighSelectedDotImageView.image = UIImage(named: "selected_dot")
        }
    }
    
    // MARK: - Quality Selection Methods
    private func selectOriginalQuality() {
        selectedQuality = .original
        updateQualitySelectionUI()
        saveSelectedQuality()
        print("Selected: Original Quality")
    }
    
    private func selectMediumQuality() {
        selectedQuality = .medium
        updateQualitySelectionUI()
        saveSelectedQuality()
        print("Selected: Medium Quality")
    }
    
    private func selectHighQuality() {
        selectedQuality = .high
        updateQualitySelectionUI()
        saveSelectedQuality()
        print("Selected: High Quality")
    }
    
    // MARK: - Helper Methods
    private func saveSelectedQuality() {
        let qualityString: String
        let selectedQualityIndex: Int
        
        switch selectedQuality {
        case .original:
            qualityString = "Low"
            selectedQualityIndex = 0
        case .medium:
            qualityString = "Medium"
            selectedQualityIndex = 1
        case .high:
            qualityString = "High"
            selectedQualityIndex = 2
        }
        
        if let userDefaults = UserDefaults(suiteName: AppStrings.groupID) {
            userDefaults.set(qualityString, forKey: "selectedQuality")
            // Also save the index if needed elsewhere
            userDefaults.set(selectedQualityIndex, forKey: "selectedQualityIndex")
        }
    }
    
    private func loadSelectedQuality() {
        if let userDefaults = UserDefaults(suiteName: AppStrings.groupID),
           let savedQuality = userDefaults.string(forKey: "selectedQuality") {
            switch savedQuality {
            case "Low":
                selectedQuality = .original
            case "Medium":
                selectedQuality = .medium
            case "High":
                selectedQuality = .high
            default:
                selectedQuality = .original
            }
            updateQualitySelectionUI()
        }
    }
    
    // MARK: - Helper Methods
    private func updateButtonState() {
        if isMirrorOn {
            displayTvButton.isUserInteractionEnabled = false
            if selectedTvType == .AirPlay || checkAirPlayStatus() {
                displayTvButton.isUserInteractionEnabled = true
            } else {
                displayOnTvView.addSubview(addrecord())
            }
        } else {
            displayTvButton.isUserInteractionEnabled = true
        }
    }
    
    private func showDeviceList() {
        let vc: ListDeviceVc = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
        vc.onConnect = { [weak self] in
            guard let self = self else { return }
            if self.commonViewModel?.getConnectedTvType() == .GcastTV {
                if let commonViewModel = self.commonViewModel {
                    broadcastSessionManager = BroadcastSessionManager(commonViewModel: commonViewModel)
                }
            } else {
                if let url = MirroringServer.shared.serverURL {
                    self.commonViewModel?.connectSDKDiscoveryModel.LGMirroring(mediaURL: url)
                }
            }
        }
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    private func startMirroringBasedOnTVType() {
        if selectedTvType == .AirPlay || checkAirPlayStatus() {
            // AirPlay - no additional setup needed
        } else if commonViewModel?.getConnectedTvType() == .GcastTV {
            if let commonViewModel = commonViewModel {
                broadcastSessionManager = BroadcastSessionManager(commonViewModel: commonViewModel)
            }
        } else {
            // LG TV mirroring
            if let url = MirroringServer.shared.serverURL {
                print("serverURL - \(url)")
                commonViewModel?.connectSDKDiscoveryModel.LGMirroring(mediaURL: url)
            }
        }
    }
}

// MARK: - Button Actions
extension ScreenMirrorVC {
    
    @IBAction func backButtonTap(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func fAQButtonTap(_ sender: Any) {
        print("FAQ button tapped")
    }
    
    @IBAction func mirroScreenSwitchTap(_ sender: UISwitch) {
        print("Mirror screen switch: \(sender.isOn ? "ON" : "OFF")")
        
        playOrigionalButton.isEnabled = sender.isOn
        playMediumButton.isEnabled = sender.isOn
        playHighButton.isEnabled = sender.isOn
        displayTvButton.isEnabled = sender.isOn
        
        if !sender.isOn && isMirrorOn {
            isMirrorOn = false
            displayTvButton.setTitle("Display on TV".localized(), for: .normal)
            displayTvButton.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func playOrigionalQualityTap(_ sender: Any) {
        selectOriginalQuality()
    }
    
    @IBAction func playMediumQualityTap(_ sender: Any) {
        selectMediumQuality()
    }
    
    @IBAction func playHighQualityTap(_ sender: Any) {
        selectHighQuality()
    }
    
    @IBAction func displayOnTvTap(_ sender: Any) {
        print("Display on TV tapped with quality: \(selectedQuality)")
        
        // Save the selected quality
        saveSelectedQuality()
        
        // Button animation from reference code
        UIView.animate(withDuration: 0.15, animations: {
            self.displayOnTvView.transform = CGAffineTransform(scaleX: 1.2, y: 1.2)
        }) { _ in
            UIView.animate(withDuration: 0.15) {
                self.displayOnTvView.transform = .identity
            }
        }
        
        // Logic from reference code's mirrorTapped (without subscription check)
//        if selectedTvType == .LGTV || selectedTvType == .GcastTV || checkAirPlayStatus() {
//            // Show AirPlay instructions
//            mirrorView()
//        } else {
            // Add broadcast picker view
            displayTvButton.isUserInteractionEnabled = false
            displayOnTvView.addSubview(addrecord())
            
            // Update UI to show mirroring is starting
            displayTvButton.setTitle("Starting Mirroring...".localized(), for: .normal)
//        }
    }
    
    @IBAction func connectedTvListTap(_ sender: Any) {
        print("Connected TV list tapped")
        showDeviceList()
    }
}

// MARK: - TV Connection Methods
extension ScreenMirrorVC {
    func addrecord() -> RPSystemBroadcastPickerView {
        let broadcastPicker = RPSystemBroadcastPickerView(frame: displayOnTvView.bounds)
        broadcastPicker.preferredExtension = AppStrings.appExtensionPackageName
        broadcastPicker.showsMicrophoneButton = false
        for subview in broadcastPicker.subviews {
            if let button = subview as? UIButton {
                button.setImage(nil, for: .normal)
            }
        }
        return broadcastPicker
    }
    
    func getConnectedTvType() -> TVType? {
        guard commonViewModel != nil else {
            print("commonViewModel is not initialized")
            return nil
        }
        return commonViewModel?.getConnectedTvType()
    }
    
    func mirrorView() {
        let message = "1) Swipe down from the top-right corner of your screen.".localized() + "\n" + "2) Tap 'Screen Mirroring'".localized() + "\n" + "3) Select your device.".localized()
        let alert = UIAlertController(title: "Screen Mirroring Using AirPlay".localized(), message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        DispatchQueue.main.async(execute: {
            self.present(alert, animated: true)
        })
    }
    func checkAirPlayStatus() -> Bool {
        let audioSession = AVAudioSession.sharedInstance()
        let currentRoute = audioSession.currentRoute
        
        for output in currentRoute.outputs {
            if output.portType == .airPlay {
                return true
            }
        }
        return false
    }
}
