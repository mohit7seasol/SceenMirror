//
//  QueueCastVc.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 13/01/26.
//

import UIKit
import SwiftPopup

class QueueCastVc: SwiftPopup {

    @IBOutlet weak var resolutionTV: UITableView! {
        didSet {
            resolutionTV.delegate = self
            resolutionTV.dataSource = self
            resolutionTV.register(UINib.init(nibName: QueueCastCell.className, bundle: nil), forCellReuseIdentifier: QueueCastCell.className)
        }
    }
    // MARK: - Variables
    
    var videoList = [VideoResolution]()
    var type = Int() // 1: YouTube, 2: Vimeo, 3: BuzzVideos, 4: IMDb
    var callBack: ((_ modal: [VideoResolution], _ selectedIndex: Int) -> Void)?
    private var thumbnailCache = [String: UIImage]()
    
    // MARK: - Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        loadThumbnails()
    }
    
    // MARK: - Methods
    
    func initView() {
        // Configure table view
        resolutionTV.separatorStyle = .singleLine
        resolutionTV.separatorInset = UIEdgeInsets(top: 0, left: 16, bottom: 0, right: 16)
        resolutionTV.tableFooterView = UIView()
    }
    
    func loadThumbnails() {
        for video in videoList {
            if !video.videothumImage.isEmpty && thumbnailCache[video.videothumImage] == nil {
                loadThumbnailImage(from: video.videothumImage)
            }
        }
        resolutionTV.reloadData()
    }
    
    func loadThumbnailImage(from urlString: String) {
        guard let url = URL(string: urlString) else { return }
        
        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self.thumbnailCache[urlString] = image
                        self.resolutionTV.reloadData()
                    }
                }
            }
        }
    }
    
    func getVideoQualityTitle(for resolution: String) -> String {
        switch resolution.lowercased() {
        case "1080p", "1080":
            return "HD 1080p"
        case "720p", "720":
            return "HD 720p"
        case "480p", "480":
            return "SD 480p"
        case "360p", "360":
            return "SD 360p"
        case "240p", "240":
            return "SD 240p"
        default:
            return resolution
        }
    }
    
    func getPlatformIcon() -> UIImage? {
        switch type {
        case 1: // YouTube
            return UIImage(systemName: "play.rectangle.fill")?.withTintColor(.red, renderingMode: .alwaysOriginal)
        case 2: // Vimeo
            return UIImage(systemName: "play.circle.fill")?.withTintColor(.systemBlue, renderingMode: .alwaysOriginal)
        case 3: // BuzzVideos
            return UIImage(systemName: "video.fill")?.withTintColor(.orange, renderingMode: .alwaysOriginal)
        case 4: // IMDb
            return UIImage(systemName: "film.fill")?.withTintColor(.yellow, renderingMode: .alwaysOriginal)
        default:
            return UIImage(systemName: "play.circle.fill")
        }
    }
    
    // MARK: - Actions
    
    @IBAction func closeButtonTapped(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}

// MARK: - UITableView Delegate & DataSource

extension QueueCastVc: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return videoList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: QueueCastCell.className, for: indexPath) as! QueueCastCell
        
        let video = videoList[indexPath.row]
        
        // Set title
        if !video.videoName.isEmpty {
            cell.lblTitles.text = video.videoName
        } else {
            cell.lblTitles.text = "Video \(indexPath.row + 1)"
        }
        
        // Set subtitle (resolution)
        cell.lblSubtitles.text = getVideoQualityTitle(for: video.videoResolution)
        cell.lblSubtitles.textColor = .white
        cell.lblSubtitles.backgroundColor = .systemBlue
        cell.lblSubtitles.layer.cornerRadius = 4
        cell.lblSubtitles.clipsToBounds = true
        cell.lblSubtitles.textAlignment = .center
        
        // Adjust subtitle size based on text length
        let textSize = video.videoResolution.size(withAttributes: [.font: cell.lblSubtitles.font!])
        cell.lblSubtitles.widthAnchor.constraint(equalToConstant: textSize.width + 16).isActive = true
        
        // Set thumbnail image
        if !video.videothumImage.isEmpty, let cachedImage = thumbnailCache[video.videothumImage] {
            cell.imgIcons.image = cachedImage
        } else {
            // Set platform icon as placeholder
            cell.imgIcons.image = getPlatformIcon()
        }
        
        // Configure image view
        cell.imgIcons.contentMode = .scaleAspectFill
        cell.imgIcons.layer.cornerRadius = 8
        cell.imgIcons.clipsToBounds = true
        cell.imgIcons.layer.borderWidth = 1
        cell.imgIcons.layer.borderColor = UIColor.lightGray.withAlphaComponent(0.3).cgColor
        
        // Add video duration if available (you can add this to VideoResolution struct if needed)
        // cell.lblDuration.text = formatDuration(video.duration)
        
        cell.selectionStyle = .default
        cell.accessoryType = .disclosureIndicator
        cell.backgroundColor = .white
        cell.layer.cornerRadius = 8
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        // Call the callback with selected video and index
        callBack?(videoList, indexPath.row)
        
        // Dismiss the popup
        dismiss(animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.width, height: 50))
        headerView.backgroundColor = .clear
        
        let titleLabel = UILabel(frame: CGRect(x: 10, y: 0, width: tableView.frame.width - 32, height: 50))
        titleLabel.text = getPlatformTitle()
        titleLabel.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        titleLabel.textColor = .white
        
        headerView.addSubview(titleLabel)
        return headerView
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 50
    }
    
    private func getPlatformTitle() -> String {
        switch type {
        case 1:
            return "YouTube Videos"
        case 2:
            return "Vimeo Videos"
        case 3:
            return "Buzz Videos"
        case 4:
            return "IMDb Videos"
        default:
            return "Available Videos"
        }
    }
}
