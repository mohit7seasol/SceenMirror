import UIKit

class QueueCastCell: UITableViewCell {
    
    @IBOutlet var imgIcons: UIImageView!
    @IBOutlet var lblTitles: UILabel!
    @IBOutlet var lblSubtitles: UILabel!
    
    

    override func awakeFromNib() {
        super.awakeFromNib()
        lblSubtitles.layer.cornerRadius = 4
    }

   
    
}
