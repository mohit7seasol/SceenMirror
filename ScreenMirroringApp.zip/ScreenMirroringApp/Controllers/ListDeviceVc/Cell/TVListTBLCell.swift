//
//  TVListTBLCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit

class TVListTBLCell: UITableViewCell {

    @IBOutlet weak var tvNameLabel: UILabel!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var tvSelectedBackgroundImageView: UIImageView!
    @IBOutlet weak var tvStatusImageView: UIImageView!

    override func awakeFromNib() {
        super.awakeFromNib()
    }
}
extension UIView {
    /// Animates a solid color filling this view from left to right.
    func animateFillLeftToRight(color: UIColor,
                                duration: TimeInterval = 0.8,
                                keepFilledAfter: Bool = true) {
        // Create the fill layer with zero width
        let fillLayer = CALayer()
        fillLayer.backgroundColor = color.cgColor
        fillLayer.frame = CGRect(x: 0, y: 0, width: 0, height: bounds.height)
        layer.sublayers?.removeAll()
        layer.addSublayer(fillLayer)
        // Animate the width of the layer’s bounds
        let anim = CABasicAnimation(keyPath: "bounds.size.width")
        anim.fromValue = 0
        anim.toValue = self.frame.size.width+self.frame.size.width
        anim.duration = duration
        anim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)

        // Set final state so it stays at 100% after animation (if requested)
        fillLayer.bounds.size.width = self.frame.size.width+self.frame.size.width
        fillLayer.add(anim, forKey: "fillLeftToRight")

        if !keepFilledAfter {
            // Remove the layer when done (optional)
            DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
                fillLayer.removeFromSuperlayer()
            }
        }
    }
}
