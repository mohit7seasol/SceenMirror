//
//  WebStreamVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 09/01/26.
//

import UIKit

class WebStreamVC: UIViewController {
    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var pintrestLbl: UILabel!
    @IBOutlet weak var fbLbl: UILabel!
    @IBOutlet weak var redItLbl: UILabel!
    @IBOutlet weak var instaLbl: UILabel!
    @IBOutlet weak var tikTokLbl: UILabel!
    @IBOutlet weak var twitterLbl: UILabel!
    @IBOutlet weak var linkedInLbl: UILabel!
    @IBOutlet weak var youtubeLbl: UILabel!
    @IBOutlet weak var telegramLbl: UILabel!
    
    @IBOutlet weak var pintrestView: UIView!
    @IBOutlet weak var fbView: UIView!
    @IBOutlet weak var redItView: UIView!
    @IBOutlet weak var instaView: UIView!
    @IBOutlet weak var tikTokView: UIView!
    @IBOutlet weak var twitterView: UIView!
    @IBOutlet weak var linkedInView: UIView!
    @IBOutlet weak var youtubeView: UIView!
    @IBOutlet weak var telegramView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    func setUI() {
        setSearchbar()
        setAllViewTappes()
    }
    func setSearchbar() {
        let searchBarHeight: CGFloat = 48.0
        let cornerRadius: CGFloat = searchBarHeight / 2
        
        SearchTextFieldStyle.apply(
            to: searchBar,
            placeholder: "Search here...",
            leftIcon: UIImage(named: "search_ic"),
            height: searchBarHeight,
            cornerRadius: cornerRadius,
            showClearButton: true
        )
        
        searchBar.delegate = self
        searchBar.addTarget(self, action: #selector(searchTextChanged(_:)), for: .editingChanged)
    }
    func setAllViewTappes() {
        pintrestView.setOnClickListener { [self] in
            openBroswer(url: "https://www.pinterest.com/", appname: "Pintrest")
        }
        
        fbView.setOnClickListener { [self] in
            openBroswer(url: "https://www.facebook.com/", appname: "Facebook")
        }
        
        redItView.setOnClickListener { [self] in
            openBroswer(url: "https://www.reddit.com/", appname: "Reddit")
        }
        
        instaView.setOnClickListener { [self] in
            openBroswer(url: "https://www.instagram.com/", appname: "Instagram")
        }
        
        tikTokView.setOnClickListener { [self] in
            openBroswer(url: "https://www.tiktok.com/en/", appname: "Tiktok")
        }
        
        twitterView.setOnClickListener { [self] in
            openBroswer(url: "https://x.com/", appname: "Twitter")
        }
        
        linkedInView.setOnClickListener { [self] in
            openBroswer(url: "https://linkedin.com/", appname: "Linkedin")
        }
        
        youtubeView.setOnClickListener { [self] in
            openBroswer(url: "https://www.youtube.com/", appname: "Youtube")
        }
        
        telegramView.setOnClickListener { [self] in
            openBroswer(url: "https://web.telegram.org/", appname: "Telegram")
        }
    }
    
    func openBroswer(url: String, appname: String) {
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "BrowserVC") as? BrowserVC else { return }
        vc.appname = appname
        vc.selectedURL = url
        navigationController?.pushViewController(vc, animated: true)
    }
    func openSearchInBrowserVC(searchText: String) {

        let finalURL: String

        if searchText.lowercased().hasPrefix("http://") ||
           searchText.lowercased().hasPrefix("https://") {

            // Full URL entered
            finalURL = searchText

        } else if searchText.contains(".") && !searchText.contains(" ") {

            // Domain like google.com
            finalURL = "https://\(searchText)"

        } else {

            // Normal search query
            let encoded = searchText.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? searchText
            finalURL = "https://www.google.com/search?q=\(encoded)"
        }

        guard let vc = storyboard?.instantiateViewController(
            withIdentifier: "BrowserVC"
        ) as? BrowserVC else { return }

        vc.selectedURL = finalURL
        vc.appname = "Search"
        self.searchBar.text = ""
        navigationController?.pushViewController(vc, animated: true)
    }
}
// MARK: - UITextField Delegate
extension WebStreamVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()

        let text = textField.text?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        guard !text.isEmpty else { return true }

        openSearchInBrowserVC(searchText: text)
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }
}
extension WebStreamVC {
    @objc func searchTextChanged(_ textField: UITextField) {
    }
    
    @IBAction func backButtonTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
}
