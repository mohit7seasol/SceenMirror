//
//  HomeVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 16/12/25.
//

import UIKit

class HomeVC: UIViewController {

    @IBOutlet weak var screenLabel: UILabel!
    @IBOutlet weak var mirroringLabel: UILabel!
    @IBOutlet weak var mirrorPhoneLabel: UILabel!
    @IBOutlet weak var premiumButton: UIButton!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var startLabel: UILabel!
    @IBOutlet weak var mirroringLabel2: UILabel!
    @IBOutlet weak var tapLabel: UILabel!
    @IBOutlet weak var connectLabel: UILabel!
    @IBOutlet weak var tvCastTitleLabel: UILabel!
    @IBOutlet weak var tvCastLabel: UILabel!
    @IBOutlet weak var videosLabel: UILabel!
    @IBOutlet weak var musicLabel: UILabel!
    @IBOutlet weak var webCastView: UIView!
    @IBOutlet weak var webCastLabel: UILabel!
    @IBOutlet weak var fbLabel: UILabel!
    @IBOutlet weak var tikLabel: UILabel!
    @IBOutlet weak var imdbLabel: UILabel!
    @IBOutlet weak var moreLabel: UILabel!
    @IBOutlet weak var youtubeLabel: UILabel!
    @IBOutlet weak var iptvLabel: UILabel!
    @IBOutlet weak var youtubeView: UIView!
    @IBOutlet weak var iptvView: UIView!
    @IBOutlet weak var tapToConnectView: UIView!
    @IBOutlet weak var startMirroringView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
    }
    func setUpUI() {
        setPrimaryUI()
    }
    func setPrimaryUI() {
        self.webCastView.layer.cornerRadius = 12
        self.webCastView.layer.borderColor = #colorLiteral(red: 0.2470588235, green: 0.5607843137, blue: 1, alpha: 1)
        self.webCastView.layer.borderWidth = 1
        
        self.youtubeView.layer.cornerRadius = 12
        self.youtubeView.layer.borderColor = #colorLiteral(red: 0.2470588235, green: 0.5607843137, blue: 1, alpha: 1)
        self.youtubeView.layer.borderWidth = 1
        
        self.iptvView.layer.cornerRadius = 12
        self.iptvView.layer.borderColor = #colorLiteral(red: 0.2470588235, green: 0.5607843137, blue: 1, alpha: 1)
        self.iptvView.layer.borderWidth = 1
        
    }
}
// MARK: - Button Actions
extension HomeVC {
    
    @IBAction func premiumButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func settingButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func startMirrorButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func tapToConnectButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func tvCastButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func videoButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func musicButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func facebookButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func tiktokButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func imdbButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func moreButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func youtubeButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func iptvButtonAction(_ sender: UIButton) {
    }
}
