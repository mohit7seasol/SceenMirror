//
//  HomeVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 16/12/25.
//

import UIKit
import BottomPopup
import NetworkExtension
import Network
import CoreLocation
import StoreKit
import Alamofire
import AVFAudio
import GoogleCast
import Lottie

var broadcastSessionManager: BroadcastSessionManager?

class HomeVC: UIViewController {

    @IBOutlet weak var screenLabel: UILabel!
    @IBOutlet weak var mirroringLabel: UILabel!
    @IBOutlet weak var mirrorPhoneLabel: UILabel!
    @IBOutlet weak var premiumButton: UIButton!
    @IBOutlet weak var settingButton: UIButton!
    @IBOutlet weak var statusLabel: UILabel!
    @IBOutlet weak var startLabel: UILabel!
    @IBOutlet weak var mirroringLabel2: UILabel!
    @IBOutlet weak var tapLabel: UILabel!
    @IBOutlet weak var connectLabel: UILabel!
    @IBOutlet weak var tvCastTitleLabel: UILabel!
    @IBOutlet weak var tvCastLabel: UILabel!
    @IBOutlet weak var videosLabel: UILabel!
    @IBOutlet weak var musicLabel: UILabel!
    @IBOutlet weak var webCastView: UIView!
    @IBOutlet weak var webCastLabel: UILabel!
    @IBOutlet weak var fbLabel: UILabel!
    @IBOutlet weak var tikLabel: UILabel!
    @IBOutlet weak var imdbLabel: UILabel!
    @IBOutlet weak var moreLabel: UILabel!
    @IBOutlet weak var youtubeLabel: UILabel!
    @IBOutlet weak var iptvLabel: UILabel!
    @IBOutlet weak var youtubeView: UIView!
    @IBOutlet weak var iptvView: UIView!
    @IBOutlet weak var tapToConnectView: UIView!
    @IBOutlet weak var startMirroringView: UIView!
    @IBOutlet weak var connectedDeviceNameLabel: UILabel!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var drawingAnimatedView: UIView!
    
    var googleNativeAds = GoogleNativeAds()
    var isShowNativeAds = false
    var allDevices: [DeviceType] {
        if commonViewModel != nil {
            let lg = commonViewModel.connectSDKDiscoveryModel.lgDevices.map { DeviceType.lg($0) }
            let cast = commonViewModel.castViewModel.devices.map { DeviceType.cast($0) }
            return lg + cast
        }else{
            return []
        }
        
    }
    var delegate: SelectedDevice?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        
        setUpUI()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        scrollView.contentInset = .zero
        scrollView.scrollIndicatorInsets = .zero
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.setNavigationBarHidden(true, animated: animated)
        requestLocalNetworkPermissionIfNeeded()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        languageChang()
        
        let selectedDevice = getSelectedTV()
        
        // Check if we need to reconnect to a previously connected device
        if !selectedDevice.isEmpty {
            DispatchQueue.main.async {
                for model in self.allDevices {
                    if selectedDevice == "LG-\(model.name)" || selectedDevice == "Gcast-\(model.name)" {
                        // Only reconnect if not already connected
                        if !commonViewModel.isDeviceConnected {
                            switch model {
                            case .lg(let lgDevice):
                                if let index = commonViewModel.connectSDKDiscoveryModel.lgDevices.firstIndex(of: lgDevice) {
                                    commonViewModel.connectSDKDiscoveryModel.isShowPopup = false
                                    commonViewModel.connectSDKDiscoveryModel.connectToLGDevice(at: index)
                                }
                            case .cast(let castDevice):
                                commonViewModel.castViewModel.connectToDevice(castDevice, isShowPopup: false)
                            }
                        }
                        break // Found the device, no need to continue
                    }
                }
            }
        }
        
        // Update UI with current connection status
        setTvName(tvName: updateConnectionUI())
    }
    
    func setUpUI() {
        setPrimaryUI()
        LocalNetworkAuthorization().requestAuthorization { granted in
            if granted {
                self.registerCastingInstance()
                commonViewModel = CommonViewModel()
                _ = CastingServer.shared
                _ = MirroringServer.shared
                commonViewModel.StopCasting()
                commonViewModel.castViewModel.selectedDevice = nil
                commonViewModel.connectSDKDiscoveryModel.selectedLGDevice = nil
                var allDevices: [DeviceType] {
                    let lg = commonViewModel.connectSDKDiscoveryModel.lgDevices.map { DeviceType.lg($0) }
                    let cast = commonViewModel.castViewModel.devices.map { DeviceType.cast($0) }
                    return lg + cast
                }
            } else {
                print("❌ Local Network permission denied")
            }
        }
    }
    
    func setPrimaryUI() {
        setupGif()
        self.webCastView.layer.cornerRadius = 12
        self.webCastView.layer.borderColor = #colorLiteral(red: 0.2470588235, green: 0.5607843137, blue: 1, alpha: 1)
        self.webCastView.layer.borderWidth = 1
        
        self.youtubeView.layer.cornerRadius = 12
        self.youtubeView.layer.borderColor = #colorLiteral(red: 0.2470588235, green: 0.5607843137, blue: 1, alpha: 1)
        self.youtubeView.layer.borderWidth = 1
        
        self.iptvView.layer.cornerRadius = 12
        self.iptvView.layer.borderColor = #colorLiteral(red: 0.2470588235, green: 0.5607843137, blue: 1, alpha: 1)
        self.iptvView.layer.borderWidth = 1
        
        self.startLabel.text = "Start"
        self.startLabel.textColor = .white
//        self.startMirroringView.addShadow(    color: UIColor(red: 0/255, green: 150/255, blue: 255/255, alpha: 1),
//                                              opacity: 0.7,
//                                              offset: CGSize(width: 0, height: 6),
//                                              radius: 22,
//                                              cornerRadius: startMirroringView.bounds.height / 2)
//        self.startMirroringView.clipsToBounds = true
    }
    func setupGif(){
        let animationView = LottieAnimationView()
        let animation = LottieAnimation.named("Drawing")
        animationView.animation = animation
        animationView.frame = drawingAnimatedView.bounds
        animationView.loopMode = .loop
        self.drawingAnimatedView.addSubview(animationView)
        animationView.play()
    }
    func languageChang() {
//        self.lblCastTv.text = "Screen Mirroring".localized()
//        self.lblDes1.text = "Confirm both TV and device share same WiFi for smooth communication.".localized()
//        self.lblHows.text = "How to cast your data on TV?".localized()
//        self.lblImageMi.text = "Image Casting".localized()
//        self.lblImageCast.text = "Cast Image now".localized()
//        self.lblVideoMi.text = "Video Casting".localized()
//        self.lblVideoCast.text = "Cast Video now".localized()
//        self.lblCastWeb.text = "Cast to Web".localized()
//        self.lblYoutube.text = "Youtube".localized()
//        self.lblWeb.text = "Web".localized()
//        self.lblIptv.text = "Live Tv".localized()
//        self.screenMirroringLabel.text = "Screen Mirroring".localized()
//        self.mirrorSubTitleLabel.text = "Mirror mobile display on TV".localized()
    }
    func requestLocalNetworkPermissionIfNeeded() {
        let hasRequested = UserDefaults.standard.bool(forKey: "HasRequestedLocalNetworkPermission")
        guard !hasRequested else { return }

        let browser = NWBrowser(for: .bonjour(type: "_googlecast._tcp", domain: nil), using: .tcp)
        browser.stateUpdateHandler = { state in
            switch state {
            case .ready:
                print("✅ Local network access granted")
                browser.cancel()
            case .failed(let error):
                print("❌ Local network access denied: \(error.localizedDescription)")
                browser.cancel()
            default:
                break
            }
        }
        browser.start(queue: .main)

        UserDefaults.standard.set(true, forKey: "HasRequestedLocalNetworkPermission")
    }
    func registerCastingInstance() {
        
        let criteria = GCKDiscoveryCriteria(applicationID: AppStrings.kCustomReceiverAppID)
        let initWithIds = Selector(("initWithApplicationIDs:"))
        
        if criteria.responds(to: initWithIds) {
            criteria.perform(initWithIds, with: NSOrderedSet(array: [kGCKDefaultMediaReceiverApplicationID, AppStrings.kCustomReceiverAppID]))
        }
        
        let options = GCKCastOptions(discoveryCriteria: criteria)
        GCKCastContext.setSharedInstanceWith(options)
        
        GCKLogger.sharedInstance().delegate = self
    }
    
    func startCastingSession() {
        if selectedTvType == .GcastTV{
            if let userDefaults = UserDefaults(suiteName: AppStrings.groupID){
                if userDefaults.bool(forKey: "isBroadcasting") == false {
                    broadcastSessionManager?.stopCastingSession()
                    DispatchQueue.main.async {
                        commonViewModel.castViewModel.startCastSession()
                    }
                }
            }
        }
    }
}
extension HomeVC : ChangeTVName{
    func setTvName(tvName: String) {
        // Case 1: Tap to Connect (no device)
        if tvName == "Tap to Connect" {
            statusLabel.text = "Connect"
            statusLabel.textColor = .white
            connectedDeviceNameLabel.text = tvName
            return
        }

        // Case 2: AirPlay device (prefix check)
        if tvName.hasPrefix("Airplay-") {
            statusLabel.text = "Connected"
            statusLabel.textColor = #colorLiteral(red: 0, green: 1, blue: 0.06666666667, alpha: 1)
            connectedDeviceNameLabel.text = tvName
            return
        }

        // Case 3: Any other connected device (LG / Gcast / etc.)
        statusLabel.text = "Connected"
        statusLabel.textColor = #colorLiteral(red: 0, green: 1, blue: 0.06666666667, alpha: 1)
        connectedDeviceNameLabel.text = tvName
    }
}
// MARK: - Button Actions
extension HomeVC {
    
    @IBAction func premiumButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func settingButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func startMirrorButtonAction(_ sender: UIButton) {
        if  !NetworkReachabilityManager()!.isReachable {
            showAlertMessage(titleStr: "Error!", messageStr: MESSAGE_ERR_NETWORK)
            return
        }
        if selectedTvType == .GcastTV{
            if commonViewModel.castViewModel.isCastingSessionGoing() {
                commonViewModel.castViewModel.stopCastingSession()
            }
        }
        let vc : ScreenMirrorVC =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ScreenMirrorVC") as! ScreenMirrorVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func tapToConnectButtonAction(_ sender: UIButton) {
        let vc : ListDeviceVc =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
        vc.tvDelegate = self
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func tvCastButtonAction(_ sender: UIButton) {
        if  !NetworkReachabilityManager()!.isReachable {
            showAlertMessage(titleStr: "Error!", messageStr: MESSAGE_ERR_NETWORK)
            return
        }
        self.startCastingSession()
        DispatchQueue.main.async {
            let vc : VideoAndPhotoListVC =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VideoAndPhotoListVC") as! VideoAndPhotoListVC
            vc.MEDIA_TYPE = .Photos
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func videoButtonAction(_ sender: UIButton) {
        if  !NetworkReachabilityManager()!.isReachable {
            showAlertMessage(titleStr: "Error!", messageStr: MESSAGE_ERR_NETWORK)
            return
        }
        self.startCastingSession()
        DispatchQueue.main.async {
            let vc : VideoAndPhotoListVC =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VideoAndPhotoListVC") as! VideoAndPhotoListVC
            vc.MEDIA_TYPE = .Videos
            self.navigationController?.pushViewController(vc, animated: true)
        }
    }
    
    @IBAction func musicButtonAction(_ sender: UIButton) { // CastMusicIntroVC
        if !NetworkReachabilityManager()!.isReachable {
            showAlertMessage(titleStr: "Error!", messageStr: MESSAGE_ERR_NETWORK)
            return
        }

        self.startCastingSession()

        DispatchQueue.main.async {
            let introVC = UIStoryboard(name: "Main", bundle: nil)
                .instantiateViewController(withIdentifier: "CastMusicIntroVC") as! CastMusicIntroVC

            introVC.homeViewController = self  // Add reference to HomeVC
            let nav = UINavigationController(rootViewController: introVC)
            nav.modalPresentationStyle = .fullScreen
            nav.navigationBar.isHidden = true

            self.present(nav, animated: true)
        }
    }
    
    @IBAction func facebookButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func tiktokButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func imdbButtonAction(_ sender: UIButton) {
    }
    
    @IBAction func moreButtonAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "WebStreamVC") as! WebStreamVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func youtubeButtonAction(_ sender: UIButton) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "YTBrowserVC") as! YTBrowserVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    @IBAction func iptvButtonAction(_ sender: UIButton) { // IPTVListVC
        let vc : IPTVListVC =  UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "IPTVListVC") as! IPTVListVC
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
extension HomeVC: GCKSessionManagerListener,GCKLoggerDelegate {

    func sessionManager(_ sessionManager: GCKSessionManager, didStart session: GCKSession) {
        print("Session started: \(session)")
    }

    func sessionManager(_ sessionManager: GCKSessionManager, didEnd session: GCKSession, withError error: Error?) {
        print("Session ended: \(session)")
    }
}
