//
//  ChannelListVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 09/01/26.
//

import UIKit
import SDWebImage
import SwiftPopup

class ChannelListVC: UIViewController {

    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var titleLabel: UILabel!
    
    var channels: [Channell] = []
    var isChannel: Bool = true
    var filteredChannels: [Channell] = []
    private var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        filteredChannels = channels
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Reload collection view to ensure proper cell layout
        collectionView.collectionViewLayout.invalidateLayout()
    }
    
    func setUI() {
        titleLabel.text = isChannel ? "Country Channels" : "Category Channels"
        setSearchbar()
        setupCollectionView()
    }
    
    func setSearchbar() {
        let searchBarHeight: CGFloat = 48.0
        let cornerRadius: CGFloat = searchBarHeight / 2
        
        SearchTextFieldStyle.apply(
            to: searchBar,
            placeholder: "Search here...",
            leftIcon: UIImage(named: "search_ic"),
            height: searchBarHeight,
            cornerRadius: cornerRadius,
            showClearButton: true
        )
        
        searchBar.delegate = self
        searchBar.addTarget(self, action: #selector(searchTextChanged(_:)), for: .editingChanged)
    }
    
    func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "ChannelCell", bundle: nil), forCellWithReuseIdentifier: "ChannelCell")
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        collectionView.collectionViewLayout = layout
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        collectionView.showsVerticalScrollIndicator = false
        
        // Enable scrolling by default
        collectionView.isScrollEnabled = true
        collectionView.isUserInteractionEnabled = true
        
        // Add keyboard hide when scrolling
        collectionView.keyboardDismissMode = .interactive
//        collectionView.reloadData()
    }
    
    func calculateCellSize() -> CGSize {
        let screenWidth = collectionView.frame.width
        
        // Check if iPad or iPhone
        let isiPad = UIDevice.current.userInterfaceIdiom == .pad
        let numberOfColumns: CGFloat = isiPad ? 4 : 2
        
        // Calculate available width (no spacing on left/right)
        let totalWidth = screenWidth
        let cellWidth = totalWidth / numberOfColumns
        
        // Make square box - same width and height
        return CGSize(width: cellWidth, height: cellWidth)
    }
    
    @IBAction func backButtonTap(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    @objc func searchTextChanged(_ textField: UITextField) {
        filterContentForSearchText(textField.text ?? "")
    }
    
    func filterContentForSearchText(_ searchText: String) {
        isSearching = !searchText.isEmpty
        
        if searchText.isEmpty {
            filteredChannels = channels
        } else {
            filteredChannels = channels.filter { channel in
                return channel.name.lowercased().contains(searchText.lowercased())
            }
        }
        
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension ChannelListVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return filteredChannels.count
    }
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ChannelCell", for: indexPath) as? ChannelCell else {
            return UICollectionViewCell()
        }
        
        let channel = filteredChannels[indexPath.item]
        
        // Set channel name
        cell.channelNameLabel.text = channel.name
        
        // Set channel logo using SDWebImage
        if let logoUrlString = channel.logo, !logoUrlString.isEmpty,
           let logoURL = URL(string: logoUrlString) {
            cell.channelLogoImageview.sd_setImage(
                with: logoURL,
                placeholderImage: UIImage(named: "channel_default"),
                options: [.progressiveLoad, .retryFailed, .scaleDownLargeImages]
            )
        } else {
            cell.channelLogoImageview.image = UIImage(named: "channel_default")
        }
        
        cell.setOnClickListener { [self] in
            self.showInterAdClick()
            openConnectionPop(channelName: channel.name, channelURL: channel.url, channelLogo: channel.logo ?? "")
        }
        
        cell.setNeedsLayout()
        cell.layoutIfNeeded()
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return calculateCellSize()
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let channel = filteredChannels[indexPath.item]
        print("Selected channel: \(channel.name)")
        // TODO: Handle channel selection - play video, show details, etc.
    }
    
    // Hide keyboard when scrolling starts
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        searchBar.resignFirstResponder()
    }
    func openConnectionPop( channelName: String, channelURL: String, channelLogo: String) {
        let vc : SelectedDevicePopVC =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "SelectedDevicePopVC") as! SelectedDevicePopVC
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        vc.onDismiss = {
            self.dismiss(animated: true)
        }
        vc.tvSelect = {
            print("TV")
            self.dismiss(animated: true)
            if selectedTvType == .noneTV{
                self.openListDevice()
            }else{
                self.openIPTVPlayer(channelURL: channelURL, ChannelName: channelName, isCast: true, channelLogo: channelLogo)
            }
        }
        vc.phoneSelect = {
            print("Phone")
            self.dismiss(animated: true)
            self.openIPTVPlayer(channelURL: channelURL, ChannelName: channelName, isCast: false, channelLogo: channelLogo)
        }
        let connectTvPopup: SelectedDevicePopVC?
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        vc.showAnimation = showAnimation
        vc.dismissAnimation = dismissAnimation
        
        // Present using SwiftPopup
        connectTvPopup = vc
        vc.show()
    }
    func openIPTVPlayer(channelURL: String, ChannelName: String, isCast: Bool, channelLogo: String) {
        let vc = storyboard?.instantiateViewController(
            withIdentifier: "IPTVChannelPlayerVC"
        ) as! IPTVChannelPlayerVC
        
        vc.channelUrl = channelURL
        vc.channelName = ChannelName
        vc.isCast = isCast
        vc.channelLogo = channelLogo
        navigationController?.pushViewController(vc, animated: true)
    }
    func openListDevice(){
        let vc : ListDeviceVc =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - UITextField Delegate
extension ChannelListVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        filterContentForSearchText("")
        return true
    }
}
