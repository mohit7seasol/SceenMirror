//
//  IPTVChannelPlayerVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 09/01/26.
//

import UIKit
import AVKit
import AVFoundation
import SVProgressHUD
import GoogleCast
import ConnectSDK
import SDWebImage

class IPTVChannelPlayerVC: UIViewController {
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var playerView: UIView!
    @IBOutlet weak var playPauseBtn: UIButton!
    @IBOutlet weak var currentDurationLbl: UILabel!
    @IBOutlet weak var totalDurationLbl: UILabel!
    @IBOutlet weak var slider: UISlider!
    @IBOutlet weak var streamingOnView: UIView!
    @IBOutlet weak var channelLogoImageView: UIImageView!
    @IBOutlet weak var volumView: UIView!
    
    var channelName = ""
    var channelUrl = ""
    var channelLogo = ""
    var isCast: Bool = false
    
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var timeObserver: Any?
    private var isPlaying = false
    private var heightOfAd = 0
    var volumeController = GCKUIDeviceVolumeController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    override func viewWillAppear(_ animated: Bool) {
        titleLbl.text = channelName
        if checkAirPlayStatus().1  {
            streamingOnView.isHidden = true
            playerView.isHidden = false
        } else {
            if isCast  {
                streamingOnView.isHidden = false
                playerView.isHidden = true
                volumView.isHidden = checkAirPlayStatus().1 ? true : false
                setupVideoPlay(url: URL(string: channelUrl) ?? URL(fileURLWithPath: ""))
                loadChannelLogo()
                
            } else {
                streamingOnView.isHidden = true
                playerView.isHidden = false
            }
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if !isCast || checkAirPlayStatus().1 {
            isPlaying = true          // ✅ AUTO PLAY FLAG
            playPauseBtn.setImage(UIImage(named: "pause1"), for: .normal)

            setupPlayer()

            navigationController?.interactivePopGestureRecognizer?.delegate = self
            navigationController?.interactivePopGestureRecognizer?.isEnabled = true
            slider.isUserInteractionEnabled = true
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if !isCast {
            player?.pause()
            isPlaying = false
            SVProgressHUD.dismiss()
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "status" {
            if player?.currentItem?.status == .readyToPlay {
                SVProgressHUD.dismiss()
                
                if isPlaying {
                    player?.play()
                    playPauseBtn.setImage(UIImage(named: "pause1"), for: .normal)
                } else {
                    playPauseBtn.setImage(UIImage(named: "play1"), for: .normal)
                }
            } else if player?.currentItem?.status == .failed {
                // Show error if player failed to load
                SVProgressHUD.dismiss()
                showErrorAlert(message: "Failed to load channel. Please check your internet connection.")
                playPauseBtn.setImage(UIImage(named: "play1"), for: .normal)
                isPlaying = false
            }
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = playerView.bounds
    }
    
    private func setupPlayer() {
        guard let url = URL(string: channelUrl) else {
            SVProgressHUD.dismiss()
            showErrorAlert(message: "Invalid channel URL")
            return
        }
        
        // Show loading indicator while setting up player
        SVProgressHUD.show(withStatus: "Loading channel...")
        
        // Create AVPlayerItem with timeout configuration
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        
        // Create player with the item
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = playerView.bounds
        playerLayer?.videoGravity = .resizeAspect
        if let layer = playerLayer {
            playerView.layer.addSublayer(layer)
        }
        
        // Resize properly
        playerLayer?.frame = playerView.bounds
        playerView.layoutIfNeeded()
        
        // Update slider & labels while playing
        addTimeObserver()
        
        // Load duration if available
        playerItem.asset.loadValuesAsynchronously(forKeys: ["duration"]) { [weak self] in
            DispatchQueue.main.async {
                var error: NSError?
                let status = playerItem.asset.statusOfValue(forKey: "duration", error: &error)
                
                if status == .loaded {
                    let duration = playerItem.asset.duration
                    let seconds = CMTimeGetSeconds(duration)
                    if seconds.isFinite && seconds > 0 {
                        self?.slider.maximumValue = Float(seconds)
                        self?.totalDurationLbl.text = self?.formatTime(seconds)
                    } else {
                        self?.totalDurationLbl.text = "Live"
                    }
                } else {
                    self?.totalDurationLbl.text = "Live"
                }
                
                // If still loading after 30 seconds, show error
                DispatchQueue.main.asyncAfter(deadline: .now() + 30) {
                    if SVProgressHUD.isVisible() {
                        SVProgressHUD.dismiss()
                        self?.showErrorAlert(message: "Channel loading timeout. Please try again.")
                        self?.playPauseBtn.setImage(UIImage(named: "play1"), for: .normal)
                        self?.isPlaying = false
                    }
                }
            }
        }
        
        // Add observer for player status
        playerItem.addObserver(self,
                               forKeyPath: "status",
                               options: [.new, .old],
                               context: nil)
        
        // Add observer for player error
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playerItemFailedToPlay),
            name: .AVPlayerItemFailedToPlayToEndTime,
            object: playerItem
        )
        
        // Add observer for playback stall
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(playbackStalled),
            name: .AVPlayerItemPlaybackStalled,
            object: playerItem
        )
    }
    func loadChannelLogo() {
        if let logoURL = URL(string: channelLogo) {
            channelLogoImageView.sd_setImage(
             with: logoURL,
             placeholderImage: UIImage(named: "channel_default"),
             options: [.progressiveLoad, .retryFailed, .scaleDownLargeImages]
         )
     }
    }
    private func addTimeObserver() {
        guard let player = player else { return }
        let interval = CMTime(seconds: 1, preferredTimescale: CMTimeScale(NSEC_PER_SEC))
        
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            let currentSeconds = CMTimeGetSeconds(time)
            self?.slider.value = Float(currentSeconds)
            self?.currentDurationLbl.text = self?.formatTime(currentSeconds)
        }
    }
    
    private func formatTime(_ seconds: Float64) -> String {
        guard seconds.isFinite else { return "--:--" }
        let mins = Int(seconds) / 60
        let secs = Int(seconds) % 60
        return String(format: "%02d:%02d", mins, secs)
    }
    
    @objc private func playerItemFailedToPlay(notification: Notification) {
        SVProgressHUD.dismiss()
        showErrorAlert(message: "Failed to play channel. Please try again.")
        playPauseBtn.setImage(UIImage(named: "tvplay_ic"), for: .normal)
        isPlaying = false
    }
    
    @objc private func playbackStalled(notification: Notification) {
        SVProgressHUD.show(withStatus: "Buffering...")
        // Auto-dismiss buffering indicator after 10 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 10) {
            if SVProgressHUD.isVisible() {
                SVProgressHUD.dismiss()
            }
        }
    }
    
    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error",
                                    message: message,
                                    preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
            self?.navigationController?.popViewController(animated: true)
        })
        present(alert, animated: true)
    }
    
    @IBAction func minusVolButtonTap(_ sender: Any) {
        addHaptic()
        if selectedTvType == .LGTV{
            commonViewModel.connectSDKDiscoveryModel.selectedLGDevice?.volumeControl().volumeDown { sucess in
            } failure: { error in
            }
        }else{
            volumeController.volumeDown()
        }
    }
    
    @IBAction func plushVolButtonTap(_ sender: Any) {
        addHaptic()
        if selectedTvType == .LGTV{
            commonViewModel.connectSDKDiscoveryModel.selectedLGDevice?.volumeControl().volumeUp { sucess in
            } failure: { error in
            }
        }else{
            volumeController.volumeUp()
        }
    }
    @IBAction func backButtonTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    @IBAction func sliderValueChanged(_ sender: UISlider) {
        let targetTime = CMTime(seconds: Double(sender.value), preferredTimescale: 600)
        player?.seek(to: targetTime)
    }
    
    @IBAction func playPauseTapped(_ sender: UIButton) {
        guard let player = player else { return }

        if isPlaying {
            // ▶️ PAUSE
            player.pause()
            isPlaying = false
            playPauseBtn.setImage(UIImage(named: "play1"), for: .normal)

        } else {
            // ▶️ PLAY
            if player.currentItem?.status == .failed {
                SVProgressHUD.show(withStatus: "Retrying...")
                setupPlayer()
                return
            }

            player.play()
            isPlaying = true
            playPauseBtn.setImage(UIImage(named: "pause1"), for: .normal)
        }
    }
    
    deinit {
        if let observer = timeObserver {
            player?.removeTimeObserver(observer)
            timeObserver = nil
        }
        
        // Remove observers
        player?.currentItem?.removeObserver(self, forKeyPath: "status")
        NotificationCenter.default.removeObserver(self)
        
        // Dismiss HUD
        SVProgressHUD.dismiss()
    }
}

// MARK: - UIGestureRecognizerDelegate
extension IPTVChannelPlayerVC {
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
}
extension IPTVChannelPlayerVC {
    func setupVideoPlay(url: URL){
        if checkAirPlayStatus().1{
            setupLocalPlayback()
        } else {
            DispatchQueue.main.async {
                
                if commonViewModel.getConnectedTvType() == .LGTV {
                    //                            self.showCustomLoading(superVc: self, titleText: "Streaming")
                    commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(titleStr: self.channelName ?? "\(APP_NAME)", subtitleStr: "")
                    commonViewModel.connectSDKDiscoveryModel.sendMediaToLGTVYT(mediaUrl: url, mimeType: "video/mp4")
                }else if commonViewModel.getConnectedTvType() == .GcastTV {
                    commonViewModel.castViewModel.castDetail = CastDetail(titleStr: self.channelName ?? "\(APP_NAME)", subtitleStr: "")
                    commonViewModel.CastMedia(url: url, mediaType: "video/mp4",imgHei: 1024, imgWid: 1024)
                }
            }
        }
    }
    func setupLocalPlayback() {
        // Configure SVProgressHUD
        SVProgressHUD.setDefaultStyle(.dark)
        SVProgressHUD.setDefaultMaskType(.clear)
        SVProgressHUD.setMinimumDismissTimeInterval(2.0)
        
        // Show loading indicator immediately
        SVProgressHUD.show(withStatus: "Loading channel...")
    }
}
