//
//  IPTVListVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 08/01/26.
//

import UIKit
import SDWebImage

enum MenuState {
    case collapsedCountry     // only country visible
    case collapsedCategory    // only category visible
    case expanded             // both visible
}

enum MenuButtonType {
    case country
    case category
}

struct IPTVGroup: Codable {
    let country: String
    let countryCodes: String
    let flag: String
    let channels: [Channell]
}

struct IPTVCategory: Codable {
    let category: String
    let channels: [Channell]
}

struct Channell: Codable {
    let name: String
    let logo: String?
    let url: String
}

class IPTVListVC: UIViewController {

    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var dropdownView: GradientDesignableView!
    @IBOutlet weak var countyButton: UIButton!
    @IBOutlet weak var categoryButton: UIButton!
    @IBOutlet weak var countryButtonView: UIView!
    @IBOutlet weak var categoryButtonView: UIView!
    @IBOutlet weak var collectionView: UICollectionView!
    
    private var menuState: MenuState = .collapsedCountry
    var categories: [IPTVCategory] = []
    var countries: [IPTVGroup] = []
    var filteredCategories: [IPTVCategory] = []
    var filteredCountries: [IPTVGroup] = []
    
    private var currentMenuType: MenuButtonType = .country
    private var isSearching = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        fetchIPTVData()
    }
    
    func setUI() {
        setSearchbar()
        setDropDown()
        setupCollectionView()
    }
    
    func setSearchbar() {
        let searchBarHeight: CGFloat = 48.0
        let cornerRadius: CGFloat = searchBarHeight / 2
        
        SearchTextFieldStyle.apply(
            to: searchBar,
            placeholder: "Search...",
            leftIcon: UIImage(named: "search_ic"),
            height: searchBarHeight,
            cornerRadius: cornerRadius,
            showClearButton: true
        )
        
        searchBar.delegate = self
        searchBar.addTarget(self, action: #selector(searchTextChanged(_:)), for: .editingChanged)
    }
    
    func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(UINib(nibName: "IPTVListCell", bundle: nil), forCellWithReuseIdentifier: "IPTVListCell")
        collectionView.register(UICollectionReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "HeaderView")
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.itemSize = CGSize(width: UIScreen.main.bounds.width, height: 66)
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        layout.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        layout.headerReferenceSize = CGSize(width: UIScreen.main.bounds.width, height: 60)
        
        collectionView.collectionViewLayout = layout
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        collectionView.showsVerticalScrollIndicator = false
    }
    
    func updateMenuUI(animated: Bool = true) {
        let animations = {
            switch self.menuState {
            case .collapsedCountry:
                self.countryButtonView.isHidden = false
                self.categoryButtonView.isHidden = true
                
            case .collapsedCategory:
                self.countryButtonView.isHidden = true
                self.categoryButtonView.isHidden = false
                
            case .expanded:
                self.countryButtonView.isHidden = false
                self.categoryButtonView.isHidden = false
            }
            
            self.view.layoutIfNeeded()
        }
        
        if animated {
            UIView.animate(withDuration: 0.25, animations: animations)
        } else {
            animations()
        }
    }
    
    func setDropDown() {
        menuState = .collapsedCountry
        currentMenuType = .country
        updateMenuUI(animated: false)
        loadDataForCurrentType()
    }
    
    func loadDataForCurrentType() {
        switch currentMenuType {
        case .country:
            filteredCountries = countries
        case .category:
            filteredCategories = categories
        }
        collectionView.reloadData()
    }
    
    func openDropDown(type: MenuButtonType) {
        currentMenuType = type
        loadDataForCurrentType()
        
        switch type {
        case .country:
            print("Open Country dropdown")
            // TODO: show country dropdown list here
            
        case .category:
            print("Open Category dropdown")
            // TODO: show category dropdown list here
        }
    }
    
    func filterContentForSearchText(_ searchText: String) {
        isSearching = !searchText.isEmpty
        
        switch currentMenuType {
        case .country:
            if searchText.isEmpty {
                filteredCountries = countries
            } else {
                filteredCountries = countries.filter { country in
                    return country.country.lowercased().contains(searchText.lowercased())
                }
            }
            
        case .category:
            if searchText.isEmpty {
                filteredCategories = categories
            } else {
                filteredCategories = categories.filter { category in
                    return category.category.lowercased().contains(searchText.lowercased())
                }
            }
        }
        
        collectionView.reloadData()
    }
    
    @objc func searchTextChanged(_ textField: UITextField) {
        filterContentForSearchText(textField.text ?? "")
    }
}

// MARK: - UICollectionView Delegate & DataSource
extension IPTVListVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "HeaderView", for: indexPath)
            
            // Remove any existing labels
            headerView.subviews.forEach { $0.removeFromSuperview() }
            
            // Create and configure title label
            let titleLabel = UILabel(frame: CGRect(x: 16, y: 0, width: collectionView.frame.width - 32, height: 32))
            titleLabel.textColor = .white
            titleLabel.font = UIFont.boldSystemFont(ofSize: 18)
            titleLabel.text = currentMenuType == .country ? "Country" : "Category"
            
            headerView.addSubview(titleLabel)
            
            return headerView
        }
        
        return UICollectionReusableView()
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        switch currentMenuType {
        case .country:
            return filteredCountries.count
        case .category:
            return filteredCategories.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IPTVListCell", for: indexPath) as! IPTVListCell
        
        switch currentMenuType {
        case .country:
            let country = filteredCountries[indexPath.item]
            cell.countryNameLbl.text = country.country
            cell.countLbl.text = "\(country.channels.count)+"
            
            // Set flag image using SDWebImage
            if !country.flag.isEmpty, let flagURL = URL(string: country.flag) {
                cell.countryFlagImageview.sd_setImage(
                    with: flagURL,
                    placeholderImage: UIImage(named: "country_default"),
                    options: [.progressiveLoad, .retryFailed]
                )
            } else {
                cell.countryFlagImageview.image = UIImage(named: "country_default")
            }
            
            // Apply rounded shape to image view
            cell.countryFlagImageview.layer.cornerRadius = 10
            cell.countryFlagImageview.layer.masksToBounds = true
            cell.countryFlagImageview.contentMode = .scaleAspectFill
            
        case .category:
            let category = filteredCategories[indexPath.item]
            cell.countryNameLbl.text = category.category
            cell.countLbl.text = "\(category.channels.count)+"
            
            // Always use category_default image for categories
            cell.countryFlagImageview.image = UIImage(named: "category_default")
            
            // Apply rounded shape to image view
            cell.countryFlagImageview.layer.cornerRadius = 10
            cell.countryFlagImageview.layer.masksToBounds = true
            cell.countryFlagImageview.contentMode = .scaleAspectFill
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 66)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 60)
    }
}

// MARK: - UITextField Delegate
extension IPTVListVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        filterContentForSearchText("")
        return true
    }
}

// MARK: - Button Actions
extension IPTVListVC {
    @IBAction func countryAndCategoryButtonTap(_ sender: UIButton) {
        let tappedMenu: MenuButtonType = (sender.tag == 1) ? .country : .category
        
        switch menuState {
            
        case .collapsedCountry:
            menuState = .expanded
            updateMenuUI()
            openDropDown(type: .country)
            
        case .collapsedCategory:
            menuState = .expanded
            updateMenuUI()
            openDropDown(type: .category)
            
        case .expanded:
            // User is selecting
            if tappedMenu == .country {
                menuState = .collapsedCountry
                openDropDown(type: .country)
            } else {
                menuState = .collapsedCategory
                openDropDown(type: .category)
            }
            updateMenuUI()
        }
    }
}

// MARK: - API's
extension IPTVListVC {
    func fetchIPTVData() {
        // First try to load from cache
        if let cachedData = UserDefaults.standard.data(forKey: "iptv_grouped_by_category"),
           let decodedChannels = try? JSONDecoder().decode([IPTVCategory].self, from: cachedData) {
            self.categories = decodedChannels
            DispatchQueue.main.async {
                self.loadDataForCurrentType()
            }
        } else {
            DispatchQueue.main.async {
                self.fetchIPTVCateData()
            }
        }
        
        if let cachedData = UserDefaults.standard.data(forKey: "iptv_grouped_by_country"),
           let decodedChannels = try? JSONDecoder().decode([IPTVGroup].self, from: cachedData) {
            self.countries = decodedChannels
            DispatchQueue.main.async {
                self.loadDataForCurrentType()
            }
        } else {
            DispatchQueue.main.async {
                self.fetchIPTVCountryData()
            }
        }
    }
    
    func fetchIPTVCountryData(){
        guard let url = URL(string: "http://d2is1ss4hhk4uk.cloudfront.net/iptv/iptv_grouped_by_country.json") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Error:", error.localizedDescription)
                return
            }
            guard let data = data else { return }
            
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode([IPTVGroup].self, from: data)
                if let encoded = try? JSONEncoder().encode(result) {
                    UserDefaults.standard.set(encoded, forKey: "iptv_grouped_by_country")
                }
                DispatchQueue.main.async {
                    self.countries = result
                    self.loadDataForCurrentType()
                }
            } catch {
                print("❌ Decoding error:", error)
            }
        }.resume()
    }
    
    func fetchIPTVCateData() {
        guard let url = URL(string: "http://d2is1ss4hhk4uk.cloudfront.net/iptv/iptv_grouped_by_category.json") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let error = error {
                print("❌ Error:", error.localizedDescription)
                return
            }
            guard let data = data else { return }
            
            do {
                let decoder = JSONDecoder()
                let result = try decoder.decode([IPTVCategory].self, from: data)
                
                if let encoded = try? JSONEncoder().encode(result) {
                    UserDefaults.standard.set(encoded, forKey: "iptv_grouped_by_category")
                }
                
                DispatchQueue.main.async {
                    self.categories = result
                    self.loadDataForCurrentType()
                }
            } catch {
                print("❌ Decoding error:", error)
            }
        }.resume()
    }
}

// MARK: - IPTVListCell Customization
extension IPTVListCell {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // Ensure the image view has rounded corners
        countryFlagImageview.layer.cornerRadius = 10
        countryFlagImageview.layer.masksToBounds = true
        countryFlagImageview.contentMode = .scaleAspectFill
    }
}
