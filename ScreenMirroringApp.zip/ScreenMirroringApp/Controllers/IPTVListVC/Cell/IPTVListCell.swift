//
//  IPTVListCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 08/01/26.
//

import UIKit

class IPTVListCell: UICollectionViewCell {
    @IBOutlet weak var countLbl: UILabel!
    @IBOutlet weak var countryFlagImageview: UIImageView!
    @IBOutlet weak var countryNameLbl: UILabel!
    @IBOutlet weak var mainView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        mainView.applyGradientBorder(firstColor: #colorLiteral(red: 0.7058823529, green: 0.7058823529, blue: 0.7294117647, alpha: 1) , secondColor: #colorLiteral(red: 0.301620692, green: 0.3289888799, blue: 0.4145909548, alpha: 1), cornerRadius: 12, borderWidth: 1.0)
    }
}
