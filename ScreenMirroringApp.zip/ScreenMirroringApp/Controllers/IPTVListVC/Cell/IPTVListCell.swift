//
//  IPTVListCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 08/01/26.
//

import UIKit
import SDWebImage

class IPTVListCell: UICollectionViewCell {
    @IBOutlet weak var countLbl: UILabel!
    @IBOutlet weak var countryFlagImageview: UIImageView!
    @IBOutlet weak var countryNameLbl: UILabel!
    @IBOutlet weak var mainView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupMainView()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        updateGradientLayers()
    }
    
    func setupMainView() {
        applyGradientBorder()
    }
    
    func applyGradientBorder() {
        // Remove existing gradient layers for border
        mainView.layer.sublayers?.removeAll { $0.name == "gradientBorder" }
        
        // Create border shape
        let borderLayer = CAShapeLayer()
        borderLayer.path = UIBezierPath(
            roundedRect: mainView.bounds.insetBy(dx: 0.5, dy: 0.5),
            cornerRadius: 50
        ).cgPath
        borderLayer.fillColor = UIColor.clear.cgColor
        borderLayer.strokeColor = UIColor.white.cgColor
        borderLayer.lineWidth = 1.0
        
        // Create gradient for border (White 70% → White 20%)
        let borderGradient = CAGradientLayer()
        borderGradient.name = "gradientBorder"
        borderGradient.frame = mainView.bounds
        borderGradient.colors = [
            UIColor.white.withAlphaComponent(0.7).cgColor,
            UIColor.white.withAlphaComponent(0.2).cgColor
        ]
        borderGradient.startPoint = CGPoint(x: 0, y: 0.5) // Left
        borderGradient.endPoint = CGPoint(x: 1, y: 0.5)   // Right
        borderGradient.mask = borderLayer
        
        // Add border gradient on top
        mainView.layer.addSublayer(borderGradient)
    }
    
    func updateGradientLayers() {
        // Update frames for gradient layers
        for layer in mainView.layer.sublayers ?? [] {
            if layer.name == "gradientBorder" {
                layer.frame = mainView.bounds
                
                // Update border path if it's a mask of gradient border
                if let gradientLayer = layer as? CAGradientLayer,
                   let maskLayer = gradientLayer.mask as? CAShapeLayer {
                    maskLayer.path = UIBezierPath(
                        roundedRect: mainView.bounds.insetBy(dx: 0.5, dy: 0.5),
                        cornerRadius: 50
                    ).cgPath
                }
                
                // Update corner radius for background gradient
                if layer.name == "gradientBackground" {
                    layer.cornerRadius = 50
                }
            }
        }
        
        // Update blur view frame
        if let blurView = mainView.subviews.first(where: { $0 is UIVisualEffectView }) {
            blurView.frame = mainView.bounds
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        // Reset image view
        countryFlagImageview.image = nil
        
        // Clear any SDWebImage downloads
        countryFlagImageview.sd_cancelCurrentImageLoad()
    }
}
