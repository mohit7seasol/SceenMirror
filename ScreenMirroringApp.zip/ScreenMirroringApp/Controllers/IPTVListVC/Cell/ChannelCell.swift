//
//  ChannelCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 09/01/26.
//

import UIKit
import SDWebImage

class ChannelCell: UICollectionViewCell {

    @IBOutlet weak var channelLogoImageview: UIImageView!
    @IBOutlet weak var channelNameLabel: UILabel!
    @IBOutlet weak var mainView: UIView!
    
    private var borderGradient: CAGradientLayer?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupMainView()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        // Ensure mainView has proper layout
        mainView.layoutIfNeeded()
        
        // Make logo image view circular or rounded
        channelLogoImageview.layer.masksToBounds = true
        channelLogoImageview.contentMode = .scaleAspectFill
        
        // Apply gradient border with updated frame
        applyGradientBorder()
    }
    
    func setupMainView() {
        // Set up main view properties
        mainView.layer.cornerRadius = 12
        mainView.layer.masksToBounds = false
        
        // Set up image view
        channelLogoImageview.backgroundColor = .clear
        
        // Set up label
        channelNameLabel.textColor = .white
        channelNameLabel.textAlignment = .center
        channelNameLabel.font = UIFont.systemFont(ofSize: 12, weight: .medium)
        channelNameLabel.numberOfLines = 2
    }
    
    func applyGradientBorder() {
        // Ensure mainView has a valid frame
        guard mainView.bounds.width > 0, mainView.bounds.height > 0 else {
            return
        }
        
        // Remove existing gradient layer
        borderGradient?.removeFromSuperlayer()
        
        // Create border shape
        let borderLayer = CAShapeLayer()
        borderLayer.path = UIBezierPath(
            roundedRect: mainView.bounds.insetBy(dx: 0.5, dy: 0.5),
            cornerRadius: 12
        ).cgPath
        borderLayer.fillColor = UIColor.clear.cgColor
        borderLayer.strokeColor = UIColor.white.cgColor
        borderLayer.lineWidth = 1.0
        
        // Create gradient for border (White 70% → White 20%)
        let gradient = CAGradientLayer()
        gradient.name = "gradientBorder"
        gradient.frame = mainView.bounds
        gradient.colors = [
            UIColor.white.withAlphaComponent(0.7).cgColor,
            UIColor.white.withAlphaComponent(0.2).cgColor
        ]
        gradient.startPoint = CGPoint(x: 0, y: 0.5) // Left
        gradient.endPoint = CGPoint(x: 1, y: 0.5)   // Right
        gradient.mask = borderLayer
        
        // Store reference and add to layer
        borderGradient = gradient
        mainView.layer.addSublayer(gradient)
    }
    
    func updateGradientLayers() {
        // Update frame for gradient layer
        if let gradient = borderGradient {
            gradient.frame = mainView.bounds
            
            // Update border path if it's a mask of gradient border
            if let maskLayer = gradient.mask as? CAShapeLayer {
                maskLayer.path = UIBezierPath(
                    roundedRect: mainView.bounds.insetBy(dx: 0.5, dy: 0.5),
                    cornerRadius: 12
                ).cgPath
            }
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        // Reset image view
        channelLogoImageview.image = nil
        
        // Clear any SDWebImage downloads
        channelLogoImageview.sd_cancelCurrentImageLoad()
        
        // Remove gradient layer
        borderGradient?.removeFromSuperlayer()
        borderGradient = nil
    }
}
