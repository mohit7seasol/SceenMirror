//
//  VideoPreviewVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 01/01/26.
//

import UIKit
import Photos
import AVKit
import AVFoundation
import MobileCoreServices
import ICGVideoTrimmer
import ConnectSDK
import MediaPlayer
import GoogleCast

class VideoCastVC: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var videoPreviewView: UIView!
    @IBOutlet weak var modeLabel: UILabel!
    @IBOutlet weak var trimmerView: ICGVideoTrimmerView!
    @IBOutlet weak var volumeView: UIView!
    
    var videoAssets = [PHAsset]()
    var mediatype: mediaType = .Videos
    var callBack: ((_ assetArray: [PHAsset]) -> Void)?
    var selectedIndex: Int = 0
    var channelURL: URL?
    var shouldCastToTV: Bool = true
    var channelName: String?
    var selectedVideoAsset: PHAsset? // Added this property
    
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var videoURL: URL?
    private var videoDuration: Float64 = 0
    private var isPlaying = false
    private var playbackTimeCheckerTimer: Timer?
    private var videoPlaybackPosition: CGFloat = 0
    private var startTime: CGFloat = 0
    private var stopTime: CGFloat = 0
    private var restartOnPlay = false
    var videoTimer : Timer?
    var playerItemEndObserver: Any?
    var volumeController = GCKUIDeviceVolumeController()
    
    var videoList = [VideoResolution]()
    var type = Int()
    
    // MARK: - Lifecycle Methods
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        
        // Check media type and load appropriate content
        if mediatype == .Web {
            // Handle web video
            setupWebVideo()
        } else {
            // Handle local video
            loadVideo()
        }
        
        setupTrimmerView()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = videoPreviewView.bounds
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        commonViewModel.startPlaybackUpdates()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player?.pause()
        stopPlaybackTimeChecker()
        stopVideoTimer()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        print("VideoCastVC: Deinitialized")
    }
    
    // MARK: - Setup Methods
    
    private func setupUI() {
        videoPreviewView.layer.cornerRadius = 8
        videoPreviewView.clipsToBounds = true
        
        // Set title based on media type
        if mediatype == .Web {
            titleLabel.text = "Web Video Cast"
        } else {
            titleLabel.text = "Video Cast"
        }
    }
    
    private func setupWebVideo() {
        trimmerView.isHidden = false
        trimmerView.isUserInteractionEnabled = false
        trimmerView.alpha = 0.6
        
        guard selectedIndex < videoList.count else { return }
        let selectedVideo = videoList[selectedIndex]
        titleLabel.text = selectedVideo.videoName

        // Load thumbnail if available
        if !selectedVideo.videothumImage.isEmpty {
            loadThumbnail(from: selectedVideo.videothumImage)
        }

        // Setup player + trimmer preview from web URL
        if let url = URL(string: selectedVideo.videoURL) {
            setupVideoPlayer(with: url)

            let asset = AVURLAsset(url: url)
            let duration = CMTimeGetSeconds(asset.duration)

            videoDuration = duration
            startTime = 0
            stopTime = CGFloat(duration)

            // 🔹 SET TRIMMER PREVIEW FOR WEB VIDEO (READ-ONLY)
            trimmerView.asset = asset
            trimmerView.resetSubviews()
            trimmerView.hideTracker(true)
        }
    }
    
    private func loadThumbnail(from urlString: String) {
        guard let url = URL(string: urlString) else { return }
        
        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        // Create an image view for thumbnail
                        let imageView = UIImageView(frame: self.videoPreviewView.bounds)
                        imageView.image = image
                        imageView.contentMode = .scaleAspectFit
                        imageView.layer.cornerRadius = 8
                        imageView.clipsToBounds = true
                        
                        // Remove existing subviews
                        self.videoPreviewView.subviews.forEach { $0.removeFromSuperview() }
                        self.videoPreviewView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }
                        
                        self.videoPreviewView.addSubview(imageView)
                    }
                }
            }
        }
    }
    
    private func setupTrimmerView() {
        guard trimmerView != nil else {
            print("Trimmer view is nil")
            return
        }
        
        // Only setup trimmer for local videos, not web videos
        if mediatype != .Web {
            trimmerView.delegate = self
            trimmerView.showsRulerView = false
            trimmerView.trackerColor = .white
            trimmerView.leftThumbImage = UIImage(named: "CustomStartIndicator")
            trimmerView.rightThumbImage = UIImage(named: "CustomEndIndicator")
            trimmerView.layer.cornerRadius = 20
            trimmerView.layer.borderColor = UIColor.lightGray.cgColor
            
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapOnVideoLayer(_:)))
            videoPreviewView.addGestureRecognizer(tapGesture)
        } else {
            // Disable trimmer for web videos
            trimmerView.isUserInteractionEnabled = false
            trimmerView.alpha = 0.5
        }
    }
    
    // MARK: - Video Loading Methods
    
    private func loadVideo() {
        guard selectedIndex < videoAssets.count else { return }
        
        let asset = videoAssets[selectedIndex]
        selectedVideoAsset = asset // Set the selected video asset
        
        let options = PHVideoRequestOptions()
        options.deliveryMode = .highQualityFormat
        options.isNetworkAccessAllowed = true
        
        PHImageManager.default().requestAVAsset(forVideo: asset, options: options) { [weak self] avAsset, audioMix, info in
            guard let self = self, let avAsset = avAsset as? AVURLAsset else { return }
            
            DispatchQueue.main.async {
                self.videoURL = avAsset.url
                self.setupVideoPlayer(with: avAsset.url)
                self.videoDuration = CMTimeGetSeconds(avAsset.duration)
                self.trimmerView.asset = avAsset
                self.trimmerView.resetSubviews()
                
                // Reset to full video duration when loading new video
                self.startTime = 0
                self.stopTime = CGFloat(self.videoDuration)
                self.restartOnPlay = false
                
                // Auto-play locally if not casting
                if !self.shouldCastToTV {
                    self.player?.play()
                    self.isPlaying = true
                    self.startPlaybackTimeChecker()
                    self.trimmerView.hideTracker(false)
                }
            }
        }
    }
    
    // MARK: - Video Casting Setup
    func setupVideoPlay(){
        // Check media type first
        if mediatype == .Web {
            // Handle web video casting
            castWebVideo()
            return
        }
        
        // Original code for local videos
        // Check if we have a selected time range
        if restartOnPlay {
            // User has selected a custom range
            if let url = videoURL {
                // For local video files, create trimmed version
                createTrimmedVideo(from: url, startTime: startTime, endTime: stopTime) { trimmedURL in
                    if let trimmedURL = trimmedURL {
                        self.castVideo(url: trimmedURL, isTrimmed: true)
                    } else {
                        // If trimming fails, cast original with seek position
                        self.castOriginalVideoWithSeek(url: url)
                    }
                }
            } else if let asset = selectedVideoAsset {
                // For PHAssets, handle selected range
                self.castAssetWithSelectedRange(asset: asset)
            }
            return
        }
        
        // Original setupVideoPlay logic for full video
        if let url = channelURL {
            if shouldCastToTV {
                if checkAirPlayStatus().1{
                    setupLocalPlayback()
                }else{
                    DispatchQueue.main.async {
                        
                        if commonViewModel.getConnectedTvType() == .LGTV {
                            commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(titleStr: self.channelName ?? "\(APP_NAME)", subtitleStr: "")
                            commonViewModel.connectSDKDiscoveryModel.sendMediaToLGTVYT(mediaUrl: url, mimeType: "video/mp4")
                            commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                            }
                        }else if commonViewModel.getConnectedTvType() == .GcastTV {
                            commonViewModel.castViewModel.castDetail = CastDetail(titleStr: self.channelName ?? "\(APP_NAME)", subtitleStr: "")
                            commonViewModel.CastMedia(url: url, mediaType: "video/mp4",imgHei: 1024, imgWid: 1024)
                            commonViewModel.castViewModel.onStartVideo = {
                            }
                        }
                    }
                }
            }else{
                setupLocalPlayback()
            }
        }else{
            if checkAirPlayStatus().1{
                setupLocalPlayback()
            }else if selectedTvType == .LGTV ||  selectedTvType == .GcastTV{
                NotificationCenter.default.addObserver(self, selector: #selector(appDidEnterBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
                NotificationCenter.default.addObserver(self, selector: #selector(appWillEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
                if let asset = selectedVideoAsset {
                    asset.getMediaFileURL { url in
                        if let url = url {
                            DispatchQueue.main.async {
                                commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                                }
                                commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(titleStr: "Video Player", subtitleStr: "")
                                commonViewModel.castViewModel.castDetail = CastDetail(titleStr: "Video Player", subtitleStr: "")
                                commonViewModel.compressAndUploadVideo(url, selectedQuality: 2)
                            }
                        }
                    }
                } else {
                }
            }else{
                setupLocalPlayback()
            }
        }
    }
    
    // MARK: - Web Video Casting
    private func castWebVideo() {
        guard selectedIndex < videoList.count else {
            print("No web video selected")
            return
        }
        
        let selectedVideo = videoList[selectedIndex]
        
        // Check device connection
        if commonViewModel.getConnectedTvType() == .noneTV && !checkAirPlayStatus().1 {
            showDeviceConnectionAlert()
            return
        }
        
        // Get the video URL
        guard let videoURL = URL(string: selectedVideo.videoURL) else {
            print("Invalid web video URL")
            return
        }
        
        if shouldCastToTV {
            if checkAirPlayStatus().1 {
                // Cast via AirPlay
                castWebVideoViaAirPlay(url: videoURL, title: selectedVideo.videoName)
            } else {
                // Cast to connected TV
                DispatchQueue.main.async {
                    if commonViewModel.getConnectedTvType() == .LGTV {
                        self.castWebVideoToLGTV(url: videoURL, title: selectedVideo.videoName)
                    } else if commonViewModel.getConnectedTvType() == .GcastTV {
                        self.castWebVideoToGoogleCast(url: videoURL, title: selectedVideo.videoName)
                    }
                }
            }
        } else {
            // Play web video locally
            playWebVideoLocally(url: videoURL)
        }
    }
    
    private func castWebVideoToLGTV(url: URL, title: String) {
        commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(
            titleStr: title,
            subtitleStr: ""
        )
        commonViewModel.connectSDKDiscoveryModel.sendMediaToLGTVYT(
            mediaUrl: url,
            mimeType: "video/mp4"
        )
        commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
            print("Started casting web video to LG TV")
        }
    }
    
    private func castWebVideoToGoogleCast(url: URL, title: String) {
        commonViewModel.castViewModel.castDetail = CastDetail(
            titleStr: title,
            subtitleStr: ""
        )
        commonViewModel.CastMedia(
            url: url,
            mediaType: "video/mp4",
            imgHei: 1024,
            imgWid: 1024
        )
        commonViewModel.castViewModel.onStartVideo = {
            print("Started casting web video to Google Cast")
        }
    }
    
    private func castWebVideoViaAirPlay(url: URL, title: String) {
        let player = AVPlayer(url: url)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        playerViewController.title = title
        
        playerViewController.allowsPictureInPicturePlayback = true
        playerViewController.player?.allowsExternalPlayback = true
        playerViewController.player?.usesExternalPlaybackWhileExternalScreenIsActive = true
        
        present(playerViewController, animated: true) {
            player.play()
        }
    }
    
    private func playWebVideoLocally(url: URL) {
        // Remove existing player
        player?.pause()
        playerLayer?.removeFromSuperlayer()
        
        // Create new player for web video
        player = AVPlayer(url: url)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoPreviewView.bounds
        playerLayer?.videoGravity = .resizeAspect
        
        // Remove existing subviews
        videoPreviewView.subviews.forEach { $0.removeFromSuperview() }
        
        if let playerLayer = playerLayer {
            videoPreviewView.layer.addSublayer(playerLayer)
        }
        
        setupAudioSession()
        isPlaying = true
        player?.play()
        
        // Set up observer for playback end
        playerItemEndObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            self.isPlaying = false
            self.player?.seek(to: .zero)
        }
    }
    
    private func setupLocalPlayback() {
        if let url = videoURL {
            loadLocalMedia(url: url, isAudio: isAudioContent(url: url))
        } else if let asset = selectedVideoAsset {
            loadLocalAsset(asset: asset, isAudio: false)
        } else {
            // Fallback to loading from videoAssets if selectedVideoAsset is nil
            if selectedIndex < videoAssets.count {
                let asset = videoAssets[selectedIndex]
                loadLocalAsset(asset: asset, isAudio: false)
            }
        }
    }
    
    private func isAudioContent(url: URL) -> Bool {
        let audioExtensions = ["mp3", "m4a", "wav", "aac"]
        return audioExtensions.contains(url.pathExtension.lowercased())
    }
    
    private func loadLocalMedia(url: URL, isAudio: Bool) {
        let playerItem = AVPlayerItem(url: url)
        playerItem.addObserver(self, forKeyPath: #keyPath(AVPlayerItem.status), options: [.new], context: nil)
        
        player = AVPlayer(playerItem: playerItem)
        if !isAudio {
            playerLayer = AVPlayerLayer(player: player)
            playerLayer?.frame = videoPreviewView.bounds
            playerLayer?.videoGravity = .resizeAspect
            videoPreviewView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }
            videoPreviewView.layer.addSublayer(playerLayer!)
        } else {
            videoPreviewView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }
        }
        setupAudioSession()
        isPlaying = true
        player?.play()
        
        playerItemEndObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            self.isPlaying = false
            self.player?.seek(to: .zero)
        }
    }
    
    private func loadLocalAsset(asset: PHAsset, isAudio: Bool = false) {
        let options = PHVideoRequestOptions()
        options.isNetworkAccessAllowed = true
        options.deliveryMode = .highQualityFormat
        
        PHImageManager.default().requestPlayerItem(forVideo: asset, options: options) { [weak self] playerItem, _ in
            guard let self = self, let item = playerItem else { return }
            
            DispatchQueue.main.async {
                item.addObserver(self, forKeyPath: #keyPath(AVPlayerItem.status), options: [.new], context: nil)
                self.player = AVPlayer(playerItem: item)
                
                if !isAudio {
                    self.playerLayer = AVPlayerLayer(player: self.player)
                    self.playerLayer?.frame = self.videoPreviewView.bounds
                    self.playerLayer?.videoGravity = .resizeAspect
                    self.videoPreviewView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }
                    self.videoPreviewView.layer.addSublayer(self.playerLayer!)
                }
                
                self.setupAudioSession()
                self.isPlaying = true
                self.player?.play()
                
                self.playerItemEndObserver = NotificationCenter.default.addObserver(
                    forName: .AVPlayerItemDidPlayToEndTime,
                    object: self.player?.currentItem,
                    queue: .main
                ) { [weak self] _ in
                    guard let self = self else { return }
                    self.isPlaying = false
                    self.player?.seek(to: .zero)
                }
            }
        }
    }
    
    private func setupAudioSession() {
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch {
            print("VideoCastVC: Failed to configure audio session: \(error.localizedDescription)")
        }
    }
    
    private func setupVideoPlayer(with url: URL) {
        player?.pause()
        stopPlaybackTimeChecker()
        playerLayer?.removeFromSuperlayer()
        
        let asset = AVAsset(url: url)
        let playerItem = AVPlayerItem(asset: asset)
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoPreviewView.bounds
        playerLayer?.videoGravity = .resizeAspect
        
        if let playerLayer = playerLayer {
            videoPreviewView.layer.addSublayer(playerLayer)
        }
    }
    
    private func cleanupPlayer(isStop: Bool = true) {
        stopVideoTimer()
        player?.pause()
        
        if let observer = playerItemEndObserver {
            NotificationCenter.default.removeObserver(observer)
            playerItemEndObserver = nil
        }
        
        player?.currentItem?.removeObserver(self, forKeyPath: #keyPath(AVPlayerItem.status), context: nil)
        player?.replaceCurrentItem(with: nil)
        playerLayer?.removeFromSuperlayer()
        
        player = nil
        playerLayer = nil
        isPlaying = false
        
        if isStop {
            if selectedTvType == .LGTV {
                setPlaceHolder(connectedTvType: .LGTV)
            } else if selectedTvType == .GcastTV {
                setPlaceHolder(connectedTvType: .GcastTV)
            }
        }
    }
    
    private func stopVideoTimer() {
        videoTimer?.invalidate()
        videoTimer = nil
    }
    
    // MARK: - Playback Control Methods
    
    @objc private func tapOnVideoLayer(_ tap: UITapGestureRecognizer) {
        // Only handle tap for local videos, not web videos
        if mediatype == .Web {
            return
        }
        
        if isPlaying {
            player?.pause()
            stopPlaybackTimeChecker()
            trimmerView.hideTracker(true)
        } else {
            // CASE 1: Play video from selected range when tapped on video preview
            if restartOnPlay {
                seekVideoToPos(startTime)
                trimmerView.seek(toTime: startTime)
                restartOnPlay = false
            }
            player?.play()
            startPlaybackTimeChecker()
            trimmerView.hideTracker(false)
        }
        isPlaying = !isPlaying
    }
    
    @objc func appDidEnterBackground() {
        if isPlaying {
            if shouldCastToTV {
                commonViewModel.togglePauseResume()
            } else {
                player?.pause()
            }
        }
    }
    
    @objc func appWillEnterForeground() {
        if isPlaying {
            if shouldCastToTV {
                commonViewModel.togglePauseResume()
            } else {
                player?.play()
            }
        }
    }
    
    private func startPlaybackTimeChecker() {
        stopPlaybackTimeChecker()
        
        playbackTimeCheckerTimer = Timer.scheduledTimer(
            timeInterval: 0.1,
            target: self,
            selector: #selector(onPlaybackTimeCheckerTimer),
            userInfo: nil,
            repeats: true
        )
    }
    
    private func stopPlaybackTimeChecker() {
        playbackTimeCheckerTimer?.invalidate()
        playbackTimeCheckerTimer = nil
    }
    
    @objc private func onPlaybackTimeCheckerTimer() {
        guard let player = player else { return }
        
        let curTime = player.currentTime()
        let seconds = CMTimeGetSeconds(curTime)
        
        if seconds < 0 {
            videoPlaybackPosition = 0
        } else {
            videoPlaybackPosition = CGFloat(seconds)
        }
        
        if mediatype != .Web {
            trimmerView.seek(toTime: videoPlaybackPosition)
        }
        
        if videoPlaybackPosition >= stopTime {
            videoPlaybackPosition = startTime
            seekVideoToPos(startTime)
            if mediatype != .Web {
                trimmerView.seek(toTime: startTime)
            }
        }
    }
    
    private func seekVideoToPos(_ pos: CGFloat) {
        videoPlaybackPosition = pos
        let time = CMTimeMakeWithSeconds(Float64(videoPlaybackPosition), preferredTimescale: player?.currentTime().timescale ?? 600)
        player?.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero)
    }
    
    // MARK: - Button Actions
    
    @IBAction func connectDeviceButtonTap(_ sender: Any) {
        let deviceVC: ListDeviceVc = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
        self.navigationController?.pushViewController(deviceVC, animated: true)
    }
    
    @IBAction func backButtonTap(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func modeButtonTap(_ sender: Any) {
        let currentOrientation = UIApplication.shared.statusBarOrientation
        
        if currentOrientation == .portrait {
            let value = UIInterfaceOrientation.landscapeRight.rawValue
            UIDevice.current.setValue(value, forKey: "orientation")
        } else {
            let value = UIInterfaceOrientation.portrait.rawValue
            UIDevice.current.setValue(value, forKey: "orientation")
        }
        
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
    }
    
    @IBAction func minusVolumButtonTap(_ sender: Any) {
        addHaptic()
        if selectedTvType == .LGTV{
            commonViewModel.connectSDKDiscoveryModel.selectedLGDevice?.volumeControl().volumeDown { sucess in
            } failure: { error in
            }
        }else{
            volumeController.volumeDown()
        }
    }
    
    @IBAction func plusVolumButtonTap(_ sender: Any) {
        addHaptic()
        if selectedTvType == .LGTV{
            commonViewModel.connectSDKDiscoveryModel.selectedLGDevice?.volumeControl().volumeUp { sucess in
            } failure: { error in
            }
        }else{
            volumeController.volumeUp()
        }
    }
    
    @IBAction func nextVideoButtonTap(_ sender: Any) {
        if mediatype == .Web {
            // Handle next video for web videos
            guard videoList.count > 0 else { return }
            
            player?.pause()
            stopPlaybackTimeChecker()
            isPlaying = false
            
            selectedIndex = (selectedIndex + 1) % videoList.count
            setupWebVideo()
        } else {
            // Handle next video for local videos
            guard videoAssets.count > 0 else { return }
            
            player?.pause()
            stopPlaybackTimeChecker()
            isPlaying = false
            
            selectedIndex = (selectedIndex + 1) % videoAssets.count
            loadVideo()
        }
    }
    
    @IBAction func previousVideoButtonTap(_ sender: Any) {
        if mediatype == .Web {
            // Handle previous video for web videos
            guard videoList.count > 0 else { return }
            
            player?.pause()
            stopPlaybackTimeChecker()
            isPlaying = false
            
            selectedIndex = selectedIndex == 0 ? videoList.count - 1 : selectedIndex - 1
            setupWebVideo()
        } else {
            // Handle previous video for local videos
            guard videoAssets.count > 0 else { return }
            
            player?.pause()
            stopPlaybackTimeChecker()
            isPlaying = false
            
            selectedIndex = selectedIndex == 0 ? videoAssets.count - 1 : selectedIndex - 1
            loadVideo()
        }
    }
    
    @IBAction func playVideoCastButtonTap(_ sender: Any) {
        // First, make sure we have a video loaded
        if videoURL == nil && selectedVideoAsset == nil && mediatype != .Web {
            // If no video is loaded, load the current video first
            loadVideo()
            
            // Wait a moment for video to load, then call setupVideoPlay
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.setupVideoPlay()
            }
        } else {
            // Video is already loaded, start casting
            setupVideoPlay()
        }
        
        isPlaying = true
    }
    
    // MARK: - Existing Casting Methods (kept for local videos)
    private func castOriginalVideoWithSeek(url: URL) {
        if shouldCastToTV {
            if checkAirPlayStatus().1 {
                // AirPlay is connected
                setupLocalPlaybackWithURLAndSeek(url: url, startTime: startTime)
            } else {
                DispatchQueue.main.async {
                    if commonViewModel.getConnectedTvType() == .LGTV {
                        commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(
                            titleStr: self.channelName ?? "\(APP_NAME)",
                            subtitleStr: ""
                        )
                        commonViewModel.connectSDKDiscoveryModel.sendMediaToLGTVYT(
                            mediaUrl: url,
                            mimeType: "video/mp4"
                        )
                        commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                            print("Started casting to LG TV (with selected start position)")
                        }
                    } else if commonViewModel.getConnectedTvType() == .GcastTV {
                        commonViewModel.castViewModel.castDetail = CastDetail(
                            titleStr: self.channelName ?? "\(APP_NAME)",
                            subtitleStr: ""
                        )
                        commonViewModel.CastMedia(
                            url: url,
                            mediaType: "video/mp4",
                            imgHei: 1024,
                            imgWid: 1024
                        )
                        commonViewModel.castViewModel.onStartVideo = {
                            print("Started casting to Google Cast (with selected start position)")
                        }
                    }
                }
            }
        } else {
            // Setup local playback with seek
            setupLocalPlaybackWithURLAndSeek(url: url, startTime: startTime)
        }
    }
    
    private func setupLocalPlaybackWithURLAndSeek(url: URL, startTime: CGFloat) {
        // Setup local player with the provided URL and seek to start position
        let playerItem = AVPlayerItem(url: url)
        playerItem.addObserver(self, forKeyPath: #keyPath(AVPlayerItem.status), options: [.new], context: nil)
        
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoPreviewView.bounds
        playerLayer?.videoGravity = .resizeAspect
        videoPreviewView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }
        videoPreviewView.layer.addSublayer(playerLayer!)
        
        setupAudioSession()
        isPlaying = true
        
        // Seek to the selected start time before playing
        let startCMTime = CMTimeMakeWithSeconds(Float64(startTime), preferredTimescale: 600)
        player?.seek(to: startCMTime, toleranceBefore: .zero, toleranceAfter: .zero) { [weak self] _ in
            self?.player?.play()
        }
        
        // Remove previous observer
        if let observer = playerItemEndObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        
        playerItemEndObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            self.isPlaying = false
            // Seek back to the selected start time instead of zero
            let startCMTime = CMTimeMakeWithSeconds(Float64(self.startTime), preferredTimescale: 600)
            self.player?.seek(to: startCMTime)
        }
    }

    private func castVideo(url: URL, isTrimmed: Bool) {
        if shouldCastToTV {
            if checkAirPlayStatus().1 {
                // AirPlay is connected, setup local playback with trimmed video
                setupLocalPlaybackWithURL(url)
            } else {
                DispatchQueue.main.async {
                    if commonViewModel.getConnectedTvType() == .LGTV {
                        commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(
                            titleStr: self.channelName ?? "\(APP_NAME)",
                            subtitleStr: isTrimmed ? "Trimmed Video" : ""
                        )
                        commonViewModel.connectSDKDiscoveryModel.sendMediaToLGTVYT(
                            mediaUrl: url,
                            mimeType: "video/mp4"
                        )
                        commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                            print("Started casting \(isTrimmed ? "trimmed " : "")video to LG TV")
                        }
                    } else if commonViewModel.getConnectedTvType() == .GcastTV {
                        commonViewModel.castViewModel.castDetail = CastDetail(
                            titleStr: self.channelName ?? "\(APP_NAME)",
                            subtitleStr: isTrimmed ? "Trimmed Video" : ""
                        )
                        commonViewModel.CastMedia(
                            url: url,
                            mediaType: "video/mp4",
                            imgHei: 1024,
                            imgWid: 1024
                        )
                        commonViewModel.castViewModel.onStartVideo = {
                            print("Started casting \(isTrimmed ? "trimmed " : "")video to Google Cast")
                        }
                    }
                }
            }
        } else {
            // Setup local playback
            setupLocalPlaybackWithURL(url)
        }
    }
    
    private func setupLocalPlaybackWithURL(_ url: URL) {
        // Setup local player with the provided URL
        let playerItem = AVPlayerItem(url: url)
        playerItem.addObserver(self, forKeyPath: #keyPath(AVPlayerItem.status), options: [.new], context: nil)
        
        player = AVPlayer(playerItem: playerItem)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoPreviewView.bounds
        playerLayer?.videoGravity = .resizeAspect
        videoPreviewView.layer.sublayers?.forEach { $0.removeFromSuperlayer() }
        videoPreviewView.layer.addSublayer(playerLayer!)
        
        setupAudioSession()
        isPlaying = true
        player?.play()
        
        // Remove previous observer
        if let observer = playerItemEndObserver {
            NotificationCenter.default.removeObserver(observer)
        }
        
        playerItemEndObserver = NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem,
            queue: .main
        ) { [weak self] _ in
            guard let self = self else { return }
            self.isPlaying = false
            self.player?.seek(to: .zero)
        }
    }
    
    private func castAssetWithSelectedRange(asset: PHAsset) {
        // For PHAsset with selected range, we need to trim it first
        asset.getMediaFileURL { [weak self] url in
            guard let self = self, let url = url else { return }
            
            self.createTrimmedVideo(from: url, startTime: self.startTime, endTime: self.stopTime) { trimmedURL in
                DispatchQueue.main.async {
                    if let trimmedURL = trimmedURL {
                        // Cast the trimmed video
                        self.castVideo(url: trimmedURL, isTrimmed: true)
                    } else {
                        // If trimming fails, cast the original video
                        NotificationCenter.default.addObserver(self, selector: #selector(self.appDidEnterBackground), name: UIApplication.didEnterBackgroundNotification, object: nil)
                        NotificationCenter.default.addObserver(self, selector: #selector(self.appWillEnterForeground), name: UIApplication.willEnterForegroundNotification, object: nil)
                        
                        if commonViewModel.getConnectedTvType() == .LGTV {
                            commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                                print("Started casting video to LG TV")
                            }
                            commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(titleStr: "Video Player", subtitleStr: "")
                        } else if commonViewModel.getConnectedTvType() == .GcastTV {
                            commonViewModel.castViewModel.castDetail = CastDetail(titleStr: "Video Player", subtitleStr: "")
                        }
                        commonViewModel.compressAndUploadVideo(url, selectedQuality: 2)
                    }
                }
            }
        }
    }
    
    private func createTrimmedVideo(from url: URL, startTime: CGFloat, endTime: CGFloat, completion: @escaping (URL?) -> Void) {
        let asset = AVAsset(url: url)
        let startCMTime = CMTimeMakeWithSeconds(Float64(startTime), preferredTimescale: 600)
        let endCMTime = CMTimeMakeWithSeconds(Float64(endTime), preferredTimescale: 600)
        let timeRange = CMTimeRange(start: startCMTime, end: endCMTime)
        
        // Create export session
        guard let exportSession = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetHighestQuality) else {
            completion(nil)
            return
        }
        
        // Create output URL
        let documentsDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let outputURL = documentsDirectory.appendingPathComponent("trimmed_video_\(Date().timeIntervalSince1970).mp4")
        
        // Delete file if it exists
        try? FileManager.default.removeItem(at: outputURL)
        
        // Configure export session
        exportSession.outputURL = outputURL
        exportSession.outputFileType = .mp4
        exportSession.timeRange = timeRange
        
        exportSession.exportAsynchronously {
            DispatchQueue.main.async {
                switch exportSession.status {
                case .completed:
                    completion(outputURL)
                case .failed, .cancelled:
                    print("Video trimming failed: \(exportSession.error?.localizedDescription ?? "Unknown error")")
                    completion(nil)
                default:
                    completion(nil)
                }
            }
        }
    }

    // MARK: - Casting Methods (for local videos)
    
    private func startCasting() {
        // Check if we have a video to cast
        guard selectedVideoAsset != nil || videoURL != nil else {
            print("No video to cast")
            return
        }
        
        // Check device connection
        if commonViewModel.getConnectedTvType() == .noneTV {
            showDeviceConnectionAlert()
            return
        }
        
        // Setup casting based on device type
        if checkAirPlayStatus().1 {
            castViaAirPlay()
        } else if commonViewModel.getConnectedTvType() == .LGTV {
            castToLGTV()
        } else if commonViewModel.getConnectedTvType() == .GcastTV {
            castToGoogleCast()
        }
    }
    
    private func castToLGTV() {
        if let url = videoURL {
            commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(
                titleStr: channelName ?? "Video",
                subtitleStr: ""
            )
            commonViewModel.connectSDKDiscoveryModel.sendMediaToLGTVYT(
                mediaUrl: url,
                mimeType: "video/mp4"
            )
            commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                print("Started casting to LG TV")
            }
        } else if let asset = selectedVideoAsset {
            asset.getMediaFileURL { [weak self] url in
                guard let self = self, let url = url else { return }
                DispatchQueue.main.async {
                    commonViewModel.connectSDKDiscoveryModel.castDetail = CastDetail(
                        titleStr: "Video Player",
                        subtitleStr: ""
                    )
                    commonViewModel.connectSDKDiscoveryModel.onStartVideo = {
                        print("Started casting video to LG TV")
                    }
                    commonViewModel.compressAndUploadVideo(url, selectedQuality: 2)
                }
            }
        }
    }
    
    private func castToGoogleCast() {
        if let url = videoURL {
            commonViewModel.castViewModel.castDetail = CastDetail(
                titleStr: channelName ?? "Video",
                subtitleStr: ""
            )
            commonViewModel.CastMedia(
                url: url,
                mediaType: "video/mp4",
                imgHei: 1024,
                imgWid: 1024
            )
            commonViewModel.castViewModel.onStartVideo = {
                print("Started casting to Google Cast")
            }
        } else if let asset = selectedVideoAsset {
            asset.getMediaFileURL { [weak self] url in
                guard let self = self, let url = url else { return }
                DispatchQueue.main.async {
                    commonViewModel.castViewModel.castDetail = CastDetail(
                        titleStr: "Video Player",
                        subtitleStr: ""
                    )
                    commonViewModel.compressAndUploadVideo(url, selectedQuality: 2)
                }
            }
        }
    }
    
    private func castViaAirPlay() {
        guard let url = videoURL else { return }
        
        let player = AVPlayer(url: url)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        
        playerViewController.allowsPictureInPicturePlayback = true
        playerViewController.player?.allowsExternalPlayback = true
        playerViewController.player?.usesExternalPlaybackWhileExternalScreenIsActive = true
        
        present(playerViewController, animated: true) {
            player.play()
        }
    }
    
    private func pauseCasting() {
        commonViewModel.togglePauseResume()
    }
    
    private func resumeCasting() {
        commonViewModel.togglePauseResume()
    }
    
    private func showDeviceConnectionAlert() {
        let alert = UIAlertController(
            title: "No Device Connected",
            message: "Please connect to a TV device to start casting.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Connect Device", style: .default) { _ in
            self.connectDeviceButtonTap(self)
        })
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(alert, animated: true)
    }
    
    // MARK: - Helper Methods
    
    private func checkAirPlayStatus() -> (Bool, Bool) {
        // Implement your AirPlay status check logic
        return (false, false) // Placeholder
    }
}

// MARK: - ICGVideoTrimmerDelegate
extension VideoCastVC: ICGVideoTrimmerDelegate {
    func trimmerView(_ trimmerView: ICGVideoTrimmerView!, didChangeLeftPosition startTime: CGFloat, rightPosition endTime: CGFloat) {
        // Only handle trimmer for local videos
        if mediatype == .Web {
            return
        }
        
        // Update the selected range
        restartOnPlay = true
        player?.pause()
        isPlaying = false
        stopPlaybackTimeChecker()
        
        trimmerView.hideTracker(true)
        
        // Store the selected range
        self.startTime = startTime
        self.stopTime = endTime
        
        // Update the video preview to show the start of selected range
        seekVideoToPos(startTime)
        
        print("Selected range: \(startTime) - \(endTime) seconds")
    }
}
