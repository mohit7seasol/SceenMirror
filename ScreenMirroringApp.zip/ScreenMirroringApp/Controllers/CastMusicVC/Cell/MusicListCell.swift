//
//  MusicListCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 06/01/26.
//

import UIKit

class MusicListCell: UITableViewCell {

    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var musicPosterImageView: UIImageView!
    @IBOutlet weak var musicNameLabel: UILabel!
    @IBOutlet weak var singerNameLabel: UILabel!
    @IBOutlet weak var musicDurationLabel: UILabel!
    @IBOutlet weak var favouriteButton: UIButton!
    @IBOutlet weak var cellBottomLineSepratorImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
