//
//  FavouriteMusicVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 06/01/26.
//

import UIKit

class FavouriteMusicVC: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }

    func setUI() {
        setTable()
    }
    func setTable() {
        
    }
}
// MARK: - Button Actions
extension FavouriteMusicVC {
    
    @IBAction func backButtonTap(_ sender: Any) {
    }
}
