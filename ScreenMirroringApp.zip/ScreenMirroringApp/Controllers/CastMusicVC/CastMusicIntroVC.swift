//
//  CastMusicIntroVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 06/01/26.
//

import UIKit

class CastMusicIntroVC: UIViewController {

    @IBOutlet weak var enjouMusicLbl: UILabel!
    @IBOutlet weak var playSongLbl: UILabel!
    @IBOutlet weak var swipToMusicLbl: UILabel!
    @IBOutlet weak var swipeCircleView: UIView!
    @IBOutlet weak var swipeParentView: GradientDesignableView!
    
    private var panGesture: UIPanGestureRecognizer!
    private var swipeCircleViewOriginalCenter: CGPoint!
    private var isSwiped = false
    private var rotationAnimation: CABasicAnimation?
    private var hintAnimationTimer: Timer?
    
    // Reference to HomeVC for navigation
    weak var homeViewController: HomeVC?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        setupSwipeGesture()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Start hint animation after a short delay
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.startHintAnimation()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        stopHintAnimation()
    }

    func setUI() {
        swipToMusicLbl.textColor = .white
        
        // Configure swipeParentView with transparent gradient and shadow
        swipeParentView.cornerRadius = 30
        swipeParentView.bgGradientDirection = 1 // Left to Right
        swipeParentView.bgGradientOpacity = 1.0 // Fully transparent
        
        // Add border gradient for visual effect only (no background)
        swipeParentView.borderGradientDirection = 0 // Top to Bottom
        swipeParentView.borderWidth = 1
        
        // Add shadow to swipeParentView (outside the view)
        swipeParentView.layer.masksToBounds = false
        swipeParentView.layer.shadowColor = UIColor(red: 0.29, green: 0.56, blue: 1, alpha: 0.15).cgColor
        swipeParentView.layer.shadowOffset = CGSize(width: 0, height: 8)
        swipeParentView.layer.shadowOpacity = 0.3
        swipeParentView.layer.shadowRadius = 15
        
        // Configure swipeCircleView
        swipeCircleView.layer.cornerRadius = swipeCircleView.frame.height / 2
        swipeCircleView.clipsToBounds = true
        
        // Add gradient to swipeCircleView
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = swipeCircleView.bounds
        gradientLayer.colors = [
            UIColor(red: 0.95, green: 0.95, blue: 1, alpha: 1).cgColor,
            UIColor(red: 0.85, green: 0.85, blue: 1, alpha: 1).cgColor
        ]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
        gradientLayer.cornerRadius = swipeCircleView.frame.height / 2
        swipeCircleView.layer.insertSublayer(gradientLayer, at: 0)
        
        // Add inner shadow/glow to swipeCircleView
        swipeCircleView.layer.shadowColor = UIColor.white.cgColor
        swipeCircleView.layer.shadowOffset = CGSize(width: 0, height: 2)
        swipeCircleView.layer.shadowOpacity = 0.3
        swipeCircleView.layer.shadowRadius = 4
        
        // Add icon/image to swipeCircleView for spin effect
        let iconImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 24, height: 24))
        iconImageView.center = CGPoint(x: swipeCircleView.bounds.width / 2, y: swipeCircleView.bounds.height / 2)
        iconImageView.contentMode = .scaleAspectFit
        swipeCircleView.addSubview(iconImageView)
        
        // Save original position
        swipeCircleViewOriginalCenter = swipeCircleView.center
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        // Update gradient layers frame after layout
        if let gradientLayer = swipeCircleView.layer.sublayers?.first as? CAGradientLayer {
            gradientLayer.frame = swipeCircleView.bounds
        }
    }
    
    // MARK: - Hint Animation
    private func startHintAnimation() {
        // Stop any existing animation
        stopHintAnimation()
        
        // Create timer for repeating hint animation
        hintAnimationTimer = Timer.scheduledTimer(withTimeInterval: 5.0, repeats: true) { [weak self] _ in
            self?.performHintAnimation()
        }
        
        // Perform first animation immediately
        performHintAnimation()
    }
    
    private func performHintAnimation() {
        guard let originalCenter = swipeCircleViewOriginalCenter else { return }
        
        // Calculate target position (80% of the way to the right)
        let targetX = swipeParentView.frame.width - swipeCircleView.frame.width / 2 - 10
        let distance = targetX - originalCenter.x
        let hintDistance = distance * 0.1 // Move 10% of the way for hint
        
        // First move to the right with bounce effect
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseOut], animations: {
            self.swipeCircleView.center.x = originalCenter.x + hintDistance
        }) { _ in
            // Bounce back with spring effect
            UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
                self.swipeCircleView.center = originalCenter
            })
        }
    }
    
    private func stopHintAnimation() {
        hintAnimationTimer?.invalidate()
        hintAnimationTimer = nil
        // Reset position
        swipeCircleView.center = swipeCircleViewOriginalCenter
        swipeCircleView.transform = .identity
    }
    
    // MARK: - Swipe Gesture
    func setupSwipeGesture() {
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        swipeCircleView.addGestureRecognizer(panGesture)
        swipeCircleView.isUserInteractionEnabled = true
    }
    
    @objc func handlePanGesture(_ gesture: UIPanGestureRecognizer) {
        // Stop hint animation when user starts interacting
        if gesture.state == .began {
            stopHintAnimation()
        }
        
        let translation = gesture.translation(in: swipeParentView)
        
        switch gesture.state {
        case .began, .changed:
            // Calculate new X position with bounds checking
            let newX = swipeCircleViewOriginalCenter.x + translation.x
            let minX = swipeCircleView.frame.width / 2 + 10
            let maxX = swipeParentView.frame.width - swipeCircleView.frame.width / 2 - 10
            
            if newX >= minX && newX <= maxX {
                swipeCircleView.center.x = newX
                
                // Rotate icon based on swipe progress
                let progress = (newX - minX) / (maxX - minX)
                let rotationAngle = progress * .pi / 2 // Rotate up to 90 degrees
                if let iconImageView = swipeCircleView.subviews.first as? UIImageView {
                    iconImageView.transform = CGAffineTransform(rotationAngle: rotationAngle)
                }
            }
            
            // Add haptic feedback when reaching threshold (75% of parent width)
            let threshold = swipeParentView.frame.width * 0.75
            if !isSwiped && newX >= threshold {
                isSwiped = true
                let feedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
                feedbackGenerator.impactOccurred()
                
                // Scale animation when reaching threshold
                UIView.animate(withDuration: 0.2, animations: {
                    self.swipeCircleView.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                }) { _ in
                    UIView.animate(withDuration: 0.2) {
                        self.swipeCircleView.transform = .identity
                    }
                }
            } else if isSwiped && newX < threshold {
                isSwiped = false
            }
            
        case .ended, .cancelled:
            let swipeThreshold = swipeParentView.frame.width * 0.7
            
            if swipeCircleView.center.x >= swipeThreshold {
                // Successful swipe - animate to end and trigger next action
                animateToEndAndTriggerNextAction()
            } else {
                // Return to original position with spring animation
                UIView.animate(withDuration: 0.5,
                               delay: 0,
                               usingSpringWithDamping: 0.7,
                               initialSpringVelocity: 0.5,
                               options: .curveEaseOut,
                               animations: {
                    self.swipeCircleView.center = self.swipeCircleViewOriginalCenter
                    // Reset icon rotation
                    if let iconImageView = self.swipeCircleView.subviews.first as? UIImageView {
                        iconImageView.transform = .identity
                    }
                }) { _ in
                    // Restart hint animation after returning to original position
                    self.startHintAnimation()
                }
            }
            
            isSwiped = false
            
        default:
            break
        }
    }
    
    private func animateToEndAndTriggerNextAction() {
        let endPosition = CGPoint(
            x: swipeParentView.frame.width - swipeCircleView.frame.width / 2 - 10,
            y: swipeCircleViewOriginalCenter.y
        )
        
        // Animate to end position with spring effect
        UIView.animate(withDuration: 0.4,
                       delay: 0,
                       usingSpringWithDamping: 0.7,
                       initialSpringVelocity: 0.8,
                       options: .curveEaseOut,
                       animations: {
            self.swipeCircleView.center = endPosition
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            
            // Rotate icon to 90 degrees at end
            if let iconImageView = self.swipeCircleView.subviews.first as? UIImageView {
                iconImageView.transform = CGAffineTransform(rotationAngle: .pi / 2)
            }
        }) { _ in
            // Success animation
            UIView.animate(withDuration: 0.2, animations: {
                self.swipeCircleView.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
                self.swipeCircleView.alpha = 0.8
            }) { _ in
                UIView.animate(withDuration: 0.2) {
                    self.swipeCircleView.transform = .identity
                    self.swipeCircleView.alpha = 1
                } completion: { _ in
                    // Start spin wheel animation and open next screen
                    self.printSwipeCompletedAndStartSpinAnimation()
                }
            }
        }
    }
    
    private func printSwipeCompletedAndStartSpinAnimation() {
        print("Swipe completed! Opening next screen...")
        
        // Start spin wheel animation
        startSpinWheelAnimation()
        
        // After 1 second delay, return to left side with animation and open next screen
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
            self.openNextScreen()
        }
    }
    
    private func startSpinWheelAnimation() {
        // Create continuous rotation animation
        rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotationAnimation?.fromValue = 0
        rotationAnimation?.toValue = CGFloat.pi * 2
        rotationAnimation?.duration = 0.8
        rotationAnimation?.repeatCount = .infinity
        rotationAnimation?.isRemovedOnCompletion = false
        
        // Add animation to the icon inside swipeCircleView
        if let iconImageView = swipeCircleView.subviews.first as? UIImageView {
            iconImageView.layer.removeAllAnimations()
            iconImageView.layer.add(rotationAnimation!, forKey: "spinAnimation")
        }
    }
    
    private func returnToLeftSideWithSpinAnimation() {
        // Stop the continuous spin animation
        if let rotationAnimation = rotationAnimation {
            if let iconImageView = swipeCircleView.subviews.first as? UIImageView {
                iconImageView.layer.removeAnimation(forKey: "spinAnimation")
            }
        }
        
        // Create a final spin animation during return
        let finalSpinAnimation = CABasicAnimation(keyPath: "transform.rotation")
        finalSpinAnimation.fromValue = 0
        finalSpinAnimation.toValue = CGFloat.pi * 4 // Spin 2 full circles
        finalSpinAnimation.duration = 1.0
        
        // Add animation to the icon
        if let iconImageView = swipeCircleView.subviews.first as? UIImageView {
            iconImageView.layer.add(finalSpinAnimation, forKey: "finalSpin")
        }
        
        // Animate swipeCircleView back to left side
        UIView.animate(withDuration: 1.0,
                       delay: 0,
                       usingSpringWithDamping: 0.6,
                       initialSpringVelocity: 0.5,
                       options: .curveEaseInOut,
                       animations: {
            self.swipeCircleView.center = self.swipeCircleViewOriginalCenter
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
            
            // Reset icon rotation after spin
            if let iconImageView = self.swipeCircleView.subviews.first as? UIImageView {
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                    UIView.animate(withDuration: 0.2) {
                        iconImageView.transform = .identity
                    }
                }
            }
        }) { _ in
            UIView.animate(withDuration: 0.3) {
                self.swipeCircleView.transform = .identity
            } completion: { _ in
                // Enable interaction again
                self.swipeCircleView.isUserInteractionEnabled = true
                print("Returned to original position with spin animation")
            }
        }
    }
    
    private func openNextScreen() {
        // Stop all animations
        stopHintAnimation()
        
        // Create CastMusicListVC and present it modally
        let listVC = UIStoryboard(name: "Main", bundle: nil)
            .instantiateViewController(withIdentifier: "CastMusicListVC") as! CastMusicListVC
        
        // Set the homeViewController reference to CastMusicListVC
        listVC.homeViewController = self.homeViewController
        
        // Push to navigation controller
        self.navigationController?.pushViewController(listVC, animated: true)
    }
    
    // For testing: Reset position
    func resetSwipeCircle() {
        swipeCircleView.center = swipeCircleViewOriginalCenter
        swipeCircleView.transform = .identity
        swipeParentView.bgGradientOpacity = 0.0
        
        // Reset icon rotation
        if let iconImageView = swipeCircleView.subviews.first as? UIImageView {
            iconImageView.transform = .identity
            iconImageView.layer.removeAllAnimations()
        }
    }
    
    @IBAction func closeButtonAction(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}
