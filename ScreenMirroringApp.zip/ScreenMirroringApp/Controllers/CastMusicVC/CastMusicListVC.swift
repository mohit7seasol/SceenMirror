//
//  CastMusicListVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 06/01/26.
//

import UIKit
import MediaPlayer
import AVKit

class GlobalMusicManager {
    
    // Singleton instance
    static let shared = GlobalMusicManager()
    
    // Private initializer
    private init() {}
    
    // MARK: - Global Variables
    var currentPlayingIndex: Int = 0
    var allSongs: [MPMediaItem] = []
    
    // MARK: - Favorites Management
    var favoriteSongIDs: Set<UInt64> {
        get {
            let array = UserDefaults.standard.array(forKey: "favoriteSongIDs") as? [UInt64] ?? []
            return Set(array)
        }
        set {
            UserDefaults.standard.set(Array(newValue), forKey: "favoriteSongIDs")
        }
    }
    
    // MARK: - Helper Methods
    
    func getFavoriteSongs() -> [MPMediaItem] {
        return allSongs.filter { favoriteSongIDs.contains($0.persistentID) }
    }
    
    func toggleFavorite(for song: MPMediaItem) {
        let pid = song.persistentID
        if favoriteSongIDs.contains(pid) {
            favoriteSongIDs.remove(pid)
        } else {
            favoriteSongIDs.insert(pid)
        }
    }
    
    func isFavorite(_ song: MPMediaItem) -> Bool {
        return favoriteSongIDs.contains(song.persistentID)
    }
    
    func findSongIndex(persistentID: UInt64) -> Int? {
        return allSongs.firstIndex { $0.persistentID == persistentID }
    }
    
    func findSongIndexInDisplayed(persistentID: UInt64, displayedSongs: [MPMediaItem]) -> Int? {
        return displayedSongs.firstIndex { $0.persistentID == persistentID }
    }
    
    var currentSong: MPMediaItem? {
        guard currentPlayingIndex >= 0 && currentPlayingIndex < allSongs.count else {
            return nil
        }
        return allSongs[currentPlayingIndex]
    }
    
    func isValidIndex(_ index: Int, in songs: [MPMediaItem]) -> Bool {
        return index >= 0 && index < songs.count
    }
}

class CastMusicListVC: UIViewController {

    // MARK: - IBOutlets (keep all your existing IBOutlets)
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var favouriteLabel: UILabel!
    @IBOutlet weak var viewAllButton: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var musicLabel: UILabel!
    @IBOutlet weak var favouriteSectionView: UIView!
    @IBOutlet weak var favouriteSectionHeightConstant: NSLayoutConstraint!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var PrePlayingMusicView: UIView!
    @IBOutlet weak var prePlayingImageView: UIImageView!
    @IBOutlet weak var preMusicNameLabel: UILabel!
    @IBOutlet weak var preMusicArtistNameLabel: UILabel!
    @IBOutlet weak var preMusicPlayButton: UIButton!
    @IBOutlet weak var preMusicShuffleButton: UIButton!
    @IBOutlet weak var preMusicRepeatButton: UIButton!
    @IBOutlet weak var preMusicProgressView: UIProgressView!
    
    // MARK: - Properties
    weak var homeViewController: HomeVC?
    
    // Music data
    var allSongs: [MPMediaItem] = []
    var displayedSongs: [MPMediaItem] = []
    
    // For music playback
    var audioPlayer: AVAudioPlayer?
    var isPlaying = false
    
    private var panGesture: UIPanGestureRecognizer!
    private var initialCenter: CGPoint = .zero
    var isPrePlayingViewVisible = false
    
    // MARK: - Playback state
    var isShuffle = false
    var isRepeat = false
    
    // No music label
    private let noMusicLabel: UILabel = {
        let label = UILabel()
        label.text = "No music found"
        label.textColor = .gray
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.textAlignment = .center
        label.isHidden = true
        label.numberOfLines = 0
        return label
    }()
    
    private var shouldUpdateTableViewCell = true
    private var displayLink: CADisplayLink?
    
    // Cast Music Airplay
    var playerViewController: AVPlayerViewController?
    var player: AVPlayer?
    var isFromFavorite: Bool = false
    var isUploading = false
    
    // Computed property for currently playing index
    var currentlyPlayingIndex: Int? {
        get {
            // Get from GlobalMusicManager but convert to displayedSongs index
            let globalIndex = GlobalMusicManager.shared.currentPlayingIndex
            if let currentSong = GlobalMusicManager.shared.currentSong {
                return displayedSongs.firstIndex { $0.persistentID == currentSong.persistentID }
            }
            return nil
        }
        set {
            // When setting, update GlobalMusicManager
            if let newValue = newValue, newValue < displayedSongs.count {
                let song = displayedSongs[newValue]
                if let globalIndex = GlobalMusicManager.shared.findSongIndex(persistentID: song.persistentID) {
                    GlobalMusicManager.shared.currentPlayingIndex = globalIndex
                }
            }
        }
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        setupNoMusicLabel()
        requestPermissionAndFetchSongs()
        setupPrePlayingMusicView()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateFavoritesCollectionVisibility()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        scrollView.contentInset.bottom = 0
        scrollView.verticalScrollIndicatorInsets.bottom = 0
    }
    
    func setUI() {
        setTable()
        setColelcetionView()
        updateFavoritesCollectionVisibility()
        if #available(iOS 11.0, *) {
            scrollView.contentInsetAdjustmentBehavior = .never
        }
    }
    
    private func setupNoMusicLabel() {
        view.addSubview(noMusicLabel)
        noMusicLabel.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            noMusicLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            noMusicLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            noMusicLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            noMusicLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20)
        ])
    }
    
    func setTable() {
        self.tableView.delegate = self
        self.tableView.dataSource = self
        self.tableView.register(["MusicListCell"])
        self.tableView.rowHeight = 70
        self.tableView.separatorStyle = .none
        self.tableView.backgroundColor = .clear
        self.tableView.showsVerticalScrollIndicator = false
        self.tableView.showsHorizontalScrollIndicator = false
    }
    
    func setColelcetionView() {
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.collectionView.register(["FavouriteMusicCell"])
        self.collectionView.showsHorizontalScrollIndicator = false
        
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
            layout.minimumLineSpacing = 10
            layout.minimumInteritemSpacing = 0
            layout.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 0)
        }
    }
    
    // MARK: - Progress Tracking
    private func startProgressTracking() {
        stopProgressTracking()
        
        displayLink = CADisplayLink(target: self, selector: #selector(updateProgressView))
        displayLink?.add(to: .main, forMode: .common)
    }

    private func stopProgressTracking() {
        displayLink?.invalidate()
        displayLink = nil
    }

    @objc private func updateProgressView() {
        guard let player = audioPlayer else { return }
        
        let currentTime = player.currentTime
        let duration = player.duration
        
        if duration > 0 {
            let progress = Float(currentTime / duration)
            preMusicProgressView.progress = progress
        }
    }
    
    // MARK: - Music Permission & Fetching
    func requestPermissionAndFetchSongs() {
        let status = MPMediaLibrary.authorizationStatus()
        if status == .authorized {
            fetchSongs()
        } else {
            MPMediaLibrary.requestAuthorization { [weak self] newStatus in
                DispatchQueue.main.async {
                    if newStatus == .authorized {
                        self?.fetchSongs()
                    } else {
                        self?.showPermissionAlert()
                    }
                }
            }
        }
    }
    
    func showPermissionAlert() {
        let alert = UIAlertController(
            title: "Permission Required",
            message: "Please allow access to your Music Library in Settings",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "Open Settings", style: .default) { _ in
            if let url = URL(string: UIApplication.openSettingsURLString) {
                UIApplication.shared.open(url)
            }
        })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alert, animated: true)
    }
    
    func fetchSongs() {
        let query = MPMediaQuery.songs()
        query.addFilterPredicate(MPMediaPropertyPredicate(value: false, forProperty: MPMediaItemPropertyIsCloudItem))
        
        guard let items = query.items else {
            handleNoSongsFound()
            return
        }
        
        allSongs = items.filter { $0.assetURL != nil }
        displayedSongs = allSongs
        
        // Update GlobalMusicManager with all songs
        GlobalMusicManager.shared.allSongs = allSongs
        
        DispatchQueue.main.async {
            self.updateNoMusicLabelVisibility()
            self.tableView.reloadData()
            self.updateFavoritesCollectionVisibility()
            self.collectionView.reloadData()
        }
    }
    
    private func handleNoSongsFound() {
        DispatchQueue.main.async {
            self.allSongs = []
            self.displayedSongs = []
            GlobalMusicManager.shared.allSongs = []
            self.updateNoMusicLabelVisibility()
            self.tableView.reloadData()
            self.updateFavoritesCollectionVisibility()
            self.collectionView.reloadData()
        }
    }
    
    private func updateNoMusicLabelVisibility() {
        noMusicLabel.isHidden = !displayedSongs.isEmpty
        tableView.isHidden = displayedSongs.isEmpty
    }
    
    // MARK: - Favorites Management
    func getFavoriteSongs() -> [MPMediaItem] {
        return GlobalMusicManager.shared.getFavoriteSongs()
    }
    
    func toggleFavorite(for song: MPMediaItem) {
        GlobalMusicManager.shared.toggleFavorite(for: song)
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
            self.updateFavoritesCollectionVisibility()
            self.collectionView.reloadData()
        }
    }
    
    func isFavorite(_ song: MPMediaItem) -> Bool {
        return GlobalMusicManager.shared.isFavorite(song)
    }
    
    func updateFavoritesCollectionVisibility() {
        let hasFavorites = !getFavoriteSongs().isEmpty
        favouriteSectionView.isHidden = !hasFavorites
        favouriteLabel.isHidden = !hasFavorites
        favouriteSectionHeightConstant.constant = hasFavorites ? 140 : 0
    }
    
    // MARK: - Music Playback
    func playSong(at index: Int, fromTableView: Bool = true, showPrePlayingView: Bool = false) {
        guard index < displayedSongs.count else { return }
        
        let song = displayedSongs[index]
        
        // Update GlobalMusicManager with current playing index
        if let globalIndex = GlobalMusicManager.shared.findSongIndex(persistentID: song.persistentID) {
            GlobalMusicManager.shared.currentPlayingIndex = globalIndex
        }
        
        // Stop currently playing song if any
        if let currentIndex = currentlyPlayingIndex, currentIndex != index {
            if let cell = tableView.cellForRow(at: IndexPath(row: currentIndex, section: 0)) as? MusicListCell {
                cell.playButton.setImage(UIImage(named: "play1"), for: .normal)
            }
            audioPlayer?.stop()
            stopProgressTracking()
        }
        
        // Toggle play/pause
        if currentlyPlayingIndex == index && isPlaying {
            // Pause
            audioPlayer?.pause()
            isPlaying = false
            stopProgressTracking()
            
            if isPrePlayingViewVisible {
                preMusicPlayButton.setImage(UIImage(named: "play1"), for: .normal)
            }
            
            if let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? MusicListCell {
                cell.playButton.setImage(UIImage(named: "play1"), for: .normal)
            }
            
        } else {
            // Play
            if let url = song.assetURL {
                do {
                    try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
                    try AVAudioSession.sharedInstance().setActive(true)
                    
                    if audioPlayer == nil || currentlyPlayingIndex != index {
                        audioPlayer = try AVAudioPlayer(contentsOf: url)
                        audioPlayer?.delegate = self
                        preMusicProgressView.progress = 0
                    }
                    
                    audioPlayer?.prepareToPlay()
                    audioPlayer?.play()
                    
                    isPlaying = true
                    startProgressTracking()
                    
                    if showPrePlayingView {
                        if !isPrePlayingViewVisible {
                            showPrePlayingMusicView(with: song, at: index)
                        } else {
                            updatePrePlayingMusicView(with: song, at: index)
                        }
                    }
                    
                    if isPrePlayingViewVisible {
                        preMusicPlayButton.setImage(UIImage(named: "pause1"), for: .normal)
                    }
                    
                    if let prevIndex = currentlyPlayingIndex, prevIndex != index,
                       let prevCell = tableView.cellForRow(at: IndexPath(row: prevIndex, section: 0)) as? MusicListCell {
                        prevCell.playButton.setImage(UIImage(named: "play1"), for: .normal)
                    }
                    
                    if let cell = tableView.cellForRow(at: IndexPath(row: index, section: 0)) as? MusicListCell {
                        cell.playButton.setImage(UIImage(named: "pause1"), for: .normal)
                    }
                    
                    // Cast Music
                    DispatchQueue.main.async {
                        commonViewModel.exportAndUploadMusic(track: song)
                        commonViewModel.startPlaybackUpdates()
                    }
                    
                } catch {
                    print("Error playing song: \(error)")
                    showAlert(title: "Error", message: "Cannot play this song")
                }
            } else {
                showAlert(title: "Error", message: "Song file not available")
            }
        }
    }
    
    func stopPlayback() {
        audioPlayer?.stop()
        stopProgressTracking()
        audioPlayer = nil
        isPlaying = false
        tableView.reloadData()
        hidePrePlayingMusicView()
    }
    
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    // MARK: - Present CastMusicPlayerVC
    private func presentMusicPlayer(with songs: [MPMediaItem], selectedIndex: Int) {
        stopProgressTracking()
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let musicPlayerVC = storyboard.instantiateViewController(withIdentifier: "CastMusicPlayerVC") as? CastMusicPlayerVC {
            musicPlayerVC.modalPresentationStyle = .fullScreen
            
            // Pass all songs from GlobalMusicManager
            musicPlayerVC.allSongs = GlobalMusicManager.shared.allSongs
            
            // Get the selected song
            let selectedSong = songs[selectedIndex]
            
            // Find global index for the selected song
            if let globalIndex = GlobalMusicManager.shared.findSongIndex(persistentID: selectedSong.persistentID) {
                // Update GlobalMusicManager
                GlobalMusicManager.shared.currentPlayingIndex = globalIndex
                
                // Set current song index in CastMusicPlayerVC
                musicPlayerVC.currentSongIndex = globalIndex
                musicPlayerVC.musicListVC = self
                
                // Transfer player if same song is playing
                if isPlaying, let currentIndex = currentlyPlayingIndex, let player = audioPlayer {
                    if currentIndex == selectedIndex {
                        musicPlayerVC.audioPlayer = player
                        musicPlayerVC.isPlaying = isPlaying
                        player.delegate = musicPlayerVC
                        
                        audioPlayer?.pause()
                        isPlaying = false
                        
                        if let cell = tableView.cellForRow(at: IndexPath(row: currentIndex, section: 0)) as? MusicListCell {
                            cell.playButton.setImage(UIImage(named: "play1"), for: .normal)
                        }
                    } else {
                        audioPlayer?.stop()
                        audioPlayer = nil
                        isPlaying = false
                        preMusicProgressView.progress = 0
                        tableView.reloadData()
                    }
                }
                
                hidePrePlayingMusicView()
                present(musicPlayerVC, animated: true)
            }
        }
    }
    
    // MARK: - Handle returning from CastMusicPlayerVC
    func handleReturnFromMusicPlayer(player: AVAudioPlayer?, isPlaying: Bool, currentIndex: Int) {
        if let player = player {
            audioPlayer = player
            audioPlayer?.delegate = self
            self.isPlaying = isPlaying
            
            // Update GlobalMusicManager
            GlobalMusicManager.shared.currentPlayingIndex = currentIndex
            
            if isPlaying {
                startProgressTracking()
                
                if let song = GlobalMusicManager.shared.allSongs[safe: currentIndex] {
                    if !isPrePlayingViewVisible {
                        showPrePlayingMusicView(with: song, at: currentIndex)
                    } else {
                        updatePrePlayingMusicView(with: song, at: currentIndex)
                    }
                    updatePrePlayingButtons()
                }
            }
        }
    }
    
    func openMirroing(){
        let vc: ListDeviceVc = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension CastMusicListVC: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return displayedSongs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MusicListCell", for: indexPath) as? MusicListCell ?? MusicListCell()
        
        let song = displayedSongs[indexPath.row]
        
        cell.musicNameLabel.text = song.title ?? "Unknown Song"
        cell.singerNameLabel.text = song.artist ?? "Unknown Artist"
        
        let duration = song.playbackDuration
        let minutes = Int(duration) / 60
        let seconds = Int(duration) % 60
        cell.musicDurationLabel.text = String(format: "%d:%02d", minutes, seconds)
        
        if let artwork = song.artwork {
            cell.musicPosterImageView.image = artwork.image(at: CGSize(width: 60, height: 60))
        } else {
            cell.musicPosterImageView.image = UIImage(named: "music_placeholder") ?? UIImage(systemName: "music.note")
        }
        
        let isFav = isFavorite(song)
        let favImageName = isFav ? "favorite" : "unfavorite"
        cell.favouriteButton.setImage(UIImage(named: favImageName), for: .normal)
        
        let playImageName = (currentlyPlayingIndex == indexPath.row && isPlaying) ? "pause1" : "play1"
        cell.playButton.setImage(UIImage(named: playImageName), for: .normal)
        
        cell.cellBottomLineSepratorImageView.isHidden = (indexPath.row == displayedSongs.count - 1)
        
        cell.favouriteButton.tag = indexPath.row
        cell.playButton.tag = indexPath.row
        
        cell.favouriteButton.removeTarget(nil, action: nil, for: .allEvents)
        cell.playButton.removeTarget(nil, action: nil, for: .allEvents)
        
        cell.favouriteButton.setOnClickListener { [weak self] in
            guard let self = self else { return }
            let song = self.displayedSongs[indexPath.row]
            self.toggleFavorite(for: song)
        }
        
        cell.playButton.setOnClickListener { [weak self] in
            guard let self = self else { return }
            self.shouldUpdateTableViewCell = true
            if selectedTvType == .noneTV {
                self.openMirroing()
            } else {
                if checkAirPlayStatus().1 {
                    self.playSong(at: indexPath.row, fromTableView: true, showPrePlayingView: false)
                    self.playWithAirPlay(song: song)
                } else {
                    DispatchQueue.main.async {
                        commonViewModel.exportAndUploadMusic(track: song)
                        commonViewModel.startPlaybackUpdates()
                    }
                    self.playSong(at: indexPath.row, fromTableView: true, showPrePlayingView: false)
                }
            }
        }
        
        cell.setOnClickListener {
            if selectedTvType == .noneTV {
                self.openMirroing()
            } else {
                // Simply pass displayedSongs and the selected index
                self.presentMusicPlayer(with: self.displayedSongs, selectedIndex: indexPath.row)
            }
        }
        
        cell.backgroundColor = .clear
        cell.contentView.backgroundColor = .clear
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)

    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension CastMusicListVC: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return getFavoriteSongs().count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FavouriteMusicCell", for: indexPath) as? FavouriteMusicCell ?? FavouriteMusicCell()
        
        let favoriteSongs = getFavoriteSongs()
        guard indexPath.row < favoriteSongs.count else { return cell }
        
        let song = favoriteSongs[indexPath.row]
        
        cell.musicTitleLabel.text = song.title ?? "Unknown"
        
        if let artwork = song.artwork {
            cell.musicPosterImageView.image = artwork.image(at: CGSize(width: 80, height: 80))
        } else {
            cell.musicPosterImageView.image = UIImage(named: "music_placeholder") ?? UIImage(systemName: "music.note")
        }
        
        cell.favouriteButton.setImage(UIImage(named: "favorite"), for: .normal)
        cell.favouriteButton.tag = indexPath.row
        
        cell.favouriteButton.removeTarget(nil, action: nil, for: .allEvents)
        
        cell.favouriteButton.setOnClickListener { [weak self] in
            guard let self = self else { return }
            self.toggleFavorite(for: song)
        }
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width / 2.3
        return CGSize(width: width, height: 100)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let favoriteSongs = getFavoriteSongs()
        guard indexPath.row < favoriteSongs.count else { return }
        
        let song = favoriteSongs[indexPath.row]
        
        // Find the song in displayedSongs
        if let indexInDisplayed = displayedSongs.firstIndex(where: { $0.persistentID == song.persistentID }) {
            presentMusicPlayer(with: displayedSongs, selectedIndex: indexInDisplayed)
        }
    }
}

// MARK: - AVAudioPlayerDelegate
extension CastMusicListVC: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if flag {
            stopProgressTracking()
            guard let currentIndex = currentlyPlayingIndex else { return }
            
            if isRepeat {
                player.currentTime = 0
                player.play()
                startProgressTracking()
            } else if isShuffle {
                var nextIndex = Int.random(in: 0..<displayedSongs.count)
                while nextIndex == currentIndex && displayedSongs.count > 1 {
                    nextIndex = Int.random(in: 0..<displayedSongs.count)
                }
                playSong(at: nextIndex, fromTableView: false, showPrePlayingView: false)
            } else {
                var nextIndex = currentIndex + 1
                if nextIndex >= displayedSongs.count {
                    nextIndex = 0
                }
                playSong(at: nextIndex, fromTableView: false, showPrePlayingView: false)
            }
        }
    }
}

// MARK: - Button Actions
extension CastMusicListVC {
    @IBAction func backButtonTap(_ sender: Any) {
        stopPlayback()
        self.navigationController?.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func viewAllButtonTap(_ sender: Any) {
        if !getFavoriteSongs().isEmpty {
            collectionView.scrollToItem(at: IndexPath(item: 0, section: 0), at: .left, animated: true)
        }
    }
    
    @IBAction func preMusicPlayButton(_ sender: UIButton) {
        shouldUpdateTableViewCell = false
        if let index = currentlyPlayingIndex {
            playSong(at: index, fromTableView: false, showPrePlayingView: true)
        } else {
            playSong(at: 0, fromTableView: false, showPrePlayingView: true)
        }
    }
    
    @IBAction func preMusicNextButton(_ sender: Any) {
        guard let currentIndex = currentlyPlayingIndex else { return }
        
        var nextIndex = currentIndex + 1
        if nextIndex >= displayedSongs.count {
            nextIndex = 0
        }
        
        shouldUpdateTableViewCell = false
        playSong(at: nextIndex, fromTableView: false, showPrePlayingView: true)
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    @IBAction func preMusicPreviousButton(_ sender: Any) {
        guard let currentIndex = currentlyPlayingIndex else { return }
        
        var previousIndex = currentIndex - 1
        if previousIndex < 0 {
            previousIndex = displayedSongs.count - 1
        }
        
        shouldUpdateTableViewCell = false
        playSong(at: previousIndex, fromTableView: false, showPrePlayingView: true)
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    @IBAction func preMusicShuffleButton(_ sender: UIButton) {
        isShuffle = !isShuffle
        updatePrePlayingButtons()
    }
    
    @IBAction func preMusicRepeatButton(_ sender: UIButton) {
        isRepeat = !isRepeat
        updatePrePlayingButtons()
    }
    
    @IBAction func preMusicCloseButton(_ sender: Any) {
        stopPlayback()
    }
    
    func refreshTableViewForCurrentPlaying() {
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
}

// MARK: - PrePlayingMusicView Management
extension CastMusicListVC {
    func setupPrePlayingMusicView() {
        PrePlayingMusicView.isHidden = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(prePlayingViewTapped))
        PrePlayingMusicView.addGestureRecognizer(tapGesture)
        
        let progressTapGesture = UITapGestureRecognizer(target: self, action: #selector(handleProgressViewTap(_:)))
        preMusicProgressView.addGestureRecognizer(progressTapGesture)
        
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        PrePlayingMusicView.addGestureRecognizer(panGesture)
        
        PrePlayingMusicView.layer.cornerRadius = 15
        PrePlayingMusicView.layer.shadowColor = UIColor.black.cgColor
        PrePlayingMusicView.layer.shadowOffset = CGSize(width: 0, height: 2)
        PrePlayingMusicView.layer.shadowOpacity = 0.3
        PrePlayingMusicView.layer.shadowRadius = 4
    }
    
    @objc func handleProgressViewTap(_ gesture: UITapGestureRecognizer) {
        guard let player = audioPlayer, player.duration > 0 else { return }
        
        let location = gesture.location(in: preMusicProgressView)
        let progress = Float(location.x / preMusicProgressView.frame.width)
        
        let newTime = TimeInterval(progress) * player.duration
        player.currentTime = newTime
        preMusicProgressView.progress = progress
    }
    
    @objc func prePlayingViewTapped() {
        if let index = currentlyPlayingIndex {
            let currentSong = displayedSongs[index]
            if let indexInAll = GlobalMusicManager.shared.findSongIndex(persistentID: currentSong.persistentID) {
                presentMusicPlayer(with: GlobalMusicManager.shared.allSongs, selectedIndex: indexInAll)
            }
        }
    }
    
    @objc func handlePanGesture(_ gesture: UIPanGestureRecognizer) {
        guard let viewToDrag = gesture.view else { return }
        
        switch gesture.state {
        case .began:
            initialCenter = viewToDrag.center
            
        case .changed:
            let translation = gesture.translation(in: self.view)
            let newCenter = CGPoint(
                x: initialCenter.x + translation.x,
                y: initialCenter.y + translation.y
            )
            
            let safeBounds = view.bounds.insetBy(
                dx: viewToDrag.bounds.width / 2,
                dy: viewToDrag.bounds.height / 2
            )
            
            var constrainedCenter = newCenter
            constrainedCenter.x = max(safeBounds.minX, min(safeBounds.maxX, constrainedCenter.x))
            constrainedCenter.y = max(safeBounds.minY, min(safeBounds.maxY, constrainedCenter.y))
            
            viewToDrag.center = constrainedCenter
            
        case .ended, .cancelled:
            let safeBounds = view.bounds.insetBy(
                dx: viewToDrag.bounds.width / 2,
                dy: viewToDrag.bounds.height / 2
            )
            
            var finalCenter = viewToDrag.center
            finalCenter.x = max(safeBounds.minX, min(safeBounds.maxX, finalCenter.x))
            finalCenter.y = max(safeBounds.minY, min(safeBounds.maxY, finalCenter.y))
            
            UIView.animate(withDuration: 0.2) {
                viewToDrag.center = finalCenter
            }
            
        default:
            break
        }
    }
    
    func showPrePlayingMusicView(with song: MPMediaItem, at index: Int) {
        preMusicNameLabel.text = song.title ?? "Unknown Song"
        preMusicArtistNameLabel.text = song.artist ?? "Unknown Artist"
        
        if let artwork = song.artwork {
            prePlayingImageView.image = artwork.image(at: CGSize(width: 60, height: 60))
        } else {
            prePlayingImageView.image = UIImage(named: "music_placeholder")
        }
        
        updatePrePlayingButtons()
        
        PrePlayingMusicView.alpha = 0
        PrePlayingMusicView.isHidden = false
        PrePlayingMusicView.transform = CGAffineTransform(translationX: 0, y: 50)
        
        UIView.animate(withDuration: 0.3) {
            self.PrePlayingMusicView.alpha = 1
            self.PrePlayingMusicView.transform = .identity
        }
        
        isPrePlayingViewVisible = true
        
        PrePlayingMusicView.center = CGPoint(
            x: view.bounds.width / 2,
            y: view.bounds.height - PrePlayingMusicView.bounds.height / 2 - 20 - view.safeAreaInsets.bottom
        )
    }
    
    func updatePrePlayingMusicView(with song: MPMediaItem, at index: Int) {
        preMusicNameLabel.text = song.title ?? "Unknown Song"
        preMusicArtistNameLabel.text = song.artist ?? "Unknown Artist"
        
        if let artwork = song.artwork {
            prePlayingImageView.image = artwork.image(at: CGSize(width: 60, height: 60))
        } else {
            prePlayingImageView.image = UIImage(named: "music_placeholder")
        }
        
        updatePrePlayingButtons()
    }
    
    func updatePrePlayingButtons() {
        let playImageName = isPlaying ? "pause1" : "play1"
        preMusicPlayButton.setImage(UIImage(named: playImageName), for: .normal)
        
        let shuffleImageName = isShuffle ? "shuffle_on" : "shuffle_off"
        preMusicShuffleButton.setImage(UIImage(named: shuffleImageName), for: .normal)
        
        let repeatImageName = isRepeat ? "repeat_on" : "repeat_off"
        preMusicRepeatButton.setImage(UIImage(named: repeatImageName), for: .normal)
    }
    
    func hidePrePlayingMusicView() {
        UIView.animate(withDuration: 0.3, animations: {
            self.PrePlayingMusicView.alpha = 0
            self.PrePlayingMusicView.transform = CGAffineTransform(translationX: 0, y: 50)
        }) { _ in
            self.PrePlayingMusicView.isHidden = true
            self.isPrePlayingViewVisible = false
        }
    }
}
extension CastMusicListVC {
    
    func playWithAirPlay(song : MPMediaItem) {
        playVideo(song: song)
    }
    
    private func configurePlayerForAirPlay() {
        guard let player = player else { return }
        
        // Enable AirPlay
        player.allowsExternalPlayback = true
        player.usesExternalPlaybackWhileExternalScreenIsActive = true
        playerViewController?.allowsPictureInPicturePlayback = false
        playerViewController?.updatesNowPlayingInfoCenter = false
        
        // Optional: Observe if it's being routed externally
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleRouteChange),
                                               name: AVAudioSession.routeChangeNotification,
                                               object: nil)
    }
    
    @objc private func handleRouteChange(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let reasonValue = userInfo[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: reasonValue) else { return }
        
        switch reason {
        case .oldDeviceUnavailable:
            print("AirPlay device disconnected.")
        case .newDeviceAvailable:
            print("AirPlay device connected.")
        default:
            break
        }
    }
    
    func export(_ assetURL: URL, completionHandler: @escaping (_ fileURL: URL?, _ error: Error?) -> ()) {
        let asset = AVURLAsset(url: assetURL)
        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            completionHandler(nil, NSError(domain: "ExportError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to create export session"]))
            return
        }
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        let fileURL = url!.appendingPathComponent("rendered_audio.m4a")
        let filePath = NSURL(string: fileURL.absoluteString)
        do {
            try FileManager.default.removeItem(at: filePath! as URL)
        } catch {
            print("Could not clear temp folder: \(error)")
        }
        
        exporter.outputURL = filePath as URL?
        exporter.outputFileType = AVFileType(rawValue: "com.apple.m4a-audio")
        exporter.exportAsynchronously {
            if exporter.status == .completed {
                completionHandler(fileURL, nil)
            } else {
                completionHandler(nil, exporter.error)
            }
        }
    }
    
    func playVideo(song : MPMediaItem) {
        guard let assetURL = song.assetURL else {
            ScreenMirroringApp.showAlert("Error".localized(), message: "No asset URL for song".localized()) { }
            return
        }
        self.showCustomLoading(superVc: self, titleText: "Playing")
        
        setVideoCastCount(count: getVideoCastCount() + 1)
        
        // Step 1: Create static video from image
        createVideoFromMusic(song: song) { imageVideoURL in
            guard let imageVideoURL = imageVideoURL else {
                DispatchQueue.main.async { self.hideCustomLoading() }
                print("Failed to create video from image")
                return
            }            // Step 2: Add audio to the video
            addAudioToVideo(videoURL: imageVideoURL, audioURL: assetURL) { finalVideoURL in
                guard let finalVideoURL = finalVideoURL else {
                    DispatchQueue.main.async { self.hideCustomLoading() }
                    print("Failed to add audio to video")
                    return
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    // Copy final video to server path
                    let serverURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("rendered_video.mp4")
                    try? FileManager.default.removeItem(at: serverURL)
                    try? FileManager.default.copyItem(at: finalVideoURL, to: serverURL)
                    
                    print("VIDEO HTTP URL \(finalVideoURL)")
                    self.uploadFile(finalVideoURL, mediaType: "video/mp4")
                    
                }
            }
        }
    }
    
    func uploadFile(_ url: URL, mediaType: String) {
        guard var serverUrl = CastingServer.shared.serverURL else {
            print("Invalid server URL")
            DispatchQueue.main.async { self.isUploading = false }
            return
        }

        serverUrl.appendPathComponent("upload")

        var request = URLRequest(url: serverUrl)
        request.httpMethod = "POST"
        request.setValue(mediaType, forHTTPHeaderField: "Content-Type")
        DispatchQueue.main.async {
            do {
                let fileData = try Data(contentsOf: url)
                
                // Ensure UI update
                DispatchQueue.main.async { self.isUploading = true }
                
                let task = URLSession.shared.uploadTask(with: request, from: fileData) { data, response, error in
                    DispatchQueue.main.async { self.isUploading = false }
                    
                    if let error = error {
                        print("Upload error: \(error)")
                        return
                    }
                    
                    guard
                        let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200,
                        let data = data,
                        let responseUrl = String(data: data, encoding: .utf8),
                        let mediaUrl = URL(string: responseUrl)
                    else {
                        print("Invalid response")
                        return
                    }
                    
                    print("Media uploaded to: \(mediaUrl)")
                    DispatchQueue.main.async {
                        self.hideCustomLoading()
                        let player = AVPlayer(url: mediaUrl)
                        let playerViewController = AVPlayerViewController()
                        playerViewController.player = player
                        if #available(iOS 16.0, *) {
                            playerViewController.allowsVideoFrameAnalysis = true
                        }
                        playerViewController.allowsPictureInPicturePlayback = true
                        self.present(playerViewController, animated: true) {
                            player.play()
                        }
                    }
                }
                
                task.resume()
            } catch {
                print("Error reading file data: \(error)")
                DispatchQueue.main.async { self.isUploading = false }
            }
        }
    }
}
func createVideoFromMusic(song : MPMediaItem, completion: @escaping (URL?) -> Void) {
    guard let assetURL = song.assetURL else {
        showAlert("Error".localized(), message: "No asset URL for song".localized()) { }
        return
    }
    let size = CGSize(width: 1080, height: 1080)
    let outputURL = FileManager.default.temporaryDirectory.appendingPathComponent("music_video.mp4")
    try? FileManager.default.removeItem(at: outputURL)
    
    guard let writer = try? AVAssetWriter(outputURL: outputURL, fileType: .mp4) else {
        completion(nil)
        return
    }
    
    let settings = [
        AVVideoCodecKey: AVVideoCodecType.h264,
        AVVideoWidthKey: size.width,
        AVVideoHeightKey: size.height
    ] as [String : Any]
    
    let writerInput = AVAssetWriterInput(mediaType: .video, outputSettings: settings)
    let pixelBufferAdaptor = AVAssetWriterInputPixelBufferAdaptor(
        assetWriterInput: writerInput,
        sourcePixelBufferAttributes: [
            kCVPixelBufferPixelFormatTypeKey as String: Int(kCVPixelFormatType_32ARGB),
            kCVPixelBufferWidthKey as String: size.width,
            kCVPixelBufferHeightKey as String: size.height
        ]
    )
    
    guard writer.canAdd(writerInput) else {
        completion(nil)
        return
    }
    writer.add(writerInput)
    
    // Get actual audio duration
    let audioAsset = AVURLAsset(url: assetURL)
    let durationInSeconds = CMTimeGetSeconds(audioAsset.duration)
    
    writer.startWriting()
    writer.startSession(atSourceTime: .zero)
    //let outputURL =  "https://buffer.com/library/content/images/library/wp-content/uploads/2017/09/13-Places-to-Find-Background-Music-for-Video-Cover-Image-2.jpg"
    let artworkImage = song.artwork?.image(at: CGSize(width: 80, height: 80)) ?? UIImage(named: "music")!
    let fps: Int32 = 30
    let frameCount = Int(durationInSeconds * Double(fps))
    let queue = DispatchQueue(label: "videoQueue")
    
    writerInput.requestMediaDataWhenReady(on: queue) {
        var frame = 0
        while frame < frameCount {
            if writerInput.isReadyForMoreMediaData {
                let time = CMTime(value: CMTimeValue(frame), timescale: fps)
                if let buffer = artworkImage.pixelBuffer(size: size) {
                    pixelBufferAdaptor.append(buffer, withPresentationTime: time)
                }
                frame += 1
            }
        }
        
        writerInput.markAsFinished()
        writer.finishWriting {
            completion(outputURL)
        }
    }
}
func addAudioToVideo(videoURL: URL, audioURL: URL, completion: @escaping (URL?) -> Void) {
    let mixComposition = AVMutableComposition()
    
    // Video Track
    let videoAsset = AVURLAsset(url: videoURL)
    guard let videoTrack = videoAsset.tracks(withMediaType: .video).first else {
        completion(nil)
        return
    }
    let videoCompositionTrack = mixComposition.addMutableTrack(withMediaType: .video,
                                                               preferredTrackID: kCMPersistentTrackID_Invalid)
    try? videoCompositionTrack?.insertTimeRange(CMTimeRangeMake(start: .zero, duration: videoAsset.duration),
                                                of: videoTrack,
                                                at: .zero)
    
    // Audio Track
    let audioAsset = AVURLAsset(url: audioURL)
    guard let audioTrack = audioAsset.tracks(withMediaType: .audio).first else {
        completion(nil)
        return
    }
    let audioCompositionTrack = mixComposition.addMutableTrack(withMediaType: .audio,
                                                               preferredTrackID: kCMPersistentTrackID_Invalid)
    try? audioCompositionTrack?.insertTimeRange(CMTimeRangeMake(start: .zero, duration: videoAsset.duration),
                                                of: audioTrack,
                                                at: .zero)
    
    // Export
    let outputURL = FileManager.default.temporaryDirectory.appendingPathComponent("final_video_with_audio.mp4")
    try? FileManager.default.removeItem(at: outputURL)
    
    let exporter = AVAssetExportSession(asset: mixComposition, presetName: AVAssetExportPresetHighestQuality)
    exporter?.outputURL = outputURL
    exporter?.outputFileType = .mp4
    exporter?.exportAsynchronously {
        if exporter?.status == .completed {
            completion(outputURL)
        } else {
            print("Audio merge failed: \(exporter?.error?.localizedDescription ?? "Unknown")")
            completion(nil)
        }
    }
}
