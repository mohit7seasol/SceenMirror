//
//  CastMusicPlayerVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 06/01/26.
//

import UIKit
import MediaPlayer
import ScalingCarousel
import Lottie

class CastMusicPlayerVC: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dismissButton: UIButton!
    @IBOutlet weak var favouriteButton: UIButton!
    @IBOutlet weak var songNameLabel: UILabel!
    @IBOutlet weak var singerNameLabel: UILabel!
    @IBOutlet weak var startDurationLabel: UILabel!
    @IBOutlet weak var endDurationLabel: UILabel!
    @IBOutlet weak var shuffleButton: UIButton!
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var repeatButton: UIButton!
    @IBOutlet weak var collectionView: UICollectionView! {
        didSet{
            collectionView.delegate = self
            collectionView.dataSource = self
            
            let nib = UINib(nibName: "FavouriteMusicCell", bundle: nil)
            collectionView.register(nib, forCellWithReuseIdentifier: "FavouriteMusicCell")
        }
    }
    @IBOutlet weak var musicWaveView: UIView!
    
    // MARK: - Properties
    var allSongs: [MPMediaItem] = []
    var currentSongIndex: Int = 0
    var audioPlayer: AVAudioPlayer?
    var musicBeatAnimation: LottieAnimationView?
    
    var isPlaying = false
    var isShuffle = false
    var isRepeat = false
    var displayLink: CADisplayLink?
    weak var musicListVC: CastMusicListVC?
    
    private var currentSong: MPMediaItem? {
        guard currentSongIndex < allSongs.count else { return nil }
        return allSongs[currentSongIndex]
    }
    
    private var favoriteSongIDs: Set<UInt64> {
        get {
            return GlobalMusicManager.shared.favoriteSongIDs
        }
        set {
            GlobalMusicManager.shared.favoriteSongIDs = newValue
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        setupMusicBeatAnimation()
        
        // Sync with GlobalMusicManager
        self.allSongs = GlobalMusicManager.shared.allSongs
        
        // CRITICAL FIX: Get current playing index from GlobalMusicManager
        self.currentSongIndex = GlobalMusicManager.shared.currentPlayingIndex
        
        playCurrentSong()
        updateUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateCollectionViewLayout()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if isPlaying && isBeingDismissed {
            if let listVC = musicListVC, let player = audioPlayer {
                player.delegate = listVC
                
                listVC.audioPlayer = player
                listVC.isPlaying = true
                
                // Update GlobalMusicManager
                GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
            }
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        super.viewWillTransition(to: size, with: coordinator)
        coordinator.animate(alongsideTransition: { _ in
            self.updateCollectionViewLayout()
            self.collectionView.collectionViewLayout.invalidateLayout()
        }, completion: nil)
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateCollectionViewLayout()
        updateAnimationFrame()
    }
    
    func setUI() {
        setCollection()
        
        shuffleButton.setImage(UIImage(named: isShuffle ? "shuffle_on" : "shuffle_off"), for: .normal)
        repeatButton.setImage(UIImage(named: isRepeat ? "repeat_on" : "repeat_off"), for: .normal)
        playButton.setImage(UIImage(named: "pause2"), for: .normal)
    }
    
    func setCollection() {
//        collectionView.delegate = self
//        collectionView.dataSource = self
//        
//        let nib = UINib(nibName: "FavouriteMusicCell", bundle: nil)
//        collectionView.register(nib, forCellWithReuseIdentifier: "FavouriteMusicCell")
        
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.decelerationRate = .fast
        
        updateCollectionViewLayout()
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            let indexPath = IndexPath(item: self.currentSongIndex, section: 0)
            self.collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
            self.collectionView.reloadData()
        }
    }
    
    private func updateCollectionViewLayout() {
        if let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
            
            let cellHeight: CGFloat = 260
            let cellWidth = cellHeight * 0.9
            
            layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
            layout.minimumLineSpacing = 10
            
            let sideInset = (collectionView.frame.width - cellWidth) / 2
            layout.sectionInset = UIEdgeInsets(top: 0, left: sideInset, bottom: 0, right: sideInset)
            
            layout.minimumInteritemSpacing = 0
        }
    }
    
    private func setupMusicBeatAnimation() {
        musicWaveView.subviews.forEach { $0.removeFromSuperview() }
        
        let animationView = LottieAnimationView(name: "Music Beat")
        animationView.contentMode = .scaleAspectFill
        animationView.loopMode = .loop
        animationView.animationSpeed = 1.0
        animationView.backgroundBehavior = .pauseAndRestore
        musicWaveView.addSubview(animationView)
        
        animationView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            animationView.leadingAnchor.constraint(equalTo: musicWaveView.leadingAnchor),
            animationView.trailingAnchor.constraint(equalTo: musicWaveView.trailingAnchor),
            animationView.topAnchor.constraint(equalTo: musicWaveView.topAnchor),
            animationView.bottomAnchor.constraint(equalTo: musicWaveView.bottomAnchor)
        ])
        
        musicBeatAnimation = animationView
    }
    
    private func updateAnimationFrame() {
        musicBeatAnimation?.frame = musicWaveView.bounds
    }
    
    private func startMusicBeatAnimation() {
        if let animationView = musicBeatAnimation {
            if animationView.isAnimationPlaying {
                return
            }
            animationView.play()
            animationView.isHidden = false
        }
    }
    
    private func stopMusicBeatAnimation() {
        if let animationView = musicBeatAnimation {
            animationView.stop()
            animationView.isHidden = false
        }
    }
    
    private func playCurrentSong() {
        // Update GlobalMusicManager
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        guard let song = currentSong, let url = song.assetURL else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.delegate = self
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            isPlaying = true
            
            startMusicBeatAnimation()
            updateUI()
            startDisplayLink()
            
            playButton.setImage(UIImage(named: "pause2"), for: .normal)
            DispatchQueue.main.async {
                commonViewModel.exportAndUploadMusic(track: song)
                commonViewModel.startPlaybackUpdates()
            }
        } catch {
            print("Error playing song: \(error)")
        }
    }
    
    private func updateUI() {
        guard let song = currentSong else { return }
        
        songNameLabel.text = song.title ?? "Unknown Song"
        singerNameLabel.text = song.artist ?? "Unknown Artist"
        
        let isFav = favoriteSongIDs.contains(song.persistentID)
        let favImage = isFav ? UIImage(named: "favorite") : UIImage(named: "unfavorite")
        favouriteButton.setImage(favImage, for: .normal)
        
        let duration = song.playbackDuration
        let totalMinutes = Int(duration) / 60
        let totalSeconds = Int(duration) % 60
        endDurationLabel.text = String(format: "%d:%02d", totalMinutes, totalSeconds)
        
        startDurationLabel.text = "0:00"
        
        collectionView.reloadData()
        
        DispatchQueue.main.async {
            let indexPath = IndexPath(item: self.currentSongIndex, section: 0)
            self.collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        }
    }
    
    private func startDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(updateProgress))
        displayLink?.add(to: .main, forMode: .common)
    }
    
    private func stopDisplayLink() {
        displayLink?.invalidate()
        displayLink = nil
    }
    
    @objc private func updateProgress() {
        guard let player = audioPlayer else { return }
        
        let currentTime = player.currentTime
        let minutes = Int(currentTime) / 60
        let seconds = Int(currentTime) % 60
        startDurationLabel.text = String(format: "%d:%02d", minutes, seconds)
    }
    
    private func playNextSong() {
        if isShuffle {
            currentSongIndex = Int.random(in: 0..<allSongs.count)
        } else {
            currentSongIndex = (currentSongIndex + 1) % allSongs.count
        }
        
        // Update GlobalMusicManager
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        playCurrentSong()
        
        if let listVC = musicListVC {
            listVC.refreshTableViewForCurrentPlaying()
        }
    }
    
    private func playPreviousSong() {
        if isShuffle {
            currentSongIndex = Int.random(in: 0..<allSongs.count)
        } else {
            currentSongIndex = currentSongIndex > 0 ? currentSongIndex - 1 : allSongs.count - 1
        }
        
        // Update GlobalMusicManager
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        playCurrentSong()
        
        if let listVC = musicListVC {
            listVC.refreshTableViewForCurrentPlaying()
        }
    }
    
    private func togglePlayPause() {
        if isPlaying {
            audioPlayer?.pause()
            playButton.setImage(UIImage(named: "play2"), for: .normal)
            stopDisplayLink()
            stopMusicBeatAnimation()
        } else {
            audioPlayer?.play()
            playButton.setImage(UIImage(named: "pause2"), for: .normal)
            startDisplayLink()
            startMusicBeatAnimation()
        }
        isPlaying = !isPlaying
    }
    
    private func toggleFavorite() {
        guard let song = currentSong else { return }
        
        let pid = song.persistentID
        if favoriteSongIDs.contains(pid) {
            favoriteSongIDs.remove(pid)
            favouriteButton.setImage(UIImage(named: "unfavorite"), for: .normal)
        } else {
            favoriteSongIDs.insert(pid)
            favouriteButton.setImage(UIImage(named: "favorite"), for: .normal)
        }
    }
}

// MARK: - UICollectionView DataSource & Delegate
extension CastMusicPlayerVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return allSongs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FavouriteMusicCell", for: indexPath) as? FavouriteMusicCell else {
            return UICollectionViewCell()
        }
        
        let song = allSongs[indexPath.row]
        
        cell.musicTitleLabel?.isHidden = true
        cell.favouriteButton?.isHidden = true
        
        if let artwork = song.artwork {
            cell.musicPosterImageView?.image = artwork.image(at: CGSize(width: 300, height: 300))
        } else {
            cell.musicPosterImageView?.image = UIImage(named: "music_placeholder") ?? UIImage(systemName: "music.note")
        }
        
        // Update border based on current song
        if indexPath.row == currentSongIndex {
            cell.contentView.layer.borderWidth = 3
            cell.contentView.layer.borderColor = #colorLiteral(red: 0.4635065794, green: 0.7372660041, blue: 1, alpha: 1).cgColor
        } else {
            cell.contentView.layer.borderWidth = 0
        }
        
        cell.contentView.layer.cornerRadius = 12
        cell.contentView.layer.masksToBounds = true
        
        // Apply scaling transform
        let centerX = collectionView.contentOffset.x + (collectionView.bounds.width / 2)
        let basePosition = cell.center.x
        let distance = abs(centerX - basePosition)
        let normalized = distance / (collectionView.bounds.width / 2)
        let scale = max(0.85, 1 - normalized * 0.15)
        
        cell.transform = CGAffineTransform(scaleX: scale, y: scale)
        cell.alpha = scale
        
        return cell
    }
}

extension CastMusicPlayerVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        currentSongIndex = indexPath.row
        playCurrentSong()
        
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        // Optional: Add pre-drag logic
    }
    
    func scrollViewWillEndDragging(_ scrollView: UIScrollView,
                                   withVelocity velocity: CGPoint,
                                   targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        guard let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout else { return }
        
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        let inset = layout.sectionInset.left
        
        var offset = targetContentOffset.pointee.x + scrollView.contentInset.left
        let page = round(offset / cellWidthIncludingSpacing)
        offset = page * cellWidthIncludingSpacing - inset
        
        targetContentOffset.pointee = CGPoint(x: offset, y: 0)
        
        let newIndex = max(0, min(Int(page), allSongs.count - 1))
        if newIndex != currentSongIndex {
            currentSongIndex = newIndex
            playCurrentSong()
        }
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        updateCurrentPage(scrollView)
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        updateCurrentPage(scrollView)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let centerX = scrollView.contentOffset.x + (collectionView.bounds.width / 2)
        
        for cell in collectionView.visibleCells {
            let basePosition = cell.center.x
            let distance = abs(centerX - basePosition)
            let normalized = distance / (collectionView.bounds.width / 2)
            let scale = max(0.85, 1 - normalized * 0.15)
            
            cell.transform = CGAffineTransform(scaleX: scale, y: scale)
            cell.alpha = scale
        }
    }
    
    private func updateCurrentPage(_ scrollView: UIScrollView) {
        guard let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout else { return }
        let cellWidthIncludingSpacing = layout.itemSize.width + layout.minimumLineSpacing
        let page = Int((scrollView.contentOffset.x + (cellWidthIncludingSpacing / 2)) / cellWidthIncludingSpacing)
        
        let newIndex = max(0, min(page, allSongs.count - 1))
        if newIndex != currentSongIndex {
            currentSongIndex = newIndex
            playCurrentSong()
        }
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension CastMusicPlayerVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let cellHeight: CGFloat = 260
        let cellWidth = cellHeight * 0.9
        return CGSize(width: cellWidth, height: cellHeight)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        guard let layout = collectionView.collectionViewLayout as? UICollectionViewFlowLayout else {
            return UIEdgeInsets.zero
        }
        
        let cellWidth = layout.itemSize.width
        let sideInset = (collectionView.frame.width - cellWidth) / 2
        return UIEdgeInsets(top: 0, left: sideInset, bottom: 0, right: sideInset)
    }
}

// MARK: - AVAudioPlayerDelegate
extension CastMusicPlayerVC: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if flag {
            stopMusicBeatAnimation()
            
            if isRepeat {
                player.currentTime = 0
                player.play()
                startMusicBeatAnimation()
            } else {
                playNextSong()
            }
            
            if let listVC = musicListVC {
                listVC.refreshTableViewForCurrentPlaying()
            }
        }
    }
}

// MARK: - Button Actions
extension CastMusicPlayerVC {
    @IBAction func screenDismissTap(_ sender: Any) {
        if let listVC = musicListVC, let player = audioPlayer {
            listVC.handleReturnFromMusicPlayer(
                player: player,
                isPlaying: isPlaying,
                currentIndex: currentSongIndex
            )
            
            audioPlayer?.delegate = listVC
            audioPlayer = nil
        }
        
        // Update GlobalMusicManager before dismissing
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        stopDisplayLink()
        stopMusicBeatAnimation()
        
        if let listVC = musicListVC {
            DispatchQueue.main.async {
                listVC.tableView.reloadData()
                listVC.collectionView.reloadData()
                listVC.updateFavoritesCollectionVisibility()
                listVC.refreshTableViewForCurrentPlaying()
            }
        }
        
        dismiss(animated: true)
    }
    
    @IBAction func favouriteTap(_ sender: Any) {
        toggleFavorite()
        
        if let listVC = musicListVC, let song = currentSong {
            listVC.toggleFavorite(for: song)
            DispatchQueue.main.async {
                listVC.tableView.reloadData()
                listVC.collectionView.reloadData()
                listVC.updateFavoritesCollectionVisibility()
            }
        }
    }
    
    @IBAction func playTap(_ sender: Any) {
        togglePlayPause()
    }
    
    @IBAction func shuffleTap(_ sender: Any) {
        isShuffle = !isShuffle
        shuffleButton.setImage(UIImage(named: isShuffle ? "shuffle_on" : "shuffle_off"), for: .normal)
    }
    
    @IBAction func previousTap(_ sender: Any) {
        playPreviousSong()
    }
    
    @IBAction func nextTap(_ sender: Any) {
        playNextSong()
    }
    
    @IBAction func repeatTap(_ sender: Any) {
        isRepeat = !isRepeat
        repeatButton.setImage(UIImage(named: isRepeat ? "repeat_on" : "repeat_off"), for: .normal)
    }
}
