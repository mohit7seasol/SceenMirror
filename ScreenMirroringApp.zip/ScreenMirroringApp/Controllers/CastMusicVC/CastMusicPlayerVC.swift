//
//  CastMusicPlayerVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 06/01/26.
//

import UIKit
import MediaPlayer
import Lottie

class CastMusicPlayerVC: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dismissButton: UIButton!
    @IBOutlet weak var favouriteButton: UIButton!
    @IBOutlet weak var songNameLabel: UILabel!
    @IBOutlet weak var singerNameLabel: UILabel!
    @IBOutlet weak var startDurationLabel: UILabel!
    @IBOutlet weak var endDurationLabel: UILabel!
    @IBOutlet weak var shuffleButton: UIButton!
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    @IBOutlet weak var repeatButton: UIButton!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var musicWaveView: UIView!
    
    // MARK: - Properties
    var allSongs: [MPMediaItem] = []
    var currentSongIndex: Int = 0
    var audioPlayer: AVAudioPlayer?
    var musicBeatAnimation: LottieAnimationView?
    
    var isPlaying = false
    var isShuffle = false
    var isRepeat = false
    var displayLink: CADisplayLink?
    weak var musicListVC: CastMusicListVC?
    
    // Carousel properties
    private var currentPage: Int = 0 {
        didSet {
            // Update when page changes
            if currentPage != currentSongIndex {
                currentSongIndex = currentPage
                playCurrentSong()
            }
        }
    }
    
    private var currentSong: MPMediaItem? {
        guard currentSongIndex < allSongs.count else { return nil }
        return allSongs[currentSongIndex]
    }
    
    private var favoriteSongIDs: Set<UInt64> {
        get {
            return GlobalMusicManager.shared.favoriteSongIDs
        }
        set {
            GlobalMusicManager.shared.favoriteSongIDs = newValue
        }
    }
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        setupMusicBeatAnimation()
        setupCarouselLayout()  // Setup UPCarouselFlowLayout
        
        // Sync with GlobalMusicManager
        self.allSongs = GlobalMusicManager.shared.allSongs
        
        // CRITICAL FIX 1: Get the correct selected index
        if let selectedSong = GlobalMusicManager.shared.currentSong {
            // Find the index in allSongs
            if let index = GlobalMusicManager.shared.findSongIndex(persistentID: selectedSong.persistentID) {
                self.currentSongIndex = index
            } else {
                // Fallback to GlobalMusicManager's currentPlayingIndex
                self.currentSongIndex = GlobalMusicManager.shared.currentPlayingIndex
            }
        } else {
            // Fallback to GlobalMusicManager's currentPlayingIndex
            self.currentSongIndex = GlobalMusicManager.shared.currentPlayingIndex
        }
        
        playCurrentSong()
        updateUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        scrollToCurrentSong()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        if isPlaying && isBeingDismissed {
            if let listVC = musicListVC, let player = audioPlayer {
                player.delegate = listVC
                
                listVC.audioPlayer = player
                listVC.isPlaying = true
                
                // Update GlobalMusicManager
                GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
            }
        }
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        updateAnimationFrame()
    }
    
    // MARK: - Setup Methods
    func setUI() {
        setupCollectionView()
        
        shuffleButton.setImage(UIImage(named: isShuffle ? "shuffle_on" : "shuffle_off"), for: .normal)
        repeatButton.setImage(UIImage(named: isRepeat ? "repeat_on" : "repeat_off"), for: .normal)
        playButton.setImage(UIImage(named: "pause2"), for: .normal)
    }
    
    private func setupCollectionView() {
        collectionView.delegate = self
        collectionView.dataSource = self
        
        let nib = UINib(nibName: "FavouriteMusicCell", bundle: nil)
        collectionView.register(nib, forCellWithReuseIdentifier: "FavouriteMusicCell")
        
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.decelerationRate = .fast
    }
    
    private func setupCarouselLayout() {
        let layout = UPCarouselFlowLayout()
        layout.scrollDirection = .horizontal
        layout.sideItemScale = 0.75      // Side images smaller
        layout.sideItemAlpha = 0.5       // Faded look for side items
        layout.spacingMode = .fixed(spacing: 12)
        
        let cellHeight: CGFloat = 260
        let cellWidth = cellHeight * 0.9
        
        layout.itemSize = CGSize(width: cellWidth, height: cellHeight)
        collectionView.collectionViewLayout = layout
        
        // Calculate and set section inset
        let sideInset = (collectionView.frame.width - cellWidth) / 2
        layout.sectionInset = UIEdgeInsets(top: 0, left: sideInset, bottom: 0, right: sideInset)
    }
    
    private func setupMusicBeatAnimation() {
        musicWaveView.subviews.forEach { $0.removeFromSuperview() }
        
        let animationView = LottieAnimationView(name: "Music Beat")
        animationView.contentMode = .scaleAspectFill
        animationView.loopMode = .loop
        animationView.animationSpeed = 1.0
        animationView.backgroundBehavior = .pauseAndRestore
        musicWaveView.addSubview(animationView)
        
        animationView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            animationView.leadingAnchor.constraint(equalTo: musicWaveView.leadingAnchor),
            animationView.trailingAnchor.constraint(equalTo: musicWaveView.trailingAnchor),
            animationView.topAnchor.constraint(equalTo: musicWaveView.topAnchor),
            animationView.bottomAnchor.constraint(equalTo: musicWaveView.bottomAnchor)
        ])
        
        musicBeatAnimation = animationView
    }
    
    private func updateAnimationFrame() {
        musicBeatAnimation?.frame = musicWaveView.bounds
    }
    
    // MARK: - Playback Methods
    private func playCurrentSong() {
        // Update GlobalMusicManager with current index
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        guard let song = currentSong, let url = song.assetURL else { return }
        
        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)
            
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.delegate = self
            audioPlayer?.prepareToPlay()
            audioPlayer?.play()
            isPlaying = true
            
            startMusicBeatAnimation()
            updateUI()
            startDisplayLink()
            
            playButton.setImage(UIImage(named: "pause2"), for: .normal)
            
            // FIX 3: Call exportAndUploadMusic when song is selected
            DispatchQueue.main.async {
                commonViewModel.exportAndUploadMusic(track: song)
                commonViewModel.startPlaybackUpdates()
            }
        } catch {
            print("Error playing song: \(error)")
        }
    }
    
    private func updateUI() {
        guard let song = currentSong else { return }
        
        songNameLabel.text = song.title ?? "Unknown Song"
        singerNameLabel.text = song.artist ?? "Unknown Artist"
        
        let isFav = favoriteSongIDs.contains(song.persistentID)
        let favImage = isFav ? UIImage(named: "favorite") : UIImage(named: "unfavorite")
        favouriteButton.setImage(favImage, for: .normal)
        
        let duration = song.playbackDuration
        let totalMinutes = Int(duration) / 60
        let totalSeconds = Int(duration) % 60
        endDurationLabel.text = String(format: "%d:%02d", totalMinutes, totalSeconds)
        
        startDurationLabel.text = "0:00"
        
        collectionView.reloadData()
        scrollToCurrentSong()
    }
    
    private func scrollToCurrentSong() {
        DispatchQueue.main.async {
            let indexPath = IndexPath(item: self.currentSongIndex, section: 0)
            self.collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false)
        }
    }
    
    private func startMusicBeatAnimation() {
        if let animationView = musicBeatAnimation {
            if animationView.isAnimationPlaying {
                return
            }
            animationView.play()
            animationView.isHidden = false
        }
    }
    
    private func stopMusicBeatAnimation() {
        if let animationView = musicBeatAnimation {
            animationView.stop()
            animationView.isHidden = false
        }
    }
    
    private func startDisplayLink() {
        displayLink = CADisplayLink(target: self, selector: #selector(updateProgress))
        displayLink?.add(to: .main, forMode: .common)
    }
    
    private func stopDisplayLink() {
        displayLink?.invalidate()
        displayLink = nil
    }
    
    @objc private func updateProgress() {
        guard let player = audioPlayer else { return }
        
        let currentTime = player.currentTime
        let minutes = Int(currentTime) / 60
        let seconds = Int(currentTime) % 60
        startDurationLabel.text = String(format: "%d:%02d", minutes, seconds)
    }
    
    private func playNextSong() {
        if isShuffle {
            var newIndex = Int.random(in: 0..<allSongs.count)
            while newIndex == currentSongIndex && allSongs.count > 1 {
                newIndex = Int.random(in: 0..<allSongs.count)
            }
            currentSongIndex = newIndex
        } else {
            currentSongIndex = (currentSongIndex + 1) % allSongs.count
        }
        
        // Update GlobalMusicManager
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        playCurrentSong()
        
        if let listVC = musicListVC {
            listVC.refreshTableViewForCurrentPlaying()
        }
    }
    
    private func playPreviousSong() {
        if isShuffle {
            var newIndex = Int.random(in: 0..<allSongs.count)
            while newIndex == currentSongIndex && allSongs.count > 1 {
                newIndex = Int.random(in: 0..<allSongs.count)
            }
            currentSongIndex = newIndex
        } else {
            currentSongIndex = currentSongIndex > 0 ? currentSongIndex - 1 : allSongs.count - 1
        }
        
        // Update GlobalMusicManager
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        playCurrentSong()
        
        if let listVC = musicListVC {
            listVC.refreshTableViewForCurrentPlaying()
        }
    }
    
    private func togglePlayPause() {
        if isPlaying {
            audioPlayer?.pause()
            playButton.setImage(UIImage(named: "play2"), for: .normal)
            stopDisplayLink()
            stopMusicBeatAnimation()
        } else {
            audioPlayer?.play()
            playButton.setImage(UIImage(named: "pause2"), for: .normal)
            startDisplayLink()
            startMusicBeatAnimation()
        }
        isPlaying = !isPlaying
    }
    
    // MARK: - Favorite Management
    private func toggleFavorite() {
        guard let song = currentSong else { return }
        
        let pid = song.persistentID
        if favoriteSongIDs.contains(pid) {
            favoriteSongIDs.remove(pid)
            favouriteButton.setImage(UIImage(named: "unfavorite"), for: .normal)
        } else {
            favoriteSongIDs.insert(pid)
            favouriteButton.setImage(UIImage(named: "favorite"), for: .normal)
        }
        
        // FIX 4: Force refresh in CastMusicListVC when coming back
        if let listVC = musicListVC {
            DispatchQueue.main.async {
                listVC.tableView.reloadData()
                listVC.collectionView.reloadData()
                listVC.updateFavoritesCollectionVisibility()
            }
        }
    }
}

// MARK: - UICollectionView DataSource & Delegate
extension CastMusicPlayerVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return allSongs.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "FavouriteMusicCell", for: indexPath) as? FavouriteMusicCell else {
            return UICollectionViewCell()
        }
        
        let song = allSongs[indexPath.row]
        
        cell.musicTitleLabel?.isHidden = true
        cell.favouriteButton?.isHidden = true
        
        if let artwork = song.artwork {
            cell.musicPosterImageView?.image = artwork.image(at: CGSize(width: 300, height: 300))
        } else {
            cell.musicPosterImageView?.image = UIImage(named: "music_placeholder") ?? UIImage(systemName: "music.note")
        }
        
        // Update border based on current song
        if indexPath.row == currentSongIndex {
            cell.contentView.layer.borderWidth = 3
            cell.contentView.layer.borderColor = #colorLiteral(red: 0.4635065794, green: 0.7372660041, blue: 1, alpha: 1).cgColor
        } else {
            cell.contentView.layer.borderWidth = 0
        }
        
        cell.contentView.layer.cornerRadius = 12
        cell.contentView.layer.masksToBounds = true
        
        return cell
    }
}

extension CastMusicPlayerVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        currentSongIndex = indexPath.row
        currentPage = indexPath.row
        playCurrentSong()
        
        collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        guard scrollView == collectionView else { return }
        
        let layout = collectionView.collectionViewLayout as! UPCarouselFlowLayout
        let pageSize = self.pageSize(for: layout)
        let offset = layout.scrollDirection == .horizontal
            ? scrollView.contentOffset.x
            : scrollView.contentOffset.y
        
        currentPage = Int(floor((offset - pageSize / 2) / pageSize) + 1)
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        guard scrollView == collectionView else { return }
        updateCurrentPage()
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        guard scrollView == collectionView else { return }
        
        // Let UPCarouselFlowLayout handle the scaling and alpha
        // It automatically applies sideItemScale and sideItemAlpha
    }
    
    private func updateCurrentPage() {
        guard let layout = collectionView.collectionViewLayout as? UPCarouselFlowLayout else { return }
        
        let pageSize = self.pageSize(for: layout)
        let page = Int((collectionView.contentOffset.x + (pageSize / 2)) / pageSize)
        
        let newIndex = max(0, min(page, allSongs.count - 1))
        if newIndex != currentSongIndex {
            currentSongIndex = newIndex
            currentPage = newIndex
            playCurrentSong()
        }
    }
    
    private func pageSize(for layout: UPCarouselFlowLayout) -> CGFloat {
        var pageSize = layout.itemSize.width
        if layout.scrollDirection == .horizontal {
            pageSize += layout.minimumLineSpacing
        } else {
            pageSize = layout.itemSize.height + layout.minimumLineSpacing
        }
        return pageSize
    }
}

// MARK: - AVAudioPlayerDelegate
extension CastMusicPlayerVC: AVAudioPlayerDelegate {
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool) {
        if flag {
            stopMusicBeatAnimation()
            
            if isRepeat {
                player.currentTime = 0
                player.play()
                startMusicBeatAnimation()
            } else {
                playNextSong()
            }
            
            if let listVC = musicListVC {
                listVC.refreshTableViewForCurrentPlaying()
            }
        }
    }
}

// MARK: - Button Actions
extension CastMusicPlayerVC {
    @IBAction func screenDismissTap(_ sender: Any) {
        if let listVC = musicListVC, let player = audioPlayer {
            listVC.handleReturnFromMusicPlayer(
                player: player,
                isPlaying: isPlaying,
                currentIndex: currentSongIndex
            )
            
            audioPlayer?.delegate = listVC
            audioPlayer = nil
        }
        
        // Update GlobalMusicManager before dismissing
        GlobalMusicManager.shared.currentPlayingIndex = currentSongIndex
        
        stopDisplayLink()
        stopMusicBeatAnimation()
        
        // FIX 4: Force refresh when going back
        if let listVC = musicListVC {
            DispatchQueue.main.async {
                listVC.tableView.reloadData()
                listVC.collectionView.reloadData()
                listVC.updateFavoritesCollectionVisibility()
                listVC.refreshTableViewForCurrentPlaying()
            }
        }
        
        dismiss(animated: true)
    }
    
    @IBAction func favouriteTap(_ sender: Any) {
        toggleFavorite()
    }
    
    @IBAction func playTap(_ sender: Any) {
        togglePlayPause()
    }
    
    @IBAction func shuffleTap(_ sender: Any) {
        isShuffle = !isShuffle
        shuffleButton.setImage(UIImage(named: isShuffle ? "shuffle_on" : "shuffle_off"), for: .normal)
    }
    
    @IBAction func previousTap(_ sender: Any) {
        playPreviousSong()
    }
    
    @IBAction func nextTap(_ sender: Any) {
        playNextSong()
    }
    
    @IBAction func repeatTap(_ sender: Any) {
        isRepeat = !isRepeat
        repeatButton.setImage(UIImage(named: isRepeat ? "repeat_on" : "repeat_off"), for: .normal)
    }
}
