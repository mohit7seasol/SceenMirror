//
//  OnVC1.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 15/12/25.
//

import UIKit
import AVKit

class OnVC1: UIViewController {

    @IBOutlet weak var fastDeviceLabel: UILabel!
    @IBOutlet weak var wirelessLabel: UILabel!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var skipButton: UIButton!
    
    var videoName = "intro 1"
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        setupVideoPlayer()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        player?.play()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player?.pause()
    }
    
    func setup() {
        setUpLoca()
    }
    
    func setUpLoca() {
        self.fastDeviceLabel.text = "Fast Device Connection".localized(LocalizationService.shared.language)
        self.wirelessLabel.text = "Wirelessly link to any TV and view your phone on the big screen.".localized(LocalizationService.shared.language)
        self.continueButton.setTitle("Continue".localized(LocalizationService.shared.language), for: .normal)
        self.skipButton.setTitle("Skip".localized(LocalizationService.shared.language), for: .normal)
    }
    
    private func setupVideoPlayer() {
        guard let videoPath = Bundle.main.path(forResource: videoName, ofType: "mp4") else {
            print("Video file not found: \(videoName)")
            return
        }
        
        let videoURL = URL(fileURLWithPath: videoPath)
        player = AVPlayer(url: videoURL)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoView.bounds
        playerLayer?.videoGravity = .resizeAspectFill
        
        if let playerLayer = playerLayer {
            videoView.layer.addSublayer(playerLayer)
        }
        
        // Loop the video
        NotificationCenter.default.addObserver(self,
            selector: #selector(playerItemDidReachEnd),
            name: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem
        )
    }
    
    @objc private func playerItemDidReachEnd(notification: Notification) {
        player?.seek(to: .zero)
        player?.play()
    }
    
    @IBAction func continueButtonAction(_ sender: UIButton) {
        // Navigate to OnVC2
        let storyboard = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
        let onVC2 = storyboard.instantiateViewController(withIdentifier: Controllers.o2VC) as! OnVC2
        navigationController?.pushViewController(onVC2, animated: true)
    }
    
    @IBAction func skipButtonAction(_ sender: UIButton) {
        // Go directly to HomeVC
        navigateToHome()
    }
    
    private func navigateToHome() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let window = sceneDelegate.window else { return }
        
        let tabBarVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
            .instantiateViewController(withIdentifier: Controllers.homeVC)
        
        window.rootViewController = tabBarVC
        window.makeKeyAndVisible()
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
