//
//  LanguageVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 15/12/25.
//

import UIKit

enum SelectLanguage: String, CaseIterable {
    case english = "English"
    case spanish = "Spanish"
    case hindi = "Hindi"
    case danish = "Danish"
    case german = "German"
    case italian = "Italian"
    case portuguese = "Portuguese"
    case turkish = "Turkish"
    case japanese = "Japanese"
    case dutch = "Dutch"
    case korean = "Korean"
    case french = "French"
    case russian = "Russian"
    case chinese = "Chinese"
    
    // Map ChooseLanguage → Language (for localization)
    var languageCode: Language {
        switch self {
        case .english: return .English
        case .spanish: return .Spanish
        case .hindi: return .Hindi
        case .danish: return .Danish
        case .german: return .German
        case .italian: return .Italian
        case .portuguese: return .Portuguese
        case .turkish: return .Turkish
        case .japanese: return .Japanese
        case .dutch: return .Dutch
        case .korean: return .Korean
        case .french: return .French
        case .russian: return .Russian
        case .chinese: return .Chinese
        }
    }
}

// MARK: - Language Enum Localized Names
extension Language {
    var localizedName: String {
        switch self {
        case .English: return "English".localized(self)
        case .Spanish: return "Spanish".localized(self)
        case .Hindi: return "Hindi".localized(self)
        case .Danish: return "dansk".localized(self)
        case .German: return "Deutsch".localized(self)
        case .Italian: return "Italiana".localized(self)
        case .Portuguese: return "Português".localized(self)
        case .Turkish: return "Türkçe".localized(self)
        case .Japanese: return "日本語".localized(self)
        case .Dutch: return "Nederlands".localized(self)
        case .Korean: return "한국어".localized(self)
        case .French: return "Français".localized(self)
        case .Russian: return "Русский".localized(self)
        case .Chinese: return "中文".localized(self)
        }
    }
}
import UIKit

class LanguageVC: UIViewController {

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var selectLanLabel: UILabel!
    
    private let languages = SelectLanguage.allCases
    private var selectedIndex: Int = 0
    private let cellIdentifier = "LanguageCell"
    private let numberOfColumns: Int = 1
    private let sideSpacing: CGFloat = 10
    var isOpenFromApp: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    func setUI() {
        setLoca()
        setCollectionView()
        // Set default selected to first index
        selectedIndex = 0
    }
    
    func setLoca() {
        self.titleLabel.text = "Choose your preferred language".localized(LocalizationService.shared.language)
        self.selectLanLabel.text = "Select Language".localized(LocalizationService.shared.language)
        self.continueButton.setTitle("Continue".localized(LocalizationService.shared.language), for: .normal)
    }
    
    func setCollectionView() {
        collectionView.dataSource = self
        collectionView.delegate = self
        collectionView.register(UINib(nibName: cellIdentifier, bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
        
        // Configure layout with 1 column and side spacing
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = 0
        layout.minimumInteritemSpacing = 0
        
        let totalWidth = collectionView.frame.width
        let itemWidth = totalWidth - (sideSpacing * 2)
        layout.itemSize = CGSize(width: itemWidth, height: 60)
        layout.sectionInset = UIEdgeInsets(top: 0, left: sideSpacing, bottom: 0, right: sideSpacing)
        
        collectionView.collectionViewLayout = layout
        collectionView.reloadData()
    }
    
    @IBAction func continueButtonAction(_ sender: UIButton) {
        // Save selected language
        let selectedLanguage = languages[selectedIndex]
        AppStorage.set(selectedLanguage.rawValue, forKey: UserDefaultKeys.selectedLanguage)
        
        // Set the language in LocalizationService
        LocalizationService.shared.language = selectedLanguage.languageCode
        
        // Navigate to next screen
        navigateToNextScreen()
    }
    
    private func navigateToNextScreen() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate else {
            return
        }
        
        if sceneDelegate.window == nil {
            sceneDelegate.window = UIWindow(windowScene: windowScene)
            sceneDelegate.window?.backgroundColor = .black
        }
        
        guard let window = sceneDelegate.window else { return }
        
        let initialVC: UIViewController
        
        if !(AppStorage.get(forKey: UserDefaultKeys.hasLaunchedBefore) ?? false) {
            // First launch → Onboarding
            let onVC1 = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.o1VC)
            initialVC = onVC1
            AppStorage.set(true, forKey: UserDefaultKeys.hasLaunchedBefore)
        } else {
            // Already launched → Home
            let homeVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
                .instantiateViewController(withIdentifier: Controllers.homeVC)
            initialVC = homeVC
        }
        
        window.rootViewController = initialVC
        window.makeKeyAndVisible()
    }
}

// MARK: - UICollectionViewDataSource, UICollectionViewDelegate
extension LanguageVC: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return languages.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as? LanguageCell else {
            return UICollectionViewCell()
        }
        
        let language = languages[indexPath.row]
        let isSelected = indexPath.row == selectedIndex
        
        // Configure cell
        cell.countyNameLabel.text = language.rawValue
        cell.countryImageView.image = UIImage(named: language.rawValue.lowercased())
        
        // Set selection state
        cell.countrySelectedImageView.isHidden = !isSelected
        cell.countrySelectedCellBackgroundImageView.isHidden = !isSelected
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Update selected index
        selectedIndex = indexPath.row
        
        // Reload collection view to update selection UI
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension LanguageVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let totalWidth = collectionView.frame.width
        let itemWidth = totalWidth - (sideSpacing * 2)
        return CGSize(width: itemWidth, height: 60)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 0, left: sideSpacing, bottom: 0, right: sideSpacing)
    }
}
