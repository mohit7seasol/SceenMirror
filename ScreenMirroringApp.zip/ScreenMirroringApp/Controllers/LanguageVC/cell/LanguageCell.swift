//
//  LanguageCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 16/12/25.
//

import UIKit

class LanguageCell: UICollectionViewCell {

    @IBOutlet weak var countryImageView: UIImageView!
    @IBOutlet weak var countyNameLabel: UILabel!
    @IBOutlet weak var countrySelectedImageView: UIImageView!
    @IBOutlet weak var countrySelectedCellBackgroundImageView: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
