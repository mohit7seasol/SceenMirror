//
//  YTBrowserVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 09/01/26.
//

import UIKit
import WebKit
import SwiftPopup
import XCDYouTubeKit
import HCVimeoVideoExtractor
import SwiftyJSON
import Lottie

class YTBrowserVC: UIViewController {

    @IBOutlet weak var swipeCircleView: UIView!
    @IBOutlet weak var swipeParentView: GradientDesignableView!
    @IBOutlet weak var searchBar: UITextField!
    @IBOutlet weak var browserView: WKWebView!
    @IBOutlet weak var animatedLotiieView: UIView!
    
    private var swipeHelper: SwipeGestureHelper!
    private var videoList = [VideoResolution]()
    private var urlString = "https://www.youtube.com" // Default URL
    private var isVideoUrlSelected = false
    private var isFetchingVideoData = false // Prevent multiple API calls
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUI()
        initBrowser()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.swipeHelper.startHintAnimation()
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        swipeHelper.stopHintAnimation()
    }
    
    func setUI() {
        setupSwipeHelper()
        setSearchbar()
        setupGif()
        updateSwipeViewState()
    }
    
    func setupSwipeHelper() {
        swipeHelper = SwipeGestureHelper()
        swipeHelper.delegate = self
        swipeHelper.setupSwipeGesture(
            swipeCircleView: swipeCircleView,
            swipeParentView: swipeParentView,
            delegate: self
        )
    }
    func setupGif(){
        let animationView = LottieAnimationView()
        let animation = LottieAnimation.named("Next_Swipe.json")
        animationView.animation = animation
        animationView.frame = animatedLotiieView.bounds
        animationView.loopMode = .loop
        self.animatedLotiieView.addSubview(animationView)
        animationView.play()
    }
    func setSearchbar() {
        let searchBarHeight: CGFloat = 48.0
        let cornerRadius: CGFloat = searchBarHeight / 2
        
        SearchTextFieldStyle.apply(
            to: searchBar,
            placeholder: "Search or enter URL",
            leftIcon: UIImage(named: "search_ic"),
            height: searchBarHeight,
            cornerRadius: cornerRadius,
            showClearButton: true
        )
        
        searchBar.delegate = self
        searchBar.addTarget(self, action: #selector(searchTextChanged(_:)), for: .editingChanged)
        searchBar.text = urlString
    }
    
    func initBrowser() {
        browserView.uiDelegate = self
        browserView.navigationDelegate = self
        browserView.addObserver(self, forKeyPath: "URL", options: .new, context: nil)
        
        let requestObj = URLRequest(url: URL(string: urlString)!)
        browserView.load(requestObj)
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey: Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == #keyPath(WKWebView.url) {
            let currentUrl = self.browserView.url?.absoluteString ?? self.searchBar.text ?? ""
            self.searchBar.text = currentUrl
            
            // Reset video detection state
            self.isVideoUrlSelected = false
            self.videoList.removeAll()
            self.isFetchingVideoData = false
            
            // Check if URL is a video URL
            if currentUrl.contains("youtube.com/watch?") {
                self.isVideoUrlSelected = true
                // Only fetch video data for casting, not for playing in browser
                // Video plays directly in browser
            } else if currentUrl.contains("vimeo.com/") {
                self.isVideoUrlSelected = true
                // Video plays directly in browser
            } else if currentUrl.contains("buzzvideos.com/") && currentUrl.validateUrl() {
                self.isVideoUrlSelected = true
            } else if currentUrl.contains("imdb.com/video/") {
                self.isVideoUrlSelected = true
                // Video plays directly in browser
            } else {
                self.isVideoUrlSelected = false
            }
            
            updateSwipeViewState()
        }
    }
    
    private func updateSwipeViewState() {
        swipeParentView.isUserInteractionEnabled = isVideoUrlSelected
        swipeCircleView.isUserInteractionEnabled = isVideoUrlSelected
        swipeParentView.alpha = isVideoUrlSelected ? 1.0 : 0.5
        
        // Add visual feedback
        if isVideoUrlSelected {
            UIView.animate(withDuration: 0.3) {
                self.swipeCircleView.transform = CGAffineTransform(scaleX: 1.1, y: 1.1)
            }
        } else {
            UIView.animate(withDuration: 0.3) {
                self.swipeCircleView.transform = .identity
            }
        }
    }
    
    @objc func searchTextChanged(_ textField: UITextField) {
        // Handle search text changes if needed
    }
    
    @IBAction func backButtonTap(_ sender: UIButton) {
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBAction func backWordTap(_ sender: UIButton) {
        if self.browserView.canGoBack {
            self.browserView.goBack()
        }
    }
    
    @IBAction func forwardTap(_ sender: UIButton) {
        if self.browserView.canGoForward {
            self.browserView.goForward()
        }
    }
    
    @IBAction func refreshTap(_ sender: UIButton) {
        if searchBar.text?.isEmpty ?? true {
            browserView.loadHTMLString("", baseURL: nil)
        } else {
            browserView.reload()
        }
    }
    
    func fetchVideoDataForCasting() {
        guard !isFetchingVideoData else { return }
        isFetchingVideoData = true
        
        let currentUrl = self.searchBar.text ?? ""
        
        if currentUrl.contains("youtube.com/watch?") {
            self.processYoutubeVideo(link: currentUrl)
        } else if currentUrl.contains("vimeo.com/") {
            self.loadVimeoVideo()
        } else if currentUrl.contains("buzzvideos.com/") {
            self.loadBuzzVideo()
        } else if currentUrl.contains("imdb.com/video/") {
            self.loadIMDbVideoFromPage()
        }
    }
    
    func processYoutubeVideo(link: String) {
        if let videoID = link.extractYoutubeId() {
            self.loadYouTubeVideo(videoID: videoID)
        } else {
            print("YouTube video URL not supported")
            isFetchingVideoData = false
        }
    }
    
    func loadYouTubeVideo(videoID: String) {
        let url = "https://yt-api.p.rapidapi.com/dl?id=\(videoID)"
        APIManager().GET_API(api: url, isShowLoader: false) { data in
            defer {
                self.isFetchingVideoData = false
            }
            
            if let data = data {
                do {
                    let dict = try JSONSerialization.jsonObject(with: data)
                    let json = JSON(dict)
                    let thumb = JSON(json["thumbnail"].arrayObject?.last)
                    self.videoList.removeAll()
                    
                    for i in 0..<json["formats"].count {
                        if json["formats"][i]["itag"].intValue == 18 {
                            self.videoList.append(VideoResolution(
                                id: UUID().uuidString,
                                videoName: json["title"].stringValue,
                                videoURL: json["formats"][i]["url"].stringValue,
                                videothumImage: thumb["url"].stringValue,
                                videoAuthor: json["channelTitle"].stringValue,
                                videoResolution: "360p"
                            ))
                        } else if json["formats"][i]["itag"].intValue == 398 {
                            self.videoList.append(VideoResolution(
                                id: UUID().uuidString,
                                videoName: json["title"].stringValue,
                                videoURL: json["formats"][i]["url"].stringValue,
                                videothumImage: thumb["url"].stringValue,
                                videoAuthor: json["channelTitle"].stringValue,
                                videoResolution: "1080p"
                            ))
                        } else if json["formats"][i]["itag"].intValue == 22 {
                            self.videoList.append(VideoResolution(
                                id: UUID().uuidString,
                                videoName: json["title"].stringValue,
                                videoURL: json["formats"][i]["url"].stringValue,
                                videothumImage: thumb["url"].stringValue,
                                videoAuthor: json["channelTitle"].stringValue,
                                videoResolution: "720p"
                            ))
                        }
                    }
                    
                    DispatchQueue.main.async {
                        if self.videoList.count > 0 {
                            print("YouTube video data loaded: \(self.videoList.count) resolutions")
                        } else {
                            print("No valid video formats found")
                        }
                    }
                } catch {
                    print("Error parsing YouTube data: \(error)")
                }
            } else {
                print("No data received from YouTube API")
            }
        }
    }
    
    func loadVimeoVideo() {
        guard let url = URL(string: self.searchBar.text ?? "") else {
            isFetchingVideoData = false
            return
        }
        
        HCVimeoVideoExtractor.fetchVideoURLFrom(url: url) { (video: HCVimeoVideo?, error: Error?) in
            defer {
                self.isFetchingVideoData = false
            }
            
            if let err = error {
                print("Vimeo error: \(err.localizedDescription)")
                return
            }
            
            guard let vid = video else {
                print("Invalid video object")
                return
            }
            
            var vimiothumURL: URL!
            
            if let url = vid.thumbnailURL[.quality1280] {
                vimiothumURL = url
            } else if let url = vid.thumbnailURL[.quality960] {
                vimiothumURL = url
            } else if let url = vid.thumbnailURL[.quality640] {
                vimiothumURL = url
            } else if let url = vid.thumbnailURL[.qualityBase] {
                vimiothumURL = url
            } else {
                vimiothumURL = vid.thumbnailURL[.qualityUnknown]
            }
            
            self.videoList.removeAll()
            vid.videoURL.forEach { (video) in
                let resolutionMap: [HCVimeoVideoQuality: String] = [
                    .quality1080p: "1080p",
                    .quality960p: "960p",
                    .quality720p: "720p",
                    .quality640p: "640p",
                    .quality540p: "540p",
                    .quality360p: "360p"
                ]
                
                if let resolution = resolutionMap[video.key], vimiothumURL != nil {
                    self.videoList.append(VideoResolution(
                        id: UUID().uuidString,
                        videoName: vid.title,
                        videoURL: video.value.absoluteString,
                        videothumImage: vimiothumURL.absoluteString,
                        videoAuthor: "",
                        videoResolution: resolution
                    ))
                }
            }
            
            DispatchQueue.main.async {
                self.videoList = self.videoList.unique { $0.videoResolution }
                if self.videoList.count > 0 {
                    print("Vimeo video data loaded: \(self.videoList.count) resolutions")
                }
            }
        }
    }
    
    func loadBuzzVideo() {
        self.browserView.evaluateJavaScript("document.body.innerHTML") { (anyObject, error) in
            defer {
                self.isFetchingVideoData = false
            }
            
            guard let htmlStr = anyObject as? String else { return }
            
            if let between = htmlStr.between("https://i.rmbl.ws/s8", "b=0") {
                guard let mediaURL = URL(string: "https://i.rmbl.ws/s8" + between + "b=0") else {
                    print("Invalid Video URL")
                    return
                }
                
                self.videoList.removeAll()
                let urlStr = mediaURL.absoluteString
                
                // Add different resolutions
                let resolutions = [
                    ("360p", ".baa"),
                    ("480p", ".caa"),
                    ("720p", ".gaa"),
                    ("1080p", ".haa")
                ]
                
                for (resolution, extensionType) in resolutions {
                    if urlStr.contains(extensionType) {
                        self.videoList.append(VideoResolution(
                            id: UUID().uuidString,
                            videoName: mediaURL.lastPathComponent,
                            videoURL: mediaURL.absoluteString,
                            videothumImage: "",
                            videoAuthor: "",
                            videoResolution: resolution
                        ))
                    } else {
                        // Try to generate other resolutions
                        let newUrlStr = urlStr.replacingOccurrences(of: ".baa", with: extensionType)
                        if UIApplication.shared.canOpenURL(URL(string: newUrlStr)!) {
                            self.videoList.append(VideoResolution(
                                id: UUID().uuidString,
                                videoName: mediaURL.lastPathComponent,
                                videoURL: newUrlStr,
                                videothumImage: "",
                                videoAuthor: "",
                                videoResolution: resolution
                            ))
                        }
                    }
                }
                
                DispatchQueue.main.async {
                    self.videoList = self.videoList.unique { $0.videoResolution }
                    if self.videoList.count > 0 {
                        print("Buzz video data loaded: \(self.videoList.count) resolutions")
                    }
                }
            }
        }
    }
    
    func loadIMDbVideoFromPage() {
        self.browserView.evaluateJavaScript("document.getElementById('__NEXT_DATA__').innerHTML") { (result, error) in
            defer {
                self.isFetchingVideoData = false
            }
            
            if let jsonValue = result as? String {
                self.loadIMDbVideo(value: jsonValue)
            }
        }
    }
    
    func loadIMDbVideo(value: String) {
        if let jsonData = value.data(using: .utf8) {
            do {
                if let jsonObject = try JSONSerialization.jsonObject(with: jsonData) as? [String: Any] {
                    let json = JSON(jsonObject)
                    let videoArray = json["props"]["videoPlaybackData"]["video"]["playbackURLs"]
                    self.videoList.removeAll()
                    
                    for i in 0..<videoArray.count {
                        if videoArray[i]["mimeType"].stringValue == "video/mp4" {
                            self.videoList.append(VideoResolution(
                                id: UUID().uuidString,
                                videoName: videoArray[i]["displayName"]["value"].stringValue,
                                videoURL: videoArray[i]["url"].stringValue, // Fixed: using "url" instead of "mimeType"
                                videothumImage: "",
                                videoAuthor: "",
                                videoResolution: videoArray[i]["displayName"]["value"].stringValue
                            ))
                        }
                    }
                    
                    DispatchQueue.main.async {
                        if self.videoList.count > 0 {
                            print("IMDb video data loaded: \(self.videoList.count) resolutions")
                        }
                    }
                }
            } catch {
                print("IMDb error: \(error)")
            }
        }
    }
    
    func openQualityList() {
        // First fetch video data if not already fetched
        if videoList.isEmpty {
            fetchVideoDataForCasting()
            
            // Show loading indicator
            let alert = UIAlertController(title: "Loading Video Data", message: "Please wait while we fetch available resolutions...", preferredStyle: .alert)
            present(alert, animated: true)
            
            // Wait a moment for video data to load, then show quality list
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                alert.dismiss(animated: true) {
                    if self.videoList.isEmpty {
                        self.showAlert(title: "Error", message: "Could not fetch video data. Please make sure you're on a supported video page.")
                    } else {
                        self.showQualityListPopup()
                    }
                }
            }
        } else {
            showQualityListPopup()
        }
    }
    
    private func showQualityListPopup() {
        let vc: QueueCastVc = UIStoryboard(name: StoryboardName.main, bundle: nil)
            .instantiateViewController(withIdentifier: "QueueCastVc") as! QueueCastVc
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        vc.videoList = self.videoList
        
        // Determine video type
        if self.searchBar.text?.contains("youtube.com/watch?") ?? false {
            vc.type = 1
        } else if self.searchBar.text?.contains("vimeo.com/") ?? false {
            vc.type = 2
        } else if self.searchBar.text?.contains("buzzvideos.com/") ?? false {
            vc.type = 3
        } else if self.searchBar.text?.contains("imdb.com") ?? false {
            vc.type = 4
        }
        
        // Set callback for quality selection
        vc.callBack = { [weak self] (modal, index) in
            guard let self = self else { return }
            
            // Navigate to video casting screen
            let castingVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
                .instantiateViewController(withIdentifier: "VideoCastVC") as! VideoCastVC
            castingVC.selectedIndex = index
            castingVC.videoList = modal
            castingVC.type = vc.type
            castingVC.mediatype = .Web // Set mediaType to .Web for web videos
            // No need to set webcast = true as it might not exist
            castingVC.modalPresentationStyle = .fullScreen
            self.navigationController?.pushViewController(castingVC, animated: true)
        }
        
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        vc.showAnimation = showAnimation
        vc.dismissAnimation = dismissAnimation
        
        vc.show()
    }
    
    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    
    deinit {
        browserView.removeObserver(self, forKeyPath: "URL")
    }
}

extension YTBrowserVC: SwipeGestureHelperDelegate {
    func swipeCompleted() {
        // Check if device is connected
        if selectedTvType == .LGTV || selectedTvType == .GcastTV || checkAirPlayStatus().1 {
            // Pause any playing videos before opening quality list
            let script = "var videos = document.getElementsByTagName('video'); for (var i = 0; i < videos.length; i++) { videos.item(i).pause(); };"
            self.browserView.evaluateJavaScript(script) { result, error in
                // Open quality list
                self.openQualityList()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.swipeHelper.performBeautifulReset(animationType: .smooth)
                }
            }
        } else {
            let vc: ListDeviceVc = UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ListDeviceVc") as! ListDeviceVc
            self.navigationController?.pushViewController(vc, animated: true)
        }
        
    }
    
    func swipeCancelled() {
        // Handle swipe cancellation
        self.swipeHelper.performBeautifulReset(animationType: .smooth)
    }
}

extension YTBrowserVC: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        
        if let text = textField.text, !text.isEmpty {
            var urlString = text
            if !urlString.hasPrefix("http://") && !urlString.hasPrefix("https://") {
                urlString = "https://\(urlString)"
            }
            
            if let url = URL(string: urlString) {
                let request = URLRequest(url: url)
                browserView.load(request)
            }
        }
        
        return true
    }
    
    func textFieldShouldClear(_ textField: UITextField) -> Bool {
        return true
    }
}

extension YTBrowserVC: WKNavigationDelegate, WKUIDelegate {
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        decisionHandler(.allow)
    }
    
    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if let url = webView.url?.absoluteString {
            self.searchBar.text = url
        }
    }
    
    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // Update UI after page loads
    }
}

extension Array {
    func unique(by condition: (Element, Element) -> Bool) -> [Element] {
        var result = [Element]()
        for element in self {
            if !result.contains(where: { condition(element, $0) }) {
                result.append(element)
            }
        }
        return result
    }
}
