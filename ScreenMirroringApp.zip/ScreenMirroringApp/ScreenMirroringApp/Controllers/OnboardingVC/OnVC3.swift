//
//  OnVC3.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 15/12/25.
//

import UIKit
import AVKit

class OnVC3: UIViewController {

    @IBOutlet weak var viewItLabel: UILabel!
    @IBOutlet weak var playAllLabel: UILabel!
    @IBOutlet weak var continueButton: UIButton!
    @IBOutlet weak var videoView: UIView!
    @IBOutlet weak var skipButton: UIButton!
    
    var videoName = "intro 3"
    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        setupVideoPlayer()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        player?.play()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        player?.pause()
    }
    
    func setup() {
        setUpLoca()
    }
    
    func setUpLoca() {
        self.viewItLabel.text = "View it all on the TV".localized(LocalizationService.shared.language)
        self.playAllLabel.text = "Play all your photos, videos, and music right on the big screen.".localized(LocalizationService.shared.language)
        self.continueButton.setTitle("Continue".localized(LocalizationService.shared.language), for: .normal)
        self.skipButton.setTitle("Skip".localized(LocalizationService.shared.language), for: .normal)
    }
    
    private func setupVideoPlayer() {
        guard let videoPath = Bundle.main.path(forResource: videoName, ofType: "mp4") else {
            print("Video file not found: \(videoName)")
            return
        }
        
        let videoURL = URL(fileURLWithPath: videoPath)
        player = AVPlayer(url: videoURL)
        playerLayer = AVPlayerLayer(player: player)
        playerLayer?.frame = videoView.bounds
        playerLayer?.videoGravity = .resizeAspectFill
        
        if let playerLayer = playerLayer {
            videoView.layer.addSublayer(playerLayer)
        }
        
        // Loop the video
        NotificationCenter.default.addObserver(self,
            selector: #selector(playerItemDidReachEnd),
            name: .AVPlayerItemDidPlayToEndTime,
            object: player?.currentItem
        )
    }
    
    @objc private func playerItemDidReachEnd(notification: Notification) {
        player?.seek(to: .zero)
        player?.play()
    }
    
    @IBAction func continueButtonAction(_ sender: UIButton) {
        navigateToHome()
    }
    
    @IBAction func skipButtonAction(_ sender: UIButton) {
        navigateToHome()
    }
    
    private func navigateToHome() {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let sceneDelegate = windowScene.delegate as? SceneDelegate,
              let sceneWindow = sceneDelegate.window else { return }
        
        let initialVC: UIViewController
        
        let homeVC = UIStoryboard(name: StoryboardName.onboarding, bundle: nil)
            .instantiateViewController(withIdentifier: Controllers.o1VC)
        initialVC = UIStoryboard(name: StoryboardName.main, bundle: nil)
            .instantiateViewController(withIdentifier: Controllers.homeVC)
        
        // Always wrap in navigation controller
        let navController = UINavigationController(rootViewController: initialVC)
        
        // Customize navigation bar
        let appearance = UINavigationBarAppearance()
        appearance.configureWithOpaqueBackground()
        appearance.backgroundColor = UIColor(named: "#111111")
        appearance.titleTextAttributes = [.foregroundColor: UIColor.white]
        appearance.largeTitleTextAttributes = [.foregroundColor: UIColor.white]
        
        navController.navigationBar.standardAppearance = appearance
        navController.navigationBar.scrollEdgeAppearance = appearance
        navController.navigationBar.tintColor = .white
        
        // Hide nav bar only for HomeVC
        if initialVC is OnVC1 {
            navController.isNavigationBarHidden = true
        }
        
        sceneWindow.rootViewController = navController
        sceneWindow.makeKeyAndVisible()
        
        if let appDelegate = UIApplication.shared.delegate as? AppDelegate {
            appDelegate.window = sceneWindow
            print("✅ AppDelegate window set successfully")
        }
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
}
