//
//  TVListTBLCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit

class TVListTBLCell: UITableViewCell {
    
    @IBOutlet weak var tvNameLabel: UILabel!
    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var tvSelectedBackgroundImageView: UIImageView!
    @IBOutlet weak var bgAnumation: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    func removeLoader(){
        mainView.backgroundColor = #colorLiteral(red: 0.368627451, green: 0.6745098039, blue: 0.9960784314, alpha: 1)
        DispatchQueue.main.async {
            self.bgAnumation.animateFillLeftToRight(color: #colorLiteral(red: 0.1098039216, green: 0.5137254902, blue: 0.9450980392, alpha: 0.4), duration: 1.0,keepFilledAfter: true)
        }
    }
}
extension UIView {
    /// Animates a solid color filling this view from left to right.
    func animateFillLeftToRight(color: UIColor,
                                duration: TimeInterval = 0.8,
                                keepFilledAfter: Bool = true) {
        // Create the fill layer with zero width
        let fillLayer = CALayer()
        fillLayer.backgroundColor = color.cgColor
        fillLayer.frame = CGRect(x: 0, y: 0, width: 0, height: bounds.height)
        layer.sublayers?.removeAll()
        layer.addSublayer(fillLayer)
        // Animate the width of the layer’s bounds
        let anim = CABasicAnimation(keyPath: "bounds.size.width")
        anim.fromValue = 0
        anim.toValue = self.frame.size.width+self.frame.size.width
        anim.duration = duration
        anim.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)

        // Set final state so it stays at 100% after animation (if requested)
        fillLayer.bounds.size.width = self.frame.size.width+self.frame.size.width
        fillLayer.add(anim, forKey: "fillLeftToRight")

        if !keepFilledAfter {
            // Remove the layer when done (optional)
            DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
                fillLayer.removeFromSuperlayer()
            }
        }
    }
}
