//
//  ListDeviceVc.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import NVActivityIndicatorView
import GoogleCast
import Network
import GoogleMobileAds
import ConnectSDK
import SVProgressHUD
import AVKit
import FirebaseAnalytics
import Lottie
import SwiftPopup

protocol ChangeTVName : AnyObject{
    func setTvName(tvName : String)
}

class ListDeviceVc: UIViewController,GCKDiscoveryManagerListener, GCKSessionManagerListener {
    @IBOutlet weak var connectYourLabel: UILabel!
    @IBOutlet weak var lottieAnimatedView: UIView!
    @IBOutlet weak var searchingLabel: UILabel!
    @IBOutlet weak var airPlayTitleLabel: UILabel!
    @IBOutlet weak var airPlayLabel: UILabel!
    @IBOutlet weak var airPlayStatusLabel: UILabel!
    @IBOutlet weak var otherConnectionsLabel: UILabel!
    @IBOutlet weak var otherConnectionsView: UIView!
    @IBOutlet weak var viNoLocalNetWork: UIView!
    @IBOutlet weak var viCheckWifi: UIView!
    @IBOutlet weak var viPlaceHolder: UIView!
    @IBOutlet weak var tblTVList: UITableView!{
        didSet{
            tblTVList.delegate = self
            tblTVList.dataSource = self
            tblTVList.register(UINib(nibName: "TVListTBLCell", bundle: nil), forCellReuseIdentifier: "TVListTBLCell")
        }
    }
    @IBOutlet weak var viAriPlay: UIView!
    
    weak var tvDelegate : ChangeTVName?
    var delegate: SelectedDevice?
    
    var routePickerView: AVRoutePickerView!
    var isSelecct : Bool = false
    var selectIndex : IndexPath!
    var allDevices: [DeviceType] {
        if commonViewModel != nil{
            let lg = commonViewModel.connectSDKDiscoveryModel.lgDevices.map { DeviceType.lg($0) }
            let cast = commonViewModel.castViewModel.devices.map { DeviceType.cast($0) }
            return lg + cast
        }else{
            return []
        }
    }
    var onConnect: (() -> Void)?
    var timer: Timer?
    var newdevices : [DeviceType] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setupGif()
        setupAirPlay()
        setUI()
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(appDidBecomeActive),
            name: UIScene.didActivateNotification,
            object: nil
        )
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        refreshData()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        disableFloatingBarTouch()
    }
    @objc func appDidBecomeActive() {
        print("App became active - refresh UI")
        refreshData()
    }
    func setUI() {
    }
    func refreshData(){
        LocalNetworkAuthorization().requestAuthorization { granted in
            if granted {
                self.viNoLocalNetWork.isHidden = true
                self.tblTVList.isHidden = false
                self.viPlaceHolder.isHidden = false
                self.tblTVList.isHidden = true
                if commonViewModel == nil{
                    commonViewModel = CommonViewModel()
                }
                commonViewModel.connectSDKDiscoveryModel.superVC = self
                commonViewModel.castViewModel.superVC = self
                NetworkManager.shared.checkIfConnectedToWiFi()
                NetworkManager.shared.onNetWorkReachable = { [weak self] in
                    self?.viCheckWifi.isHidden = true
                    self?.tblTVList.reloadData()
                }
                DiscoveryManager.shared().startDiscovery()
                self.newdevices = self.allDevices
                self.timer = Timer.scheduledTimer(withTimeInterval: 3.0, repeats: true) { [weak self] _ in
                    if self?.newdevices.count != self?.allDevices.count{
                        self?.newdevices = self?.allDevices ?? []
                        self?.tblTVList.reloadData()
                    }
                }
                DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(8)) {
                    if self.allDevices.count > 0{
                        self.viPlaceHolder.isHidden = true
                        self.viCheckWifi.isHidden = true
                        self.tblTVList.isHidden = false
                        self.otherConnectionsView.isHidden = false
                    }else{
                        self.viPlaceHolder.isHidden = true
                        self.viCheckWifi.isHidden = false
                        self.tblTVList.isHidden = true
                        self.otherConnectionsView.isHidden = true
                    }
                }
            }else{
                self.viPlaceHolder.isHidden = true
                self.viCheckWifi.isHidden = true
                self.viNoLocalNetWork.isHidden = false
                self.tblTVList.isHidden = true
                self.otherConnectionsView.isHidden = false
                print("❌ Local Network permission denied")
            }
        }
    }
    func setupGif(){
        let animationView = LottieAnimationView()
        let animation = LottieAnimation.named("Connect to tv")
        animationView.animation = animation
        animationView.frame = lottieAnimatedView.bounds
        animationView.loopMode = .loop
        self.lottieAnimatedView.addSubview(animationView)
        animationView.play()

    }
    
    func showloader(isShow : Bool, isShowPopup : Bool = true){
//        if isShow{
//            if let cell = self.tblTVList.cellForRow(at: selectIndex) as? TVListTBLCell{
//                cell.imgShowConnect.isHidden = true
//                cell.setLoaderGif()
//                cell.lblTVConnectAndDisconect.text = "Connecting..."
//            }
//        }else{
//            if let cell = self.tblTVList.cellForRow(at: selectIndex) as? TVListTBLCell{
//                cell.removeLoader()
//                cell.imgShowConnect.isHidden = false
//                cell.lblTVConnectAndDisconect.text = "Connected"
//                cell.imgShowConnect.image = UIImage(named: "logoConnect")
//                DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000)) {
//                    if isShowPopup{
//                        self.openConnectionPop()
//                    }
//                }
//            }
//        }
    }
    
    @IBAction func backButtonAction(_ sender: UIButton) {
        if self.delegate != nil{
            self.delegate?.Device(isSelected: true)
        }
        self.navigationController?.popViewController(animated: true)
    }
}
extension ListDeviceVc: UITableViewDelegate, UITableViewDataSource{
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let count = allDevices.count
        if count > 0{
            self.tblTVList.isHidden = false
            self.viPlaceHolder.isHidden = true
            self.viCheckWifi.isHidden = true
            self.viNoLocalNetWork.isHidden = true
            self.otherConnectionsView.isHidden = true
        }else{
            viPlaceHolder.isHidden = false
        }
        return count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tblTVList.dequeueReusableCell(withIdentifier: "TVListTBLCell", for: indexPath) as! TVListTBLCell
        let selectedDevice = getSelectedTV()
        let model = allDevices[indexPath.row]
        cell.tvNameLabel.text = model.name
        if selectedDevice == "LG-\(model.name)" || selectedDevice == "Gcast-\(model.name)" {
            cell.removeLoader()
            cell.tvSelectedBackgroundImageView.image = UIImage(named: "tv_select_bg")
            tvDelegate?.setTvName(tvName: "\(model.name)")
            switch model {
            case .lg(let lgDevice):
                if let index = commonViewModel.connectSDKDiscoveryModel.lgDevices.firstIndex(of: lgDevice) {
                    selectIndex = indexPath
                    commonViewModel.connectSDKDiscoveryModel.isShowPopup = false
                    if commonViewModel.connectSDKDiscoveryModel.selectedLGDevice == nil{
                        commonViewModel.connectSDKDiscoveryModel.connectToLGDevice(at: index)
                    }else{
                        self.showloader(isShow: false,isShowPopup: false)
                    }
                }
            case .cast(let castDevice):
                selectIndex = indexPath
                if commonViewModel.castViewModel.selectedDevice == nil{
                    commonViewModel.castViewModel.connectToDevice(castDevice, isShowPopup: false)
                }else{
                    self.showloader(isShow: false,isShowPopup: false)
                }
            }
        }else{
            cell.bgAnumation.layer.sublayers?.removeAll()
            cell.tvSelectedBackgroundImageView.image = UIImage(named: "tv_unselect_bg")
        }
        
        /* cell.setOnClickListener {
            self.selectIndex = indexPath
            let selectedDevice = getSelectedTV()
            let model = self.allDevices[indexPath.row]
            
            switch model {
            case .lg(let lgDevice):
                if selectedDevice == "LG-\(model.name)"{
                    self.showDisconnectPop(subTitle: "This device is currently connected. Do you want to disconnect it?".localized(), tvType: .LGTV, devicetype: model, selectedInd: indexPath)
                }else if selectedDevice == ""{
                    if let index = commonViewModel.connectSDKDiscoveryModel.lgDevices.firstIndex(of: lgDevice) {
                        self.showloader(isShow: true)
                        commonViewModel.connectSDKDiscoveryModel.isShowPopup = true
                        commonViewModel.connectSDKDiscoveryModel.connectToLGDevice(at: index)
                    }
                }else if selectedDevice != "" {
                    self.showDisconnectPop(subTitle: "You need to disconnect from current TV to Proceed.".localized(), tvType: .LGTV, devicetype: model, selectedInd: indexPath)
                }else{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AbortPopVC") as! AbortPopVC
                    vc.modalPresentationStyle = .overFullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    vc.tvName = model.name
                    vc.onAbortTV = {
                        self.disConnectTV(selectInd: indexPath, devicetype: model)
                    }
                    self.present(vc, animated: true)
                }
            case .cast(let castDevice):
                SilentAudioManager.shared.start()
                if selectedDevice == "Gcast-\(model.name)"{
                    self.showDisconnectPop(subTitle: "This device is currently connected. Do you want to disconnect it?".localized(), tvType: .GcastTV, devicetype: model, selectedInd: indexPath)
                }else if selectedDevice == ""{
                    self.showloader(isShow: true)
                    commonViewModel.connectSDKDiscoveryModel.isShowPopup = true
                    commonViewModel.castViewModel.connectToDevice(castDevice, isShowPopup: true)
                }else if selectedDevice != "" {
                    self.showDisconnectPop(subTitle: "You need to disconnect from current TV to Proceed.".localized(), tvType: .GcastTV, devicetype: model, selectedInd: indexPath)
                }else{
                    let vc = self.storyboard?.instantiateViewController(withIdentifier: "AbortPopVC") as! AbortPopVC
                    vc.modalPresentationStyle = .overFullScreen
                    vc.modalTransitionStyle = .crossDissolve
                    vc.tvName = model.name
                    vc.onAbortTV = {
                        self.disConnectTV(selectInd: indexPath, devicetype: model)
                    }
                    self.present(vc, animated: true)
                }
            }
        } */
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 72
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectIndex = indexPath
        let selectedDevice = getSelectedTV()
        let model = allDevices[indexPath.row]
        switch model {
        case .lg(let lgDevice):
            if selectedDevice == "LG-\(model.name)"{
                showDisconnectPop(subTitle: "This device is currently connected. Do you want to disconnect it?".localized(), tvType: .LGTV, devicetype: model, selectedInd: indexPath)
            }else if selectedDevice == ""{
                if let index = commonViewModel.connectSDKDiscoveryModel.lgDevices.firstIndex(of: lgDevice) {
                    self.showloader(isShow: true)
                    commonViewModel.connectSDKDiscoveryModel.isShowPopup = true
                    commonViewModel.connectSDKDiscoveryModel.connectToLGDevice(at: index)
                }
            }else if selectedDevice != "" {
                showDisconnectPop(subTitle: "You need to disconnect from current TV to Proceed.".localized(), tvType: .LGTV, devicetype: model, selectedInd: indexPath)
            }else{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AbortPopVC") as! AbortPopVC
                vc.modalPresentationStyle = .overFullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.tvName = model.name
                vc.onAbortTV = { [weak self] in
                    self?.disConnectTV(selectInd: indexPath, devicetype: model)
                }
                self.present(vc, animated: true)
            }
        case .cast(let castDevice):
            SilentAudioManager.shared.start()
            if selectedDevice == "Gcast-\(model.name)"{
                showDisconnectPop(subTitle: "This device is currently connected. Do you want to disconnect it?".localized(), tvType: .GcastTV, devicetype: model, selectedInd: indexPath)
            }else if selectedDevice == ""{
                self.showloader(isShow: true)
                commonViewModel.connectSDKDiscoveryModel.isShowPopup = true
                commonViewModel.castViewModel.connectToDevice(castDevice, isShowPopup: true)
            }else if selectedDevice != "" {
                showDisconnectPop(subTitle: "You need to disconnect from current TV to Proceed.".localized(), tvType: .GcastTV, devicetype: model, selectedInd: indexPath)
            }else{
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "AbortPopVC") as! AbortPopVC
                vc.modalPresentationStyle = .overFullScreen
                vc.modalTransitionStyle = .crossDissolve
                vc.tvName = model.name
                vc.onAbortTV = { [weak self] in
                    self?.disConnectTV(selectInd: indexPath, devicetype: model)
                }
                self.present(vc, animated: true)
            }
        }
        
    } 
    
    func showDisconnectPop(subTitle : String, tvType : TVType,devicetype:DeviceType, selectedInd : IndexPath){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "DisconnectTvPopVC") as! DisconnectTvPopVC
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        vc.subTitle = subTitle
        vc.onDisconnect = {
            if subTitle == "This device is currently connected. Do you want to disconnect it?".localized(){
                setSelectedTV(name: "")
                if tvType == .GcastTV{
                    commonViewModel.connectSDKDiscoveryModel.disconnectLGDevice()
                }else{
                    commonViewModel.castViewModel.disconnectFromDevice()
                    commonViewModel.castViewModel.stopCastingSession()
                }
                
            }else{
                setSelectedTV(name: "")
                if tvType == .GcastTV{
                    commonViewModel.connectSDKDiscoveryModel.disconnectLGDevice()
                    DispatchQueue.main.async {
                        switch devicetype{
                        case .lg(let lgDevice):
                            break
                        case .cast((let castDevice)):
                            commonViewModel.castViewModel.connectToDevice(castDevice, isShowPopup: true)
                        }
                    }
                }else{
                    commonViewModel.castViewModel.disconnectFromDevice()
                    commonViewModel.castViewModel.stopCastingSession()
                    DispatchQueue.main.async {
                        switch devicetype{
                        case .lg(let lgDevice):
                            if let index = commonViewModel.connectSDKDiscoveryModel.lgDevices.firstIndex(of: lgDevice) {
                                commonViewModel.connectSDKDiscoveryModel.connectToLGDevice(at: index)
                            }
                        case .cast((let castDevice)):
                            break
                        }
                    }
                }
            }
            self.disConnectTV(selectInd: selectedInd, devicetype: devicetype)
        }
        
        self.present(vc, animated: true)
    }
    
    func disConnectTV(selectInd : IndexPath,devicetype:DeviceType) {
        if let cell = self.tblTVList.cellForRow(at: selectInd) as? TVListTBLCell{
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(1)) {
                self.tvDelegate?.setTvName(tvName: "Connect to TV")
                DispatchQueue.main.async {
                    self.tblTVList.reloadData()
                }
            }
        }
    }
    
    func openConnectionPop(){
        let vc : ConnectTvPopVC =  UIStoryboard(name: StoryboardName.main, bundle: nil).instantiateViewController(withIdentifier: "ConnectTvPopVC") as! ConnectTvPopVC
        vc.modalPresentationStyle = .overCurrentContext
        vc.modalTransitionStyle = .crossDissolve
        vc.onDismiss = {
//            self.handleSwipeDown()
            self.onConnect?()
        }
        let connectTvPopup: ConnectTvPopVC?
        let showAnimation = ActionSheetShowAnimation()
        showAnimation.duration = 0.3
        showAnimation.springWithDamping = 0.8
        
        let dismissAnimation = ActionSheetDismissAnimation()
        dismissAnimation.duration = 0.2
        
        vc.showAnimation = showAnimation
        vc.dismissAnimation = dismissAnimation
        
        // Present using SwiftPopup
        connectTvPopup = vc
        vc.show()
    }
    
}
extension ListDeviceVc {
    
    func setupAirPlay() {
        // Create AirPlay route picker
        routePickerView = AVRoutePickerView()
        routePickerView.backgroundColor = UIColor.clear
        routePickerView.activeTintColor = UIColor.clear
        routePickerView.tintColor = UIColor.clear
        
        // Add to the designated view
        viAriPlay.addSubview(routePickerView)
        routePickerView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            routePickerView.leadingAnchor.constraint(equalTo: viAriPlay.leadingAnchor),
            routePickerView.trailingAnchor.constraint(equalTo: viAriPlay.trailingAnchor),
            routePickerView.topAnchor.constraint(equalTo: viAriPlay.topAnchor),
            routePickerView.bottomAnchor.constraint(equalTo: viAriPlay.bottomAnchor)
        ])
        checkAirPlayStatus()
        // Listen for route changes
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(audioRouteChanged),
            name: AVAudioSession.routeChangeNotification,
            object: nil
        )
    }
    
    @objc private func audioRouteChanged(_ notification: Notification) {
        guard let userInfo = notification.userInfo,
              let reasonValue = userInfo[AVAudioSessionRouteChangeReasonKey] as? UInt,
              let reason = AVAudioSession.RouteChangeReason(rawValue: reasonValue) else {
            return
        }
        
        DispatchQueue.main.async {
            switch reason {
            case .newDeviceAvailable:
                self.isSelecct = true
                self.checkAirPlayStatus()
            case .oldDeviceUnavailable:
                self.checkAirPlayStatus()
            default:
                break
            }
        }
    }
    
    private func checkAirPlayStatus() {
        let audioSession = AVAudioSession.sharedInstance()
        let currentRoute = audioSession.currentRoute

        for output in currentRoute.outputs {
            if output.portType == .airPlay {
                let workItem = DispatchWorkItem {
                    setSelectedTV(name: "Airplay-\(output.portName)")
                    self.tvDelegate?.setTvName(tvName: "Airplay-\(output.portName)")
                    self.airPlayStatusLabel.text = "Connected to \(output.portName)"
                    self.tblTVList.reloadData()
                    if self.isSelecct {
                        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(1000)) {
                            commonViewModel.castViewModel.selectedDevice = nil
                            commonViewModel.connectSDKDiscoveryModel.selectedLGDevice = nil
                            self.openConnectionPop()
                        }
                    }
                }
                DispatchQueue.main.async(execute: workItem)
                return
            }
        }
    }

    
    func disconnectAirPlay() {
        let session = AVAudioSession.sharedInstance()
        do {
            try session.setActive(true)
            setSelectedTV(name: "")
            tvDelegate?.setTvName(tvName: "Connect to TV")
            self.airPlayStatusLabel.textColor = UIColor(named: "AFAFAF")
            self.airPlayStatusLabel.text = "Not Connected"
            // Force playback to the device's built-in speaker
            try session.overrideOutputAudioPort(.speaker)
        } catch {
            print("Error disconnecting AirPlay: \(error)")
        }
    }
    func disableFloatingBarTouch() {
        guard let window = UIApplication.shared.windows.first else { return }

        for subview in window.subviews {
            if String(describing: type(of: subview)).contains("UIFloatingBar") {
                subview.isUserInteractionEnabled = false
                subview.alpha = 1 // keep visible
            }
        }
    }
}
