//
//  VideoAndPhotoListVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 18/12/25.
//

import UIKit
import Photos

class VideoAndPhotoListVC: UIViewController {
    @IBOutlet weak var albumCV: UICollectionView!
    @IBOutlet weak var albumListCV: UICollectionView!
    
    var MEDIA_TYPE: mediaType = .Photos
    
    // MARK: - Variables
    private var SMART_ALBUM = PHFetchResult<PHAssetCollection>()
    private var OTHER_ALBUM = PHFetchResult<PHAssetCollection>()
    private var ALL_ASSETS = [[String: PHFetchResult<PHAsset>]]()
    private var selectedAlbumAssets = PHFetchResult<PHAsset>()
    private var selectedAlbumIndex = 0
    
    // Cache for image sizes to avoid repeated calculations
    private var imageSizeCache: [IndexPath: CGSize] = [:]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCollectionViews()
        fetchAlbums()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Update layout after view layout
        albumCV.collectionViewLayout.invalidateLayout()
        albumListCV.collectionViewLayout.invalidateLayout()
    }
    
    // MARK: - Setup Methods
    private func setupCollectionViews() {
        // Setup albumCV (horizontal scrolling for albums)
        let albumLayout = UICollectionViewFlowLayout()
        albumLayout.scrollDirection = .horizontal
        albumLayout.minimumLineSpacing = 10
        albumLayout.minimumInteritemSpacing = 10
        albumLayout.sectionInset = UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        
        // Set explicit item size for albumCV to fix sizing issues
        albumLayout.itemSize = CGSize(width: 80, height: 116)
        
        albumCV.collectionViewLayout = albumLayout
        
        albumCV.delegate = self
        albumCV.dataSource = self
        albumCV.register(UINib(nibName: "AlbumListCell", bundle: nil), forCellWithReuseIdentifier: "AlbumListCell")
        albumCV.showsHorizontalScrollIndicator = false
        
        // Setup albumListCV with custom waterfall layout
        let waterfallLayout = CustomWaterfallLayout()
        waterfallLayout.delegate = self
        
        albumListCV.collectionViewLayout = waterfallLayout
        albumListCV.prefetchDataSource = self
        
        albumListCV.delegate = self
        albumListCV.dataSource = self
        albumListCV.register(UINib(nibName: "AlbumPhotoVideoCell", bundle: nil), forCellWithReuseIdentifier: "AlbumPhotoVideoCell")
        
        // Add refresh control for albumListCV if needed
        let refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(refreshAlbumData), for: .valueChanged)
        albumListCV.refreshControl = refreshControl
    }
    
    @objc private func refreshAlbumData() {
        imageSizeCache.removeAll()
        albumListCV.reloadData()
        albumListCV.refreshControl?.endRefreshing()
    }
    
    // MARK: - Fetch Albums
    private func fetchAlbums() {
        PHPhotoLibrary.requestAuthorization { [weak self] (status) in
            guard let self = self else { return }
            
            switch status {
            case .authorized:
                DispatchQueue.main.async {
                    self.fetchAlbumCollections()
                }
            case .denied, .restricted:
                DispatchQueue.main.async {
                    self.showPermissionAlert()
                }
            case .limited, .notDetermined:
                print("Limited or Not Determined authorization")
            @unknown default:
                break
            }
        }
    }
    
    private func fetchAlbumCollections() {
        let fetchOptions = PHFetchOptions()
        if MEDIA_TYPE == .Videos {
            fetchOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.video.rawValue)
        } else if MEDIA_TYPE == .Photos {
            fetchOptions.predicate = NSPredicate(format: "mediaType = %d", PHAssetMediaType.image.rawValue)
        }
        
        SMART_ALBUM = PHAssetCollection.fetchAssetCollections(with: .smartAlbum, subtype: .any, options: nil)
        OTHER_ALBUM = PHAssetCollection.fetchAssetCollections(with: .album, subtype: .any, options: nil)
        
        var fetchedAssets = PHFetchResult<PHAsset>()
        
        // Fetch from SMART albums
        for i in 0..<SMART_ALBUM.count {
            fetchedAssets = PHAsset.fetchAssets(in: SMART_ALBUM[i], options: fetchOptions)
            if fetchedAssets.count > 0 {
                let albumName = SMART_ALBUM[i].localizedTitle ?? "Smart Album"
                let temp = [albumName : fetchedAssets]
                ALL_ASSETS.append(temp)
            }
        }
        
        // Fetch from OTHER albums
        for i in 0..<OTHER_ALBUM.count {
            fetchedAssets = PHAsset.fetchAssets(in: OTHER_ALBUM[i], options: fetchOptions)
            if fetchedAssets.count > 0 {
                let albumName = OTHER_ALBUM[i].localizedTitle ?? "Album"
                let temp = [albumName : fetchedAssets]
                ALL_ASSETS.append(temp)
            }
        }
        
        DispatchQueue.main.async {
            self.albumCV.reloadData()
            if self.ALL_ASSETS.count > 0 {
                // Select first album by default
                self.selectAlbumAtIndex(0)
            }
        }
    }
    
    private func selectAlbumAtIndex(_ index: Int) {
        selectedAlbumIndex = index
        if let albumDict = ALL_ASSETS[safe: index],
           let assets = albumDict.values.first {
            selectedAlbumAssets = assets
        }
        
        // Clear cache when album changes
        imageSizeCache.removeAll()
        
        // Reload albumCV to update selection UI
        albumCV.reloadData()
        
        // Scroll to selected cell
        let indexPath = IndexPath(item: index, section: 0)
        albumCV.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
        
        // Reload albumListCV with new assets
        albumListCV.reloadData()
    }
    
    // Calculate image height based on aspect ratio
    private func calculateImageHeight(for asset: PHAsset, withWidth width: CGFloat) -> CGFloat {
        let aspectRatio = CGFloat(asset.pixelHeight) / CGFloat(asset.pixelWidth)
        
        // Add extra height for video duration label if it's a video
        let extraHeight: CGFloat = MEDIA_TYPE == .Videos ? 30 : 0
        
        return (width * aspectRatio) + extraHeight
    }
    
    private func showPermissionAlert() {
        let alert = UIAlertController(
            title: "Can not access Photos and Videos!",
            message: "You have not given permission for access Photos and Videos. \nGoto settings and give permission 'ALL Photos' to access all Photos and Videos.",
            preferredStyle: .alert
        )
        
        alert.addAction(UIAlertAction(title: "Setting", style: .default, handler: { _ in
            UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        
        present(alert, animated: true)
    }
}

// MARK: - UICollectionViewDataSource
extension VideoAndPhotoListVC: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == albumCV {
            return ALL_ASSETS.count
        } else {
            return selectedAlbumAssets.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if collectionView == albumCV {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AlbumListCell", for: indexPath) as! AlbumListCell
            
            let albumDict = ALL_ASSETS[indexPath.item]
            let albumName = albumDict.keys.first ?? "Unknown"
            let assetsCount = albumDict.values.first?.count ?? 0
            
            cell.albumNameLabel.text = albumName
            
            // Format count like (100+)
            let countText = assetsCount > 99 ? "(99+)" : "(\(assetsCount))"
            cell.totalAssetsCountLabel.text = countText
            
            // Fetch and set thumbnail from first asset - MATCHING AlbumsVc APPROACH
            let name = ALL_ASSETS[indexPath.item].keys.first!
            let assets = ALL_ASSETS[indexPath.item][name]!
            let firstAsset = assets.firstObject
            
            if let firstAsset = firstAsset {
                // Get image size based on thumbImageHeightConstant
                let targetSize = CGSize(width: collectionView.frame.width,
                                      height: collectionView.frame.width)
                cell.albumThumImageView.fetchImageAsset(firstAsset,
                                                      targetSize: targetSize,
                                                      completionHandler: nil)
            } else {
                cell.albumThumImageView.image = UIImage(systemName: "photo.on.rectangle")
            }
            
            // Set selection state
            cell.setSelected(indexPath.item == selectedAlbumIndex)
            
            // Ensure circular layout
            cell.layoutIfNeeded()
            
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "AlbumPhotoVideoCell",
                                                         for: indexPath) as! AlbumPhotoVideoCell
            
            let asset = selectedAlbumAssets[indexPath.item]
            
            // Fetch and set image preview
            cell.photoOrVideoImagePreview.fetchImageAsset(asset,
                                                          targetSize: CGSize(width: 300, height: 300),
                                                          completionHandler: nil)
            
            // Configure for video if needed
            if MEDIA_TYPE == .Videos {
                cell.videoDurationView.isHidden = false
                let duration = Int(asset.duration)
                let minutes = duration / 60
                let seconds = duration % 60
                cell.durationLabel.text = String(format: "%02d:%02d", minutes, seconds)
            } else {
                cell.videoDurationView.isHidden = true
                cell.durationLabel.text = ""
            }
            
            return cell
        }
    }
}

// MARK: - UICollectionViewDelegate
extension VideoAndPhotoListVC: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == albumCV {
            selectAlbumAtIndex(indexPath.item)
        } else {
            // Handle selection of photo/video
            print("Selected asset at index: \(indexPath.item)")
            // You can implement navigation to detail view or casting functionality here
        }
    }
}

// MARK: - UICollectionViewDataSourcePrefetching
extension VideoAndPhotoListVC: UICollectionViewDataSourcePrefetching {
    func collectionView(_ collectionView: UICollectionView, prefetchItemsAt indexPaths: [IndexPath]) {
        if collectionView == albumListCV {
            let options = PHImageRequestOptions()
            options.deliveryMode = .fastFormat
            options.isNetworkAccessAllowed = true
            
            for indexPath in indexPaths {
                guard indexPath.item < selectedAlbumAssets.count else { continue }
                let asset = selectedAlbumAssets[indexPath.item]
                
                // Prefetch thumbnail - provide empty completion handler
                PHImageManager.default().requestImage(for: asset,
                                                     targetSize: CGSize(width: 300, height: 300),
                                                     contentMode: .aspectFill,
                                                     options: options) { (_, _) in
                    // We don't need to do anything with the result for prefetching
                    // The image will be cached by PHImageManager
                }
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cancelPrefetchingForItemsAt indexPaths: [IndexPath]) {
        // You can optionally implement cancellation logic here
        // This is useful if you're using custom image loading
    }
}

// MARK: - UICollectionViewDelegateFlowLayout (For albumCV only)
extension VideoAndPhotoListVC: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       sizeForItemAt indexPath: IndexPath) -> CGSize {
        
        // This method only handles albumCV (horizontal collection view)
        if collectionView == albumCV {
            // Calculate minimum cell height: thumbImageHeightConstant + extra space
            // thumbImageHeightConstant is 66, add 42 extra space = 108 total height
            // Width should match height for circular layout
            let thumbHeight: CGFloat = 66 // From your thumbImageHeightConstant
            let cellHeight: CGFloat = thumbHeight + 42 // Total 108
            let cellWidth: CGFloat = thumbHeight // Square for circular image
            
            return CGSize(width: cellWidth, height: cellHeight)
        }
        
        // Return zero for albumListCV - it will be handled by CustomWaterfallLayout
        return CGSize.zero
    }
    
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == albumCV {
            return 10
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if collectionView == albumCV {
            return 10
        }
        return 0
    }
    
    func collectionView(_ collectionView: UICollectionView,
                       layout collectionViewLayout: UICollectionViewLayout,
                       insetForSectionAt section: Int) -> UIEdgeInsets {
        if collectionView == albumCV {
            return UIEdgeInsets(top: 0, left: 10, bottom: 0, right: 10)
        }
        return UIEdgeInsets.zero
    }
}

// MARK: - CustomWaterfallLayoutDelegate (For albumListCV only)
extension VideoAndPhotoListVC: CustomWaterfallLayoutDelegate {
    func collectionView(_ collectionView: UICollectionView,
                       heightForItemAt indexPath: IndexPath,
                       withWidth width: CGFloat) -> CGFloat {
        
        // Check cache first
        if let cachedSize = imageSizeCache[indexPath] {
            return cachedSize.height
        }
        
        // Calculate height if not cached
        guard indexPath.item < selectedAlbumAssets.count else {
            return 200 // Default fallback
        }
        
        let asset = selectedAlbumAssets[indexPath.item]
        let height = calculateImageHeight(for: asset, withWidth: width)
        
        // Cache the calculated size
        imageSizeCache[indexPath] = CGSize(width: width, height: height)
        
        return height
    }
    
    func columnCountForCollectionView(_ collectionView: UICollectionView) -> Int {
        // Return 2 columns for portrait, 3 for landscape on iPad
        if UIDevice.current.userInterfaceIdiom == .pad {
            return collectionView.bounds.width > 600 ? 3 : 2
        }
        return 2
    }
}

// MARK: - UIColor Extension for hex color
extension UIColor {
    convenience init?(hex: String) {
        var hexString = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if hexString.hasPrefix("#") {
            hexString.remove(at: hexString.startIndex)
        }
        
        guard hexString.count == 6 else { return nil }
        
        var rgbValue: UInt64 = 0
        Scanner(string: hexString).scanHexInt64(&rgbValue)
        
        self.init(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: 1.0
        )
    }
}

// MARK: - Array Extension for safe indexing
extension Array {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
