//
//  AlbumListCell.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 18/12/25.
//

import UIKit

class AlbumListCell: UICollectionViewCell {
    @IBOutlet weak var albumThumImageView: UIImageView!
    @IBOutlet weak var albumNameLabel: UILabel!
    @IBOutlet weak var totalAssetsCountLabel: UILabel!
    @IBOutlet weak var albumSelectedView: UIView!
    @IBOutlet weak var thumbImageHeightConstant: NSLayoutConstraint!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        setupUI()
        // Set constant value for thumb image height
        thumbImageHeightConstant.constant = 66
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        // Update corner radius after layout is complete
        updateCircularLayout()
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        albumThumImageView.image = nil
        albumSelectedView.isHidden = true
    }
    
    private func setupUI() {
        // Use hex color for selected view background
        albumSelectedView.backgroundColor = UIColor(hex: "#3F8FFF")
        albumSelectedView.isHidden = true
        
        // Set image view properties
        albumThumImageView.contentMode = .scaleAspectFill
        albumThumImageView.clipsToBounds = true
        albumThumImageView.backgroundColor = .systemGray6
        
        // Apply corner radius immediately
        albumThumImageView.layer.cornerRadius = thumbImageHeightConstant.constant / 2
        albumSelectedView.layer.cornerRadius = thumbImageHeightConstant.constant / 2
    }
    
    private func updateCircularLayout() {
        // Ensure circular layout with thumbImageHeightConstant
        albumThumImageView.layer.cornerRadius = thumbImageHeightConstant.constant / 2
        albumSelectedView.layer.cornerRadius = thumbImageHeightConstant.constant / 2
        
        // Apply border based on selection state
        albumThumImageView.layer.borderWidth = 2
        albumThumImageView.layer.borderColor = albumSelectedView.isHidden ? UIColor.clear.cgColor : UIColor(hex: "#3F8FFF")?.cgColor
    }
    
    func setSelected(_ isSelected: Bool) {
        albumSelectedView.isHidden = !isSelected
        
        // Change border color when selected
        albumThumImageView.layer.borderColor = isSelected ? UIColor(hex: "#3F8FFF")?.cgColor : UIColor.clear.cgColor
        
        // Ensure layout updates
        layoutIfNeeded()
    }
}
