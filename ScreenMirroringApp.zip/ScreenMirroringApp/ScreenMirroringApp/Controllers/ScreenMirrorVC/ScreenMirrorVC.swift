//
//  ScreenMirrorVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import Lottie

class ScreenMirrorVC: UIViewController {

    @IBOutlet weak var navigationTitleLabel: UILabel!
    @IBOutlet weak var connectedDeviceLabel: UILabel!
    @IBOutlet weak var connectButton: UIButton!
    @IBOutlet weak var mirrorScreenLabel: UILabel!
    @IBOutlet weak var mirroScreenTitleLabel: UILabel!
    @IBOutlet weak var playOrigionalLabel: UILabel!
    @IBOutlet weak var playOrigionalBackgroundSelectedImageView: UIImageView!
    @IBOutlet weak var playOrigionalSelectedDotImageView: UIImageView!
    @IBOutlet weak var playMediumBackgroundSelectedImageView: UIImageView!
    @IBOutlet weak var playMediumSelectedDotImageView: UIImageView!
    @IBOutlet weak var playMediumLabel: UILabel!
    @IBOutlet weak var playHeighLabel: UILabel!
    @IBOutlet weak var playHeighBackgroundSelectedImageView: UIImageView!
    @IBOutlet weak var playHeighSelectedDotImageView: UIImageView!
    @IBOutlet weak var lottieAnimatedView: UIView!
    @IBOutlet weak var displayTvButton: UIButton!
    @IBOutlet weak var playOrigionalButton: UIButton!
    @IBOutlet weak var playMediumButton: UIButton!
    @IBOutlet weak var playHighButton: UIButton!
    
    var lottieFileName = "Connect to tv"
    private var animationView: LottieAnimationView?
    
    // Enum for quality selection
    enum VideoQuality {
        case original
        case medium
        case high
    }
    
    private var selectedQuality: VideoQuality = .original
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        setLoca()
        setupLottieAnimation()
        setupDefaultSelection()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        animationView?.play()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        animationView?.pause()
    }
    
    func setUpUI() {
        
    }
    
    func setLoca() {
        self.navigationTitleLabel.text = "Mirror Screen To TV".localized(LocalizationService.shared.language)
        self.connectButton.setTitle("Connect".localized(LocalizationService.shared.language), for: .normal)
        self.mirrorScreenLabel.text = "Mirror Screen To TV".localized(LocalizationService.shared.language)
        self.mirroScreenTitleLabel.text = "Mirror Screen To TV".localized(LocalizationService.shared.language)
        self.playOrigionalLabel.text = "Play Original Quality".localized(LocalizationService.shared.language)
        self.playMediumLabel.text = "Play Medium Quality".localized(LocalizationService.shared.language)
        self.playHeighLabel.text = "Play High Quality".localized(LocalizationService.shared.language)
        self.displayTvButton.setTitle("Display on TV".localized(LocalizationService.shared.language), for: .normal)
    }
    
    // MARK: - Lottie Animation Setup
    private func setupLottieAnimation() {
        // Initialize Lottie animation view
        animationView = LottieAnimationView(name: lottieFileName)
        animationView?.frame = lottieAnimatedView.bounds
        animationView?.contentMode = .scaleAspectFit
        animationView?.loopMode = .loop
        animationView?.animationSpeed = 1.0
        
        if let animationView = animationView {
            lottieAnimatedView.addSubview(animationView)
            
            // Add constraints to fill the parent view
            animationView.translatesAutoresizingMaskIntoConstraints = false
            NSLayoutConstraint.activate([
                animationView.topAnchor.constraint(equalTo: lottieAnimatedView.topAnchor),
                animationView.bottomAnchor.constraint(equalTo: lottieAnimatedView.bottomAnchor),
                animationView.leadingAnchor.constraint(equalTo: lottieAnimatedView.leadingAnchor),
                animationView.trailingAnchor.constraint(equalTo: lottieAnimatedView.trailingAnchor)
            ])
            
            // Start animation
            animationView.play()
        }
    }
    
    // MARK: - Quality Selection Setup
    private func setupDefaultSelection() {
        // Set default selection to Original Quality
        selectedQuality = .original
        updateQualitySelectionUI()
    }
    
    private func updateQualitySelectionUI() {
        // Reset all images to unselected state
        playOrigionalBackgroundSelectedImageView.image = UIImage(named: "mirror_unselected")
        playOrigionalSelectedDotImageView.image = UIImage(named: "unselected_dot")
        
        playMediumBackgroundSelectedImageView.image = UIImage(named: "mirror_unselected")
        playMediumSelectedDotImageView.image = UIImage(named: "unselected_dot")
        
        playHeighBackgroundSelectedImageView.image = UIImage(named: "mirror_unselected")
        playHeighSelectedDotImageView.image = UIImage(named: "unselected_dot")
        
        // Set selected state based on selectedQuality
        switch selectedQuality {
        case .original:
            playOrigionalBackgroundSelectedImageView.image = UIImage(named: "mirror_selected")
            playOrigionalSelectedDotImageView.image = UIImage(named: "selected_dot")
            
        case .medium:
            playMediumBackgroundSelectedImageView.image = UIImage(named: "mirror_selected")
            playMediumSelectedDotImageView.image = UIImage(named: "selected_dot")
            
        case .high:
            playHeighBackgroundSelectedImageView.image = UIImage(named: "mirror_selected")
            playHeighSelectedDotImageView.image = UIImage(named: "selected_dot")
        }
    }
    
    // MARK: - Quality Selection Methods
    private func selectOriginalQuality() {
        selectedQuality = .original
        updateQualitySelectionUI()
        print("Selected: Original Quality")
        // Add your original quality logic here
    }
    
    private func selectMediumQuality() {
        selectedQuality = .medium
        updateQualitySelectionUI()
        print("Selected: Medium Quality")
        // Add your medium quality logic here
    }
    
    private func selectHighQuality() {
        selectedQuality = .high
        updateQualitySelectionUI()
        print("Selected: High Quality")
        // Add your high quality logic here
    }
    
    // MARK: - Helper Methods
    private func saveSelectedQuality() {
        // Save the selected quality to UserDefaults or your preferred storage
        let qualityString: String
        switch selectedQuality {
        case .original: qualityString = "original"
        case .medium: qualityString = "medium"
        case .high: qualityString = "high"
        }
        
        UserDefaults.standard.set(qualityString, forKey: "SelectedVideoQuality")
        UserDefaults.standard.synchronize()
    }
    
    private func loadSelectedQuality() {
        // Load previously selected quality if available
        if let savedQuality = UserDefaults.standard.string(forKey: "SelectedVideoQuality") {
            switch savedQuality {
            case "original": selectedQuality = .original
            case "medium": selectedQuality = .medium
            case "high": selectedQuality = .high
            default: selectedQuality = .original
            }
            updateQualitySelectionUI()
        }
    }
}

// MARK: - Button Actions
extension ScreenMirrorVC {
    
    @IBAction func backButtonTap(_ sender: Any) {
        navigationController?.popViewController(animated: true)
    }
    
    @IBAction func fAQButtonTap(_ sender: Any) {
        // Handle FAQ button tap
        print("FAQ button tapped")
        // Add your FAQ navigation logic here
    }
    
    @IBAction func mirroScreenSwitchTap(_ sender: UISwitch) {
        // Handle mirror screen switch
        print("Mirror screen switch: \(sender.isOn ? "ON" : "OFF")")
        // Add your mirror screen logic here
        
        // You might want to enable/disable other controls based on switch state
        playOrigionalButton.isEnabled = sender.isOn
        playMediumButton.isEnabled = sender.isOn
        playHighButton.isEnabled = sender.isOn
        displayTvButton.isEnabled = sender.isOn
    }
    
    @IBAction func playOrigionalQualityTap(_ sender: Any) {
        selectOriginalQuality()
    }
    
    @IBAction func playMediumQualityTap(_ sender: Any) {
        selectMediumQuality()
    }
    
    @IBAction func playHighQualityTap(_ sender: Any) {
        selectHighQuality()
    }
    
    @IBAction func displayOnTvTap(_ sender: Any) {
        // Handle display on TV action
        print("Display on TV tapped with quality: \(selectedQuality)")
        
        // Save the selected quality
        saveSelectedQuality()
        
        // Add your display on TV logic here based on selected quality
        switch selectedQuality {
        case .original:
            print("Starting mirroring with original quality...")
        case .medium:
            print("Starting mirroring with medium quality...")
        case .high:
            print("Starting mirroring with high quality...")
        }
    }
    
    @IBAction func connectedTvListTap(_ sender: Any) {
        // Handle connected TV list tap
        print("Connected TV list tapped")
        // Add your TV list navigation logic here
    }
}
