//
//  SelectedDevicePopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
protocol SelectedDevice {
    func Device(isSelected:Bool)
}
class SelectedDevicePopVC: UIViewController {

    var delegate:SelectedDevice?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
