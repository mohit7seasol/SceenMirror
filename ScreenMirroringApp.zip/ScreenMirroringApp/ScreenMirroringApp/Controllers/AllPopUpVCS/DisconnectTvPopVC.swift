//
//  DisconnectTvPopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit

class DisconnectTvPopVC: UIViewController {
    var subTitle : String?
    var onDisconnect: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
