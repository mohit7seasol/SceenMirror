//
//  ConnectTvPopVC.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//

import UIKit
import SwiftPopup
import Lottie

class ConnectTvPopVC: SwiftPopup {
    
    @IBOutlet weak var lottieAnimatedView: UIView!
    
    var onDismiss: (() -> Void)?
    var isPaymentOne : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playLottie()
    }

    func playLottie() {
        let animationView = LottieAnimationView()
        let animation = LottieAnimation.named("Connect to tv")
        animationView.animation = animation
        animationView.frame = lottieAnimatedView.bounds
        animationView.loopMode = .loop
        self.lottieAnimatedView.addSubview(animationView)
        animationView.play()
    }
    @IBAction func closeButtonAction(_ sender: Any) {
        dismiss()
    }
    
    @IBAction func continueButtonAction(_ sender: Any) {
        dismiss()
    }
}
