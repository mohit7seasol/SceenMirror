//
//  SkeletonCustomView7.swift
//  MovieHub
//
//  Created by Parthiv Akbari on 04/07/25.
//

import UIKit

class SkeletonCustomView7: UIView {

    @IBOutlet weak var shimmerView: View!
    @IBOutlet weak var view1: View!
    @IBOutlet weak var view2: View!
    @IBOutlet weak var view3: View!
    @IBOutlet weak var view5: View!
    
    

}
