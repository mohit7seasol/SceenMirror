//
//  CustomWaterfallLayout.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 31/12/25.
//

import UIKit

protocol CustomWaterfallLayoutDelegate: AnyObject {
    func collectionView(_ collectionView: UICollectionView,
                       heightForItemAt indexPath: IndexPath,
                       withWidth width: CGFloat) -> CGFloat
    func columnCountForCollectionView(_ collectionView: UICollectionView) -> Int
}

class CustomWaterfallLayout: UICollectionViewLayout {
    
    // MARK: - Properties
    weak var delegate: CustomWaterfallLayoutDelegate?
    
    private var numberOfColumns = 2
    private var cellPadding: CGFloat = 2
    private var contentHeight: CGFloat = 0
    private var contentWidth: CGFloat {
        guard let collectionView = collectionView else { return 0 }
        let insets = collectionView.contentInset
        return collectionView.bounds.width - (insets.left + insets.right)
    }
    
    private var cache: [UICollectionViewLayoutAttributes] = []
    private var columnHeights: [CGFloat] = []
    
    // MARK: - Layout Preparation
    override func prepare() {
        super.prepare()
        
        guard let collectionView = collectionView else { return }
        
        // Reset
        cache.removeAll()
        columnHeights.removeAll()
        contentHeight = 0
        
        // Get column count from delegate or use default
        numberOfColumns = delegate?.columnCountForCollectionView(collectionView) ?? 2
        
        // Initialize column heights
        columnHeights = Array(repeating: 0, count: numberOfColumns)
        
        let columnWidth = contentWidth / CGFloat(numberOfColumns)
        var xOffset: [CGFloat] = []
        
        for column in 0..<numberOfColumns {
            xOffset.append(CGFloat(column) * columnWidth)
        }
        
        var column = 0
        let numberOfItems = collectionView.numberOfItems(inSection: 0)
        
        for item in 0..<numberOfItems {
            let indexPath = IndexPath(item: item, section: 0)
            
            // Get item height from delegate
            let itemHeight = delegate?.collectionView(collectionView,
                                                     heightForItemAt: indexPath,
                                                     withWidth: columnWidth) ?? 200
            
            // Calculate frame
            let height = cellPadding * 2 + itemHeight
            let frame = CGRect(x: xOffset[column],
                             y: columnHeights[column],
                             width: columnWidth,
                             height: height)
            
            let insetFrame = frame.insetBy(dx: cellPadding, dy: cellPadding)
            
            // Create attributes
            let attributes = UICollectionViewLayoutAttributes(forCellWith: indexPath)
            attributes.frame = insetFrame
            cache.append(attributes)
            
            // Update column height
            columnHeights[column] = columnHeights[column] + height
            
            // Update content height
            contentHeight = max(contentHeight, columnHeights[column])
            
            // Move to next column (find shortest column)
            column = shortestColumnIndex()
        }
    }
    
    private func shortestColumnIndex() -> Int {
        var shortestIndex = 0
        var shortestHeight = CGFloat.greatestFiniteMagnitude
        
        for (index, height) in columnHeights.enumerated() {
            if height < shortestHeight {
                shortestHeight = height
                shortestIndex = index
            }
        }
        return shortestIndex
    }
    
    // MARK: - Layout Attributes
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        var visibleLayoutAttributes: [UICollectionViewLayoutAttributes] = []
        
        for attributes in cache {
            if attributes.frame.intersects(rect) {
                visibleLayoutAttributes.append(attributes)
            }
        }
        return visibleLayoutAttributes
    }
    
    override func layoutAttributesForItem(at indexPath: IndexPath) -> UICollectionViewLayoutAttributes? {
        return cache[indexPath.item]
    }
    
    // MARK: - Collection View Content Size
    override var collectionViewContentSize: CGSize {
        return CGSize(width: contentWidth, height: contentHeight)
    }
    
    // MARK: - Invalidation
    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        guard let collectionView = collectionView else { return false }
        return newBounds.width != collectionView.bounds.width
    }
}
