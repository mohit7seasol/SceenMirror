//
//  AppStrings.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//


import Foundation

struct AppStrings {
    static let groupID = "group.com.casttoscreen.castplay"//.com.multi.tv"
    static let appExtensionPackageName = "com.casttoscreen.castplay.Screen-Casting-Extension"//"com.multi.tv.Screen-Casting-Extension"
    
    static let deviceIPKey = "ConnectedDeviceIP"
    static let serverUrlKey = "serverURL"
    
    static let pexelWebKey = "EvP7eQQFXRRDKLyLVBv9M8DWrxhgYL7gc6V4FuE5xkfpGyVRgvQNwyns"
    
//    static let channelNamespace = "urn:x-cast:com.cast.play.channel"//urn:x-cast:com.big.screen.channel"
//    static let kCustomReceiverAppID = "43E72089"//C7821FB5"//"B6208013"
    
    static let channelNamespace = "urn:x-cast:com.big.screen.channel"
    static let kCustomReceiverAppID = "B6208013"
    
//    static let channelNamespace = "urn:x-cast:com.big.screen.channel"
//    static let kCustomReceiverAppID = "B6208013"
     
}
