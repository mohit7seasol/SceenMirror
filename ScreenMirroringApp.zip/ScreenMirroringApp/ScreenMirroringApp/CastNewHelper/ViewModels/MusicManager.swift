//
//  MusicManager.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 17/12/25.
//


import MediaPlayer
import Combine

class MusicManager: ObservableObject {
    @Published var tracks: [MPMediaItem] = []
    @Published var isLoading: Bool = false

    func fetchMusic() {
        isLoading = true
        
        MPMediaLibrary.requestAuthorization { status in
            guard status == .authorized else {
                DispatchQueue.main.async {
                    self.isLoading = false
                }
                return
            }
            
            let mediaQuery = MPMediaQuery.songs()
            let items = mediaQuery.items ?? []
            
            DispatchQueue.main.async {
                self.tracks = items
                self.isLoading = false
            }
        }
    }
}
