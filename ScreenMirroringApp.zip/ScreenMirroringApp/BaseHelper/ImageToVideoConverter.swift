//
//  ImageToVideoConverter.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 01/01/26.
//

import Foundation
import UIKit
import AVFoundation
import Photos

class ImageToVideoConverter {
    
    static func convertImageToVideo(imageURL: URL, completion: @escaping (Result<URL, Error>) -> Void) {
        
        // Create output URL in documents directory
        let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let outputURL = documentsPath.appendingPathComponent("converted_video_\(UUID().uuidString).mp4")
        
        // Remove file if it already exists
        if FileManager.default.fileExists(atPath: outputURL.path) {
            try? FileManager.default.removeItem(at: outputURL)
        }
        
        // Load image
        guard let image = UIImage(contentsOfFile: imageURL.path) else {
            completion(.failure(VideoConversionError.imageLoadFailed))
            return
        }
        
        // Video settings
        let videoSize = CGSize(width: 1080, height: 1920) // Portrait orientation
        let fps: Int32 = 30
        let videoDuration: Double = 10  // 5 seconds
        
        // Create AVAssetWriter
        guard let assetWriter = try? AVAssetWriter(outputURL: outputURL, fileType: .mp4) else {
            completion(.failure(VideoConversionError.assetWriterCreationFailed))
            return
        }
        
        // Video input settings
        let videoSettings: [String: Any] = [
            AVVideoCodecKey: AVVideoCodecType.h264,
            AVVideoWidthKey: videoSize.width,
            AVVideoHeightKey: videoSize.height,
            AVVideoCompressionPropertiesKey: [
                AVVideoAverageBitRateKey: 6000000,
                AVVideoProfileLevelKey: AVVideoProfileLevelH264HighAutoLevel
            ]
        ]
        
        // Create video input
        let assetWriterInput = AVAssetWriterInput(mediaType: .video, outputSettings: videoSettings)
        assetWriterInput.expectsMediaDataInRealTime = false
        
        // Create pixel buffer adaptor
        let pixelBufferAttributes: [String: Any] = [
            kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_32ARGB,
            kCVPixelBufferWidthKey as String: videoSize.width,
            kCVPixelBufferHeightKey as String: videoSize.height
        ]
        
        let pixelBufferAdaptor = AVAssetWriterInputPixelBufferAdaptor(
            assetWriterInput: assetWriterInput,
            sourcePixelBufferAttributes: pixelBufferAttributes
        )
        
        // Add input to writer
        if assetWriter.canAdd(assetWriterInput) {
            assetWriter.add(assetWriterInput)
        } else {
            completion(.failure(VideoConversionError.cannotAddInput))
            return
        }
        
        // Start writing
        assetWriter.startWriting()
        assetWriter.startSession(atSourceTime: .zero)
        
        // Create frames
        let frameDuration = CMTime(value: 1, timescale: CMTimeScale(fps))
        let totalFrames = Int(videoDuration * Double(fps))
        
        var frameCount = 0
        
        assetWriterInput.requestMediaDataWhenReady(on: DispatchQueue.global(qos: .userInitiated)) {
            while assetWriterInput.isReadyForMoreMediaData && frameCount < totalFrames {
                
                let presentationTime = CMTime(value: CMTimeValue(frameCount), timescale: CMTimeScale(fps))
                
                if let pixelBuffer = self.createPixelBuffer(from: image, size: videoSize, pixelBufferPool: pixelBufferAdaptor.pixelBufferPool) {
                    
                    if !pixelBufferAdaptor.append(pixelBuffer, withPresentationTime: presentationTime) {
                        print("Failed to append pixel buffer at frame \(frameCount)")
                        break
                    }
                    
                    frameCount += 1
                } else {
                    print("Failed to create pixel buffer at frame \(frameCount)")
                    break
                }
            }
            
            // Finish writing
            assetWriterInput.markAsFinished()
            assetWriter.finishWriting {
                DispatchQueue.main.async {
                    if assetWriter.status == .completed {
                        completion(.success(outputURL))
                    } else {
                        completion(.failure(assetWriter.error ?? VideoConversionError.unknown))
                    }
                }
            }
        }
    }
    
    static func saveImageToTemp(image: UIImage) -> URL {
        let tempDirectory = FileManager.default.temporaryDirectory
        let tempURL = tempDirectory.appendingPathComponent("\(UUID().uuidString).jpg")
        
        if let imageData = image.jpegData(compressionQuality: 0.8) {
            try? imageData.write(to: tempURL)
        }
        
        return tempURL
    }
    
    private static func createPixelBuffer(from image: UIImage, size: CGSize, pixelBufferPool: CVPixelBufferPool?) -> CVPixelBuffer? {
        
        var pixelBuffer: CVPixelBuffer?
        
        let options: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true
        ]
        
        let status = CVPixelBufferCreate(
            kCFAllocatorDefault,
            Int(size.width),
            Int(size.height),
            kCVPixelFormatType_32ARGB,
            options as CFDictionary,
            &pixelBuffer
        )
        
        guard status == kCVReturnSuccess, let buffer = pixelBuffer else {
            return nil
        }
        
        CVPixelBufferLockBaseAddress(buffer, [])
        
        let context = CGContext(
            data: CVPixelBufferGetBaseAddress(buffer),
            width: Int(size.width),
            height: Int(size.height),
            bitsPerComponent: 8,
            bytesPerRow: CVPixelBufferGetBytesPerRow(buffer),
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue
        )
        
        guard let cgContext = context else {
            CVPixelBufferUnlockBaseAddress(buffer, [])
            return nil
        }
        
        // Clear the buffer
        cgContext.clear(CGRect(origin: .zero, size: size))
        
        // Draw image centered and scaled to fit
        let imageSize = image.size
        let scaleX = size.width / imageSize.width
        let scaleY = size.height / imageSize.height
        let scale = min(scaleX, scaleY)
        
        let scaledSize = CGSize(width: imageSize.width * scale, height: imageSize.height * scale)
        let drawRect = CGRect(
            x: (size.width - scaledSize.width) / 2,
            y: (size.height - scaledSize.height) / 2,
            width: scaledSize.width,
            height: scaledSize.height
        )
        
        if let cgImage = image.cgImage {
            cgContext.draw(cgImage, in: drawRect)
        }
        
        CVPixelBufferUnlockBaseAddress(buffer, [])
        
        return buffer
    }
}

// Error enum
enum VideoConversionError: Error {
    case imageLoadFailed
    case assetWriterCreationFailed
    case cannotAddInput
    case unknown
    
    var localizedDescription: String {
        switch self {
        case .imageLoadFailed:
            return "Failed to load image"
        case .assetWriterCreationFailed:
            return "Failed to create asset writer"
        case .cannotAddInput:
            return "Cannot add input to asset writer"
        case .unknown:
            return "Unknown error occurred"
        }
    }
}

