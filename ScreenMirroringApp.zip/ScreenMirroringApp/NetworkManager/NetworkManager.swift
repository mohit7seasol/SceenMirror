//
//  NetworkManager.swift
//  DramaBox
//
//  Created by DREAMWORLD on 05/12/25.
//

import Foundation
import Alamofire
import UIKit

class NetworkManager {
    static let shared = NetworkManager()
    private init() {}
    
    private let baseProxyURL = "https://api-livevideocall.7seasol.in/proxy?url="
    
    // MARK: - Helper
    private func makeURL(for endpoint: String) -> String {
        return "\(baseProxyURL)\(endpoint.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? "")"
    }
    
    // MARK: - Fetch Remote Config (grfg.json)
    func fetchRemoteConfig(from vc: UIViewController,
                           completion: @escaping (Result<[String: Any], Error>) -> Void) {
        guard ReachabilityManager.shared.isConnectedToNetwork() else {
            ReachabilityManager.shared.showNoInternetAlert(on: vc)
            return
        }
        
        let urlString = getJSON
        
        AF.request(urlString, method: .get)
            .validate()
            .responseJSON { response in
                switch response.result {
                case .success(let value):
                    if let json = value as? [String: Any] {
                        completion(.success(json))
                    } else {
                        completion(.failure(NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid JSON format."])))
                    }
                case .failure(let error):
                    completion(.failure(error))
                }
            }
    }
}
