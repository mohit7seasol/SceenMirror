//
//  Common.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 16/12/25.
//

import Foundation
import UIKit

class HelperManager {
    static func setupInitialLanguage() {
            // Ensure language is set from saved preference
            if let savedLanguage = UserDefaults.standard.string(forKey: "language"),
               let language = Language(rawValue: savedLanguage) {
                LocalizationService.shared.language = language
            } else if let savedChooseLanguage = UserDefaults.standard.string(forKey: UserDefaultKeys.selectedLanguage),
                      let chooseLanguage = SelectLanguage(rawValue: savedChooseLanguage) {
                // Fallback to your custom storage
                LocalizationService.shared.language = chooseLanguage.languageCode
            }
            // If neither exists, it will use the default from LocalizationService
  }
}
