//
//  ConnectFile.swift
//  TVCastNative
//
//  Created by 7 Seasol3 on 18/08/25.
//

import Foundation
import UIKit

var commonViewModel : CommonViewModel!

var APP_NAME = "Screen Mirroring"

let SELECTED_TV = "SELECTED_TV"

func setSelectedTV(name:String){
    UserDefaults().set(encodable: name, forKey: SELECTED_TV)
    UserDefaults().synchronize()
}

func getSelectedTV() -> String{
    if let count = UserDefaults().get(String.self, forKey: SELECTED_TV){
        return count
    }else{
        return ""
    }
   
}

func resizeImage(_ image: UIImage, maxWidth: CGFloat) -> UIImage {
    let scale = maxWidth / image.size.width
    let newSize = CGSize(width: maxWidth, height: image.size.height * scale)
    UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
    image.draw(in: CGRect(origin: .zero, size: newSize))
    let resizedImage = UIGraphicsGetImageFromCurrentImageContext()
    UIGraphicsEndImageContext()
    return resizedImage ?? image
}

func getWiFiAddress() -> String? {
    var address : String?
    var ifaddr : UnsafeMutablePointer<ifaddrs>? = nil
    if getifaddrs(&ifaddr) == 0 {
        var ptr = ifaddr
        while ptr != nil {
            defer { ptr = ptr?.pointee.ifa_next }

            let interface = ptr!.pointee
            let addrFamily = interface.ifa_addr.pointee.sa_family
            if addrFamily == UInt8(AF_INET) {
                let name = String(cString: interface.ifa_name)
                if name == "en0" {
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    getnameinfo(interface.ifa_addr, socklen_t(interface.ifa_addr.pointee.sa_len),
                                &hostname, socklen_t(hostname.count),
                                nil, socklen_t(0), NI_NUMERICHOST)
                    address = String(cString: hostname)
                    break
                }
            }
        }
        freeifaddrs(ifaddr)
    }
//    return "192.168.1.56"
    return address
}
