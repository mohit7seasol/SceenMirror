//
//  Searchbar.swift
//  DramaBox
//
//  Created by DREAMWORLD on 05/12/25.
//

import UIKit

struct SearchBarStyle {

    static func apply(
        to searchBar: UISearchBar,
        placeholder: String = "Search here..."
    ) {
        let textField = searchBar.searchTextField

        // ✅ Placeholder
        textField.placeholder = placeholder
        textField.textColor = .white

        // ✅ Remove default background
        searchBar.backgroundImage = UIImage()

        // ✅ Force Custom Left Icon (FIXED)
        let leftIconView = UIImageView(image: UIImage(named: "search_ic"))
        leftIconView.contentMode = .scaleAspectFit
        leftIconView.tintColor = .white
        leftIconView.frame = CGRect(x: 0, y: 0, width: 20, height: 20)

        let leftContainer = UIView(frame: CGRect(x: 0, y: 0, width: 34, height: 24))
        leftIconView.center = leftContainer.center
        leftContainer.addSubview(leftIconView)

        textField.leftView = leftContainer
        textField.leftViewMode = .always

        // ✅ Apply after autolayout
        DispatchQueue.main.async {

            // Corner radius (Height / 2)
            textField.layer.cornerRadius = textField.frame.height / 2
            textField.layer.masksToBounds = true

            // ✅ Gradient Background
            let gradient = CAGradientLayer()
            gradient.colors = [
                UIColor(named: "#242424")!.cgColor,
                UIColor(named: "#252525")!.cgColor
            ]
            gradient.startPoint = CGPoint(x: 0, y: 0)
            gradient.endPoint   = CGPoint(x: 1, y: 1)
            gradient.frame = textField.bounds
            gradient.cornerRadius = textField.frame.height / 2

            // Remove old gradients
            textField.layer.sublayers?.removeAll(where: { $0 is CAGradientLayer })
            textField.layer.insertSublayer(gradient, at: 0)
        }
    }
}

class ClearButtonTextField: UITextField {
    var clearButtonTintColor: UIColor = .white
    var clearButtonSize: CGSize = CGSize(width: 20, height: 20)
    var clearButtonPadding: CGFloat = 8.0
    
    private lazy var clearButton: UIButton = {
        let button = UIButton(type: .custom)
        let image = UIImage(systemName: "xmark.circle.fill") ?? UIImage()
        button.setImage(image, for: .normal)
        button.tintColor = clearButtonTintColor
        button.frame = CGRect(origin: .zero, size: clearButtonSize)
        button.addTarget(self, action: #selector(clearButtonTapped), for: .touchUpInside)
        button.isHidden = true
        button.alpha = 0.7
        return button
    }()
    
    @objc private func clearButtonTapped() {
        self.text = ""
        self.sendActions(for: .editingChanged)
        updateClearButtonVisibility()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupClearButton()
        setupCursorColor()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupClearButton()
        setupCursorColor()
    }
    
    private func setupClearButton() {
        self.addTarget(self, action: #selector(editingChanged), for: .editingChanged)
        
        let clearContainer = UIView(frame: CGRect(
            x: 0,
            y: 0,
            width: clearButtonSize.width + clearButtonPadding * 2,
            height: clearButtonSize.height
        ))
        clearButton.center = clearContainer.center
        clearContainer.addSubview(clearButton)
        
        self.rightView = clearContainer
        self.rightViewMode = .whileEditing
    }
    
    private func setupCursorColor() {
        // ✅ Set cursor color to white
        self.tintColor = .white
    }
    
    @objc private func editingChanged() {
        updateClearButtonVisibility()
    }
    
    private func updateClearButtonVisibility() {
        let hasText = !(self.text?.isEmpty ?? true)
        clearButton.isHidden = !hasText
    }
    
    func showClearButton() {
        clearButton.isHidden = false
    }
    
    func hideClearButton() {
        clearButton.isHidden = true
    }
}

struct SearchTextFieldStyle {

    static func apply(
        to textField: UITextField,
        placeholder: String = "Search here...",
        placeholderColor: UIColor = UIColor.white.withAlphaComponent(0.7),
        textColor: UIColor = .white,
        leftIcon: UIImage? = UIImage(named: "search_ic"),
        leftIconTintColor: UIColor = .white,
        leftIconSize: CGSize = CGSize(width: 20, height: 20),
        leftIconContainerSize: CGSize = CGSize(width: 34, height: 24),
        leftPadding: CGFloat = 10.0,
        rightPadding: CGFloat = 10.0,
        height: CGFloat = 45.0,
        cornerRadius: CGFloat = 24.0,
        backgroundColor: UIColor = .clear,
        showClearButton: Bool = true,
        clearButtonTintColor: UIColor = .white,
        clearButtonSize: CGSize = CGSize(width: 20, height: 20),
        clearButtonPadding: CGFloat = 8.0
    ) {
        
        // ✅ Set cursor color to white
        textField.tintColor = .white
        
        // ✅ Convert to ClearButtonTextField if needed
        if showClearButton && !(textField is ClearButtonTextField) {
            // We'll handle clear button separately since we can't change the class
            setupClearButtonForTextField(
                textField: textField,
                tintColor: clearButtonTintColor,
                size: clearButtonSize,
                padding: clearButtonPadding
            )
        }
        
        // ✅ Apply height constraint
        textField.translatesAutoresizingMaskIntoConstraints = false
        textField.heightAnchor.constraint(equalToConstant: height).isActive = true
        
        // ✅ Placeholder
        textField.placeholder = placeholder
        textField.textColor = textColor
        
        // ✅ Custom placeholder color
        textField.attributedPlaceholder = NSAttributedString(
            string: placeholder,
            attributes: [NSAttributedString.Key.foregroundColor: placeholderColor]
        )
        
        // ✅ Background color
        textField.backgroundColor = backgroundColor
        
        // ✅ Left Icon with padding
        if let leftIcon = leftIcon {
            let leftIconView = UIImageView(image: leftIcon)
            leftIconView.contentMode = .scaleAspectFit
            leftIconView.tintColor = leftIconTintColor
            leftIconView.frame = CGRect(origin: .zero, size: leftIconSize)
            
            // ✅ Apply left padding to container
            let leftContainer = UIView(frame: CGRect(
                x: 0,
                y: 0,
                width: leftIconContainerSize.width + leftPadding,
                height: height
            ))
            leftIconView.center = CGPoint(
                x: leftContainer.bounds.midX + leftPadding/2,
                y: leftContainer.bounds.midY
            )
            leftContainer.addSubview(leftIconView)
            
            textField.leftView = leftContainer
            textField.leftViewMode = .always
        } else {
            // Fallback to system search icon
            let leftIconView = UIImageView(image: UIImage(systemName: "magnifyingglass"))
            leftIconView.contentMode = .scaleAspectFit
            leftIconView.tintColor = leftIconTintColor
            leftIconView.frame = CGRect(origin: .zero, size: leftIconSize)
            
            let leftContainer = UIView(frame: CGRect(
                x: 0,
                y: 0,
                width: leftIconContainerSize.width + leftPadding,
                height: height
            ))
            leftIconView.center = CGPoint(
                x: leftContainer.bounds.midX + leftPadding/2,
                y: leftContainer.bounds.midY
            )
            leftContainer.addSubview(leftIconView)
            
            textField.leftView = leftContainer
            textField.leftViewMode = .always
        }
        
        // ✅ Apply gradient styling after autolayout
        DispatchQueue.main.async {
            applyGradientStyle(
                to: textField,
                height: height,
                cornerRadius: cornerRadius
            )
        }
        
        // ✅ Add observer for text changes to show/hide clear button
        if showClearButton {
            NotificationCenter.default.addObserver(
                forName: UITextField.textDidChangeNotification,
                object: textField,
                queue: .main
            ) { _ in
                updateClearButtonForTextField(textField)
            }
        }
    }
    
    private static func setupClearButtonForTextField(
        textField: UITextField,
        tintColor: UIColor,
        size: CGSize,
        padding: CGFloat
    ) {
        let clearButton = UIButton(type: .custom)
        let image = UIImage(systemName: "xmark.circle.fill") ?? UIImage()
        clearButton.setImage(image, for: .normal)
        clearButton.tintColor = tintColor
        clearButton.frame = CGRect(origin: .zero, size: size)
        
        // FIXED: Create a separate handler for the button action
        let clearButtonHandler = ClearButtonHandler(textField: textField)
        clearButton.addTarget(clearButtonHandler, action: #selector(ClearButtonHandler.clearButtonTapped), for: .touchUpInside)
        
        clearButton.isHidden = true
        clearButton.alpha = 0.7
        
        let clearContainer = UIView(frame: CGRect(
            x: 0,
            y: 0,
            width: size.width + padding * 2,
            height: size.height
        ))
        clearButton.center = clearContainer.center
        clearContainer.addSubview(clearButton)
        
        // Store the clear button and handler as associated objects
        objc_setAssociatedObject(
            textField,
            &AssociatedKeys.clearButton,
            clearButton,
            .OBJC_ASSOCIATION_RETAIN_NONATOMIC
        )
        
        objc_setAssociatedObject(
            textField,
            &AssociatedKeys.clearButtonHandler,
            clearButtonHandler,
            .OBJC_ASSOCIATION_RETAIN_NONATOMIC
        )
        
        textField.rightView = clearContainer
        textField.rightViewMode = .whileEditing
    }
    
    private static func updateClearButtonForTextField(_ textField: UITextField) {
        if let clearButton = objc_getAssociatedObject(
            textField,
            &AssociatedKeys.clearButton
        ) as? UIButton {
            let hasText = !(textField.text?.isEmpty ?? true)
            clearButton.isHidden = !hasText
        }
    }
    
    private static func applyGradientStyle(
        to textField: UITextField,
        height: CGFloat,
        cornerRadius: CGFloat
    ) {
        // Ensure the text field has a valid frame
        guard textField.bounds.width > 0 else {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
                applyGradientStyle(to: textField, height: height, cornerRadius: cornerRadius)
            }
            return
        }
        
        // ✅ Corner radius
        textField.layer.cornerRadius = cornerRadius
        textField.layer.masksToBounds = true
        
        // ✅ Remove old gradient layers first
        textField.layer.sublayers?.removeAll(where: { $0 is CAGradientLayer })
        
        // ✅ 1. Gradient Background (White 30% → 15% opacity) - Left to Right
        let backgroundGradient = CAGradientLayer()
        backgroundGradient.colors = [
            UIColor.white.withAlphaComponent(0.3).cgColor,
            UIColor.white.withAlphaComponent(0.15).cgColor
        ]
        backgroundGradient.startPoint = CGPoint(x: 0, y: 0.5)
        backgroundGradient.endPoint = CGPoint(x: 1, y: 0.5)
        backgroundGradient.frame = textField.bounds
        backgroundGradient.cornerRadius = cornerRadius
        
        // ✅ 2. Gradient Border
        let borderLayer = CAShapeLayer()
        borderLayer.path = UIBezierPath(
            roundedRect: textField.bounds.insetBy(dx: 0.5, dy: 0.5),
            cornerRadius: cornerRadius
        ).cgPath
        borderLayer.fillColor = UIColor.clear.cgColor
        borderLayer.strokeColor = UIColor.white.cgColor
        borderLayer.lineWidth = 1.0
        
        // ✅ Create gradient for border
        let borderGradient = CAGradientLayer()
        borderGradient.frame = textField.bounds
        borderGradient.colors = [
            UIColor.white.withAlphaComponent(0.7).cgColor,
            UIColor.white.withAlphaComponent(0.2).cgColor
        ]
        borderGradient.startPoint = CGPoint(x: 0, y: 0.5)
        borderGradient.endPoint = CGPoint(x: 1, y: 0.5)
        borderGradient.mask = borderLayer
        
        // Add layers
        textField.layer.insertSublayer(backgroundGradient, at: 0)
        textField.layer.insertSublayer(borderGradient, above: backgroundGradient)
        
        // Ensure background is clear
        textField.backgroundColor = .clear
    }
    
    struct AssociatedKeys {
        static var clearButton = "clearButton"
        static var clearButtonHandler = "clearButtonHandler"
    }
}

// MARK: - Handler class for Objective-C compatibility
class ClearButtonHandler: NSObject {
    weak var textField: UITextField?
    
    init(textField: UITextField) {
        self.textField = textField
        super.init()
    }
    
    @objc func clearButtonTapped() {
        textField?.text = ""
        textField?.sendActions(for: .editingChanged)
        updateClearButtonVisibility()
    }
    
    private func updateClearButtonVisibility() {
        if let clearButton = objc_getAssociatedObject(
            textField as Any,
            &SearchTextFieldStyle.AssociatedKeys.clearButton
        ) as? UIButton {
            let hasText = !(textField?.text?.isEmpty ?? true)
            clearButton.isHidden = !hasText
        }
    }
}

// MARK: - Helper extension for UIView
extension UIView {
    func findSubview<T: UIView>(ofType type: T.Type) -> T? {
        for subview in subviews {
            if let typedSubview = subview as? T {
                return typedSubview
            }
            if let found = subview.findSubview(ofType: type) {
                return found
            }
        }
        return nil
    }
}
