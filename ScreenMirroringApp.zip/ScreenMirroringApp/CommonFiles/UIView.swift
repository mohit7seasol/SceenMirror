import Foundation
import UIKit

@IBDesignable
class CustomView: UIView {
    
    @IBInspectable var cornerRadius: CGFloat = 0 {
        didSet {
            layer.cornerRadius = cornerRadius
            gradientLayer.cornerRadius = cornerRadius
            dashedBorderLayer.cornerRadius = cornerRadius
        }
    }
    
    // MARK: - Gradient Border
    @IBInspectable var borderStartColor: UIColor = .clear {
        didSet { updateBorderGradientColors() }
    }
    
    @IBInspectable var borderEndColor: UIColor = .clear {
        didSet { updateBorderGradientColors() }
    }
    
    @IBInspectable var borderIsVertical: Bool = false {
        didSet { updateBorderGradientDirection() }
    }
    
    @IBInspectable var borderWidth: CGFloat = 0 {
        didSet {
            layer.borderWidth = borderWidth
        }
    }
    
    @IBInspectable var shadowColor: UIColor = .black {
        didSet {
            layer.shadowColor = shadowColor.cgColor
        }
    }
    
    @IBInspectable var shadowOpacity: Float = 0.5 {
        didSet {
            layer.shadowOpacity = shadowOpacity
        }
    }
    
    @IBInspectable var shadowOffset: CGSize = CGSize(width: 0, height: 2) {
        didSet {
            layer.shadowOffset = shadowOffset
        }
    }
    
    @IBInspectable var shadowRadius: CGFloat = 4 {
        didSet {
            layer.shadowRadius = shadowRadius
        }
    }
    
    // Gradient Colors
    @IBInspectable var startColor: UIColor = .clear {
        didSet {
            updateGradientColors()
        }
    }
    
    @IBInspectable var endColor: UIColor = .clear {
        didSet {
            updateGradientColors()
        }
    }
    
    // Gradient direction: 0 = horizontal, 1 = vertical
    @IBInspectable var isVertical: Bool = false {
        didSet {
            updateGradientDirection()
        }
    }
    
    @IBInspectable var backgroundOpacity: CGFloat = 1.0 {
        didSet { updateGradientColors() }
    }
    
    // Dashed Border Properties
    @IBInspectable var dashBorderColor: UIColor = .clear {
        didSet {
            updateDashBorder()
        }
    }
    
    @IBInspectable var dashBorderWidth: CGFloat = 1 {
        didSet {
            updateDashBorder()
        }
    }
    
    @IBInspectable var dashPattern: [NSNumber] = [6, 3] { // Dash length and gap
        didSet {
            updateDashBorder()
        }
    }
    
    private let gradientLayer = CAGradientLayer()
    private let dashedBorderLayer = CAShapeLayer()
    private let borderGradientLayer = CAGradientLayer()
    private let borderShapeLayer = CAShapeLayer()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupView()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupView()
    }
    
    private func setupView() {
        layer.masksToBounds = false
        
        // Background gradient
        gradientLayer.cornerRadius = cornerRadius
        layer.insertSublayer(gradientLayer, at: 0)
        updateGradientColors()
        updateGradientDirection()
        
        // Gradient border setup
        borderShapeLayer.lineWidth = borderWidth
        borderShapeLayer.fillColor = UIColor.clear.cgColor
        borderShapeLayer.strokeColor = UIColor.white.cgColor // dummy color, mask ignores this anyway
        borderGradientLayer.mask = borderShapeLayer
        layer.addSublayer(borderGradientLayer)
        updateBorderGradientColors()
        updateBorderGradientDirection()
        updateBorderPath()

        
        // Dashed border (if used)
        dashedBorderLayer.strokeColor = dashBorderColor.cgColor
        dashedBorderLayer.fillColor = nil
        dashedBorderLayer.lineDashPattern = dashPattern
        dashedBorderLayer.lineWidth = dashBorderWidth
        dashedBorderLayer.frame = bounds
        layer.addSublayer(dashedBorderLayer)
    }
    
    private func updateGradientColors() {
        gradientLayer.colors = [
            startColor.withAlphaComponent(backgroundOpacity).cgColor,
            endColor.withAlphaComponent(backgroundOpacity).cgColor
        ]
    }
    
    private func updateGradientDirection() {
        if isVertical {
            // Vertical gradient
            gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
            gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        } else {
            // Horizontal gradient
            gradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
            gradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
        }
    }
    
    private func updateDashBorder() {
        let dashPath = UIBezierPath(roundedRect: bounds, cornerRadius: cornerRadius)
        dashedBorderLayer.path = dashPath.cgPath
        dashedBorderLayer.strokeColor = dashBorderColor.cgColor
        dashedBorderLayer.lineDashPattern = dashPattern
        dashedBorderLayer.lineWidth = dashBorderWidth
        dashedBorderLayer.frame = bounds
    }
    
    // MARK: - Layout
    override func layoutSubviews() {
        super.layoutSubviews()
        gradientLayer.frame = bounds
        borderGradientLayer.frame = bounds
        updateBorderPath()
        updateDashBorder()
    }

    
    override func prepareForInterfaceBuilder() {
        super.prepareForInterfaceBuilder()
        setupView()
    }
    
    private func updateBorder() {
        borderShapeLayer.lineWidth = borderWidth
        updateBorderPath()
    }
    
    private func updateBorderPath() {
        let borderRect = bounds.insetBy(dx: borderWidth / 2, dy: borderWidth / 2)
        let path = UIBezierPath(roundedRect: borderRect, cornerRadius: cornerRadius)
        borderShapeLayer.path = path.cgPath
    }
    
    private func updateBorderGradientColors() {
        borderGradientLayer.colors = [borderStartColor.cgColor, borderEndColor.cgColor]
    }
    
    private func updateBorderGradientDirection() {
        if borderIsVertical {
            borderGradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
            borderGradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        } else {
            borderGradientLayer.startPoint = CGPoint(x: 0, y: 0.5)
            borderGradientLayer.endPoint = CGPoint(x: 1, y: 0.5)
        }
    }
    
}
