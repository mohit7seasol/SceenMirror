//
//  SwipeGestureCommonView.swift
//  ScreenMirroringApp
//
//  Created by DREAMWORLD on 09/01/26.
//

import Foundation
import UIKit

// MARK: - Protocol for Swipe Completion
protocol SwipeGestureHelperDelegate: AnyObject {
    func swipeCompleted()
    func swipeCancelled()
}

// MARK: - Animation Types
enum ResetAnimationType {
    case bounce
    case spring
    case smooth
    case elastic
    case fade
    case custom(duration: TimeInterval, damping: CGFloat, velocity: CGFloat)
}

// MARK: - Main Swipe Helper Class
class SwipeGestureHelper: NSObject {
    
    // MARK: - Properties
    weak var delegate: SwipeGestureHelperDelegate?
    
    private var swipeCircleView: UIView!
    private var swipeParentView: UIView!
    private var swipeCircleViewOriginalCenter: CGPoint!
    private var panGesture: UIPanGestureRecognizer!
    private var hintAnimationTimer: Timer?
    private var rotationAnimation: CABasicAnimation?
    private var pulseAnimation: CABasicAnimation?
    private var isSwiped = false
    private var hasReachedRightThreshold = false
    private var lastSwipeDirection: CGFloat = 0
    private var isResetting = false
    
    // MARK: - UI Configuration
    private var iconImageView: UIImageView?
    private var gradientLayer: CAGradientLayer?
    private var glowLayer: CALayer?
    
    // MARK: - Customization Properties (can be set before setup)
    var swipeCircleColor1: UIColor = UIColor(red: 0.95, green: 0.95, blue: 1, alpha: 1)
    var swipeCircleColor2: UIColor = UIColor(red: 0.85, green: 0.85, blue: 1, alpha: 1)
    var swipeParentCornerRadius: CGFloat = 30
    var swipeThresholdPercentage: CGFloat = 0.7 // 70% to complete
    var hintAnimationInterval: TimeInterval = 5.0
    var iconImage: UIImage? = nil // Set custom icon if needed
    
    // MARK: - Setup Methods
    func setupSwipeGesture(
        swipeCircleView: UIView,
        swipeParentView: UIView,
        delegate: SwipeGestureHelperDelegate
    ) {
        self.swipeCircleView = swipeCircleView
        self.swipeParentView = swipeParentView
        self.delegate = delegate
        
        configureParentView()
        configureSwipeCircleView()
        setupGestureRecognizer()
        setupIconImageView()
        
        // Save original position
        swipeCircleViewOriginalCenter = swipeCircleView.center
    }
    
    // MARK: - UI Configuration
    private func configureParentView() {
        swipeParentView.layer.cornerRadius = swipeParentCornerRadius
        swipeParentView.layer.masksToBounds = false
        
        // Add shadow
        swipeParentView.layer.shadowColor = UIColor(red: 0.29, green: 0.56, blue: 1, alpha: 0.15).cgColor
        swipeParentView.layer.shadowOffset = CGSize(width: 0, height: 8)
        swipeParentView.layer.shadowOpacity = 0.3
        swipeParentView.layer.shadowRadius = 15
    }
    
    private func configureSwipeCircleView() {
        swipeCircleView.layer.cornerRadius = swipeCircleView.frame.height / 2
        swipeCircleView.clipsToBounds = true
        
        // Add gradient
        gradientLayer = CAGradientLayer()
        gradientLayer?.frame = swipeCircleView.bounds
        gradientLayer?.colors = [swipeCircleColor1.cgColor, swipeCircleColor2.cgColor]
        gradientLayer?.startPoint = CGPoint(x: 0, y: 0.5)
        gradientLayer?.endPoint = CGPoint(x: 1, y: 0.5)
        gradientLayer?.cornerRadius = swipeCircleView.frame.height / 2
        
        if let gradientLayer = gradientLayer {
            swipeCircleView.layer.insertSublayer(gradientLayer, at: 0)
        }
        
        // Add glow effect
        addGlowEffect()
        
        // Add inner shadow/glow
        swipeCircleView.layer.shadowColor = UIColor.white.cgColor
        swipeCircleView.layer.shadowOffset = CGSize(width: 0, height: 2)
        swipeCircleView.layer.shadowOpacity = 0.3
        swipeCircleView.layer.shadowRadius = 4
    }
    
    private func addGlowEffect() {
        glowLayer = CALayer()
        glowLayer?.frame = swipeCircleView.bounds
        glowLayer?.backgroundColor = UIColor(red: 0.29, green: 0.56, blue: 1, alpha: 0.2).cgColor
        glowLayer?.cornerRadius = swipeCircleView.frame.height / 2
        glowLayer?.opacity = 0.0
        
        if let glowLayer = glowLayer {
            swipeCircleView.layer.insertSublayer(glowLayer, at: 0)
        }
    }
    
    private func setupIconImageView() {
        let iconSize = min(swipeCircleView.bounds.width, swipeCircleView.bounds.height) * 0.6
        iconImageView = UIImageView(frame: CGRect(x: 0, y: 0, width: iconSize, height: iconSize))
        iconImageView?.center = CGPoint(x: swipeCircleView.bounds.width / 2, y: swipeCircleView.bounds.height / 2)
        iconImageView?.contentMode = .scaleAspectFit
        
        if let customImage = iconImage {
            iconImageView?.image = customImage
        }
        
        if let iconImageView = iconImageView {
            swipeCircleView.addSubview(iconImageView)
        }
    }
    
    private func setupGestureRecognizer() {
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(handlePanGesture(_:)))
        panGesture.delegate = self
        swipeCircleView.addGestureRecognizer(panGesture)
        swipeCircleView.isUserInteractionEnabled = true
        
        // Add double tap gesture for reset
        let doubleTap = UITapGestureRecognizer(target: self, action: #selector(handleDoubleTap(_:)))
        doubleTap.numberOfTapsRequired = 2
        swipeCircleView.addGestureRecognizer(doubleTap)
    }
    
    // MARK: - Layout Updates
    func updateLayout() {
        gradientLayer?.frame = swipeCircleView.bounds
        glowLayer?.frame = swipeCircleView.bounds
        iconImageView?.center = CGPoint(x: swipeCircleView.bounds.width / 2, y: swipeCircleView.bounds.height / 2)
    }
    
    // MARK: - Hint Animation
    func startHintAnimation() {
        stopHintAnimation()
        
        hintAnimationTimer = Timer.scheduledTimer(withTimeInterval: hintAnimationInterval, repeats: true) { [weak self] _ in
            self?.performHintAnimation()
        }
        
        performHintAnimation()
    }
    
    func stopHintAnimation() {
        hintAnimationTimer?.invalidate()
        hintAnimationTimer = nil
    }
    
    private func performHintAnimation() {
        guard let originalCenter = swipeCircleViewOriginalCenter else { return }
        
        let targetX = swipeParentView.frame.width - swipeCircleView.frame.width / 2 - 10
        let distance = targetX - originalCenter.x
        let hintDistance = distance * 0.1
        
        UIView.animate(withDuration: 0.5, delay: 0, options: [.curveEaseOut], animations: {
            self.swipeCircleView.center.x = originalCenter.x + hintDistance
            self.iconImageView?.transform = CGAffineTransform(rotationAngle: CGFloat.pi / 8)
        }) { _ in
            UIView.animate(withDuration: 0.8, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.5, options: [], animations: {
                self.swipeCircleView.center = originalCenter
                self.iconImageView?.transform = .identity
            })
        }
    }
    
    // MARK: - Gesture Handling
    @objc private func handlePanGesture(_ gesture: UIPanGestureRecognizer) {
        guard !isResetting else { return }
        
        let translation = gesture.translation(in: swipeParentView)
        let velocity = gesture.velocity(in: swipeParentView)
        
        // Track swipe direction
        if translation.x > 0 {
            lastSwipeDirection = 1 // Right
        } else if translation.x < 0 {
            lastSwipeDirection = -1 // Left
        }
        
        switch gesture.state {
        case .began:
            stopHintAnimation()
            hasReachedRightThreshold = false
            startPulseAnimation()
            
        case .changed:
            handlePanChanged(translation: translation, velocity: velocity)
            
        case .ended, .cancelled:
            stopPulseAnimation()
            handlePanEnded()
            
        default:
            break
        }
    }
    
    @objc private func handleDoubleTap(_ gesture: UITapGestureRecognizer) {
        performBeautifulReset()
    }
    
    private func handlePanChanged(translation: CGPoint, velocity: CGPoint) {
        let newX = swipeCircleViewOriginalCenter.x + translation.x
        let minX = swipeCircleView.frame.width / 2 + 10
        let maxX = swipeParentView.frame.width - swipeCircleView.frame.width / 2 - 10
        
        // Prevent left movement if already swiped right and trying to go back left
        if hasReachedRightThreshold && lastSwipeDirection < 0 {
            // Don't allow moving left after reaching threshold
            return
        }
        
        // Calculate bounds
        var boundedX = min(max(newX, minX), maxX)
        
        // If fast swipe to right, ensure it reaches at least threshold
        if velocity.x > 500 && !hasReachedRightThreshold {
            let thresholdX = minX + (maxX - minX) * swipeThresholdPercentage
            boundedX = max(boundedX, thresholdX)
        }
        
        swipeCircleView.center.x = boundedX
        
        // Rotate icon based on progress
        let progress = (boundedX - minX) / (maxX - minX)
        let rotationAngle = progress * .pi / 2
        iconImageView?.transform = CGAffineTransform(rotationAngle: rotationAngle)
        
        // Scale based on progress
        let scale = 1.0 + (progress * 0.1)
        swipeCircleView.transform = CGAffineTransform(scaleX: scale, y: scale)
        
        // Update glow opacity based on progress
        glowLayer?.opacity = Float(progress * 0.5)
        
        // Check threshold
        let threshold = swipeParentView.frame.width * swipeThresholdPercentage
        if !isSwiped && boundedX >= threshold {
            isSwiped = true
            hasReachedRightThreshold = true
            
            // Haptic feedback
            let feedbackGenerator = UIImpactFeedbackGenerator(style: .medium)
            feedbackGenerator.impactOccurred()
            
            // Success pulse animation
            performSuccessPulse()
        } else if isSwiped && boundedX < threshold {
            isSwiped = false
            hasReachedRightThreshold = false
        }
    }
    
    private func handlePanEnded() {
        let swipeThreshold = swipeParentView.frame.width * swipeThresholdPercentage
        
        if swipeCircleView.center.x >= swipeThreshold && lastSwipeDirection > 0 {
            animateToEndAndTriggerAction()
        } else {
            // Reset with beautiful animation if not completed
            performReturnAnimation()
            delegate?.swipeCancelled()
        }
        
        isSwiped = false
        hasReachedRightThreshold = false
    }
    
    // MARK: - Animation Methods
    private func animateToEndAndTriggerAction() {
        let endPosition = CGPoint(
            x: swipeParentView.frame.width - swipeCircleView.frame.width / 2 - 10,
            y: swipeCircleViewOriginalCenter.y
        )
        
        // Glow intensifies
        UIView.animate(withDuration: 0.3) {
            self.glowLayer?.opacity = 0.8
        }
        
        UIView.animate(withDuration: 0.4,
                       delay: 0,
                       usingSpringWithDamping: 0.7,
                       initialSpringVelocity: 0.8,
                       options: .curveEaseOut,
                       animations: {
            self.swipeCircleView.center = endPosition
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            self.iconImageView?.transform = CGAffineTransform(rotationAngle: .pi / 2)
        }) { _ in
            // Success animation sequence
            self.performSuccessAnimationSequence()
        }
    }
    
    private func performSuccessAnimationSequence() {
        // 1. First pulse
        UIView.animate(withDuration: 0.15, animations: {
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 1.15, y: 1.15)
            self.swipeCircleView.alpha = 0.9
        }) { _ in
            // 2. Second pulse
            UIView.animate(withDuration: 0.15, animations: {
                self.swipeCircleView.transform = CGAffineTransform(scaleX: 1.05, y: 1.05)
                self.swipeCircleView.alpha = 1
            }) { _ in
                // 3. Final settle
                UIView.animate(withDuration: 0.1) {
                    self.swipeCircleView.transform = .identity
                } completion: { _ in
                    self.startSpinAnimation()
                    self.delegate?.swipeCompleted()
                }
            }
        }
    }
    
    private func performReturnAnimation() {
        guard let originalCenter = swipeCircleViewOriginalCenter else { return }
        
        // Fade out glow
        UIView.animate(withDuration: 0.3) {
            self.glowLayer?.opacity = 0.0
        }
        
        UIView.animate(withDuration: 0.6,
                       delay: 0,
                       usingSpringWithDamping: 0.7,
                       initialSpringVelocity: 0.5,
                       options: .curveEaseOut,
                       animations: {
            self.swipeCircleView.center = originalCenter
            self.iconImageView?.transform = .identity
            self.swipeCircleView.transform = .identity
        }) { _ in
            // Restart hint animation after return
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.startHintAnimation()
            }
        }
    }
    
    // MARK: - Beautiful Reset Animations
    
    /// Perform a beautiful reset animation
    func performBeautifulReset(animationType: ResetAnimationType = .bounce) {
        guard !isResetting, let originalCenter = swipeCircleViewOriginalCenter else { return }
        
        isResetting = true
        stopSpinAnimation()
        stopHintAnimation()
        stopPulseAnimation()
        
        // Reset state
        isSwiped = false
        hasReachedRightThreshold = false
        lastSwipeDirection = 0
        
        // Haptic feedback
        let feedbackGenerator = UIImpactFeedbackGenerator(style: .light)
        feedbackGenerator.impactOccurred()
        
        switch animationType {
        case .bounce:
            performBounceReset(to: originalCenter)
        case .spring:
            performSpringReset(to: originalCenter)
        case .smooth:
            performSmoothReset(to: originalCenter)
        case .elastic:
            performElasticReset(to: originalCenter)
        case .fade:
            performFadeReset(to: originalCenter)
        case .custom(let duration, let damping, let velocity):
            performCustomReset(to: originalCenter, duration: duration, damping: damping, velocity: velocity)
        }
    }
    
    private func performBounceReset(to position: CGPoint) {
        // First, pull back slightly
        UIView.animate(withDuration: 0.2, animations: {
            self.swipeCircleView.center.x = position.x - 20
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 0.9, y: 0.9)
            self.iconImageView?.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / 8)
        }) { _ in
            // Then bounce to position with overshoot
            UIView.animate(withDuration: 0.8,
                           delay: 0,
                           usingSpringWithDamping: 0.5,
                           initialSpringVelocity: 0.8,
                           options: .curveEaseOut,
                           animations: {
                self.swipeCircleView.center = position
                self.swipeCircleView.transform = .identity
                self.iconImageView?.transform = .identity
                self.glowLayer?.opacity = 0.0
            }) { _ in
                self.isResetting = false
                self.startHintAnimation()
            }
        }
    }
    
    private func performSpringReset(to position: CGPoint) {
        // Add a glow pulse before reset
        let pulse = CABasicAnimation(keyPath: "opacity")
        pulse.fromValue = 0.5
        pulse.toValue = 0
        pulse.duration = 0.3
        glowLayer?.add(pulse, forKey: "resetPulse")
        
        UIView.animate(withDuration: 0.7,
                       delay: 0,
                       usingSpringWithDamping: 0.6,
                       initialSpringVelocity: 0.9,
                       options: .curveEaseOut,
                       animations: {
            self.swipeCircleView.center = position
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 0.95, y: 0.95)
            self.iconImageView?.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / 4)
            self.glowLayer?.opacity = 0.0
        }) { _ in
            // Final settle
            UIView.animate(withDuration: 0.2, animations: {
                self.swipeCircleView.transform = .identity
                self.iconImageView?.transform = .identity
            }) { _ in
                self.isResetting = false
                self.startHintAnimation()
            }
        }
    }
    
    private func performSmoothReset(to position: CGPoint) {
        let distance = abs(self.swipeCircleView.center.x - position.x)
        let duration = min(0.8, Double(distance / 200))
        
        UIView.animate(withDuration: duration,
                       delay: 0,
                       options: [.curveEaseInOut, .allowUserInteraction],
                       animations: {
            self.swipeCircleView.center = position
            self.swipeCircleView.transform = .identity
            self.iconImageView?.transform = .identity
            
            // Smooth rotation back
            let currentX = self.swipeCircleView.center.x
            let progress = 1.0 - (currentX - position.x) / (self.swipeParentView.frame.width - position.x)
            self.iconImageView?.transform = CGAffineTransform(rotationAngle: CGFloat.pi/2 * progress)
            
            self.glowLayer?.opacity = 0.0
        }) { _ in
            self.isResetting = false
            self.startHintAnimation()
        }
    }
    
    private func performElasticReset(to position: CGPoint) {
        // Simulate elastic effect with multiple bounces
        let animation = CAKeyframeAnimation(keyPath: "position.x")
        let currentX = swipeCircleView.center.x
        let delta = position.x - currentX
        
        // Create elastic keyframes
        let keyframes = [
            currentX + delta * 0.0,    // Start
            currentX + delta * 1.2,    // Overshoot
            currentX + delta * 0.9,    // Bounce back
            currentX + delta * 1.05,   // Small overshoot
            currentX + delta * 0.98,   // Settle
            currentX + delta * 1.0     // Final
        ]
        
        animation.values = keyframes
        animation.keyTimes = [0, 0.2, 0.4, 0.6, 0.8, 1.0]
        animation.duration = 0.8
        animation.timingFunction = CAMediaTimingFunction(name: .easeOut)
        
        // Also animate scale
        let scaleAnimation = CAKeyframeAnimation(keyPath: "transform.scale")
        scaleAnimation.values = [1.0, 1.1, 0.95, 1.02, 0.99, 1.0]
        scaleAnimation.keyTimes = [0, 0.2, 0.4, 0.6, 0.8, 1.0]
        scaleAnimation.duration = 0.8
        
        CATransaction.begin()
        CATransaction.setCompletionBlock {
            self.swipeCircleView.center = position
            self.swipeCircleView.transform = .identity
            self.iconImageView?.transform = .identity
            self.glowLayer?.opacity = 0.0
            self.isResetting = false
            self.startHintAnimation()
        }
        
        swipeCircleView.layer.add(animation, forKey: "elasticPosition")
        swipeCircleView.layer.add(scaleAnimation, forKey: "elasticScale")
        
        CATransaction.commit()
    }
    
    private func performFadeReset(to position: CGPoint) {
        // Fade out, move, then fade in
        UIView.animate(withDuration: 0.2, animations: {
            self.swipeCircleView.alpha = 0.3
            self.swipeCircleView.transform = CGAffineTransform(scaleX: 0.8, y: 0.8)
        }) { _ in
            // Move to position while faded
            self.swipeCircleView.center = position
            
            // Fade back in with scale
            UIView.animate(withDuration: 0.4,
                           delay: 0,
                           usingSpringWithDamping: 0.7,
                           initialSpringVelocity: 0.5,
                           options: .curveEaseOut,
                           animations: {
                self.swipeCircleView.alpha = 1.0
                self.swipeCircleView.transform = .identity
                self.iconImageView?.transform = .identity
                self.glowLayer?.opacity = 0.0
            }) { _ in
                self.isResetting = false
                self.startHintAnimation()
            }
        }
    }
    
    private func performCustomReset(to position: CGPoint, duration: TimeInterval, damping: CGFloat, velocity: CGFloat) {
        UIView.animate(withDuration: duration,
                       delay: 0,
                       usingSpringWithDamping: damping,
                       initialSpringVelocity: velocity,
                       options: .curveEaseOut,
                       animations: {
            self.swipeCircleView.center = position
            self.swipeCircleView.transform = .identity
            self.iconImageView?.transform = .identity
            self.glowLayer?.opacity = 0.0
        }) { _ in
            self.isResetting = false
            self.startHintAnimation()
        }
    }
    
    // MARK: - Helper Animations
    private func startPulseAnimation() {
        pulseAnimation = CABasicAnimation(keyPath: "transform.scale")
        pulseAnimation?.fromValue = 1.0
        pulseAnimation?.toValue = 1.05
        pulseAnimation?.duration = 0.5
        pulseAnimation?.autoreverses = true
        pulseAnimation?.repeatCount = .infinity
        pulseAnimation?.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        
        if let animation = pulseAnimation {
            swipeCircleView.layer.add(animation, forKey: "pulse")
        }
    }
    
    private func stopPulseAnimation() {
        swipeCircleView.layer.removeAnimation(forKey: "pulse")
    }
    
    private func performSuccessPulse() {
        let pulse = CABasicAnimation(keyPath: "transform.scale")
        pulse.fromValue = 1.0
        pulse.toValue = 1.2
        pulse.duration = 0.2
        pulse.autoreverses = true
        pulse.timingFunction = CAMediaTimingFunction(name: .easeOut)
        
        swipeCircleView.layer.add(pulse, forKey: "successPulse")
    }
    
    private func startSpinAnimation() {
        rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotationAnimation?.fromValue = 0
        rotationAnimation?.toValue = CGFloat.pi * 2
        rotationAnimation?.duration = 0.8
        rotationAnimation?.repeatCount = .infinity
        rotationAnimation?.isRemovedOnCompletion = false
        
        if let animation = rotationAnimation {
            iconImageView?.layer.add(animation, forKey: "spinAnimation")
        }
    }
    
    func stopSpinAnimation() {
        iconImageView?.layer.removeAnimation(forKey: "spinAnimation")
    }
    
    // MARK: - Public Methods
    
    /// Reset with beautiful animation (default bounce)
    func resetPosition() {
        performBeautifulReset(animationType: .bounce)
    }
    
    /// Reset immediately without animation
    func resetPositionImmediately() {
        guard let originalCenter = swipeCircleViewOriginalCenter else { return }
        
        stopSpinAnimation()
        stopHintAnimation()
        stopPulseAnimation()
        
        isSwiped = false
        hasReachedRightThreshold = false
        lastSwipeDirection = 0
        
        swipeCircleView.center = originalCenter
        swipeCircleView.transform = .identity
        iconImageView?.transform = .identity
        swipeCircleView.alpha = 1
        glowLayer?.opacity = 0.0
        
        startHintAnimation()
    }
    
    func resetSwipeCircle() {
        resetPositionImmediately()
    }
    
    func cleanup() {
        stopHintAnimation()
        stopSpinAnimation()
        stopPulseAnimation()
        swipeCircleView?.removeGestureRecognizer(panGesture)
    }
}

// MARK: - UIGestureRecognizerDelegate
extension SwipeGestureHelper: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return false
    }
    
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        return !isResetting
    }
}
