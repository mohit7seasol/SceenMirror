//
//  BottomSheet.swift
//  DramaBox
//
//  Created by DREAMWORLD on 09/12/25.
//

import UIKit

open class ActionSheetShowAnimation: NSObject, UIViewControllerAnimatedTransitioning {
    
    public var duration: TimeInterval = 0.8
    public var delay: TimeInterval = 0.0
    public var springWithDamping: CGFloat = 0.8
    public var springVelocity: CGFloat = 2.0
    public var blurEffect: UIBlurEffect?
    public var blurAlpha: CGFloat = 0.30
    
    // Liquid glass effect properties
    public var liquidGlassBlurRadius: CGFloat = 20.0
    public var liquidGlassSaturation: CGFloat = 1.8
    public var liquidGlassBrightness: CGFloat = 1.1
    
    private var blurView: UIVisualEffectView?
    
    open func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return duration
    }
    
    open func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        guard let toViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to),
              let toView = transitionContext.view(forKey: UITransitionContextViewKey.to)
        else {
            return
        }
        
        let containerView = transitionContext.containerView
        
        // Create liquid glass effect background
        let blurEffect = self.blurEffect ?? UIBlurEffect(style: .systemUltraThinMaterialDark)
        let blurView = UIVisualEffectView(effect: nil)
        blurView.frame = containerView.bounds
        blurView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        self.blurView = blurView
        
        // Add liquid glass overlay with multiple layers for depth
        let liquidGlassView = UIView(frame: blurView.bounds)
        liquidGlassView.backgroundColor = UIColor.clear
        liquidGlassView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        // Create a vibrant view for the liquid glass effect
        let vibrantView = UIView(frame: blurView.bounds)
        vibrantView.backgroundColor = UIColor.white.withAlphaComponent(0.08)
        vibrantView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        
        // Add gradient overlay for liquid effect
        let gradientLayer = CAGradientLayer()
        gradientLayer.frame = blurView.bounds
        gradientLayer.colors = [
            UIColor.white.withAlphaComponent(0.05).cgColor,
            UIColor.white.withAlphaComponent(0.10).cgColor,
            UIColor.white.withAlphaComponent(0.03).cgColor
        ]
        gradientLayer.locations = [0.0, 0.5, 1.0]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
        
        // Add border glow effect
        let borderLayer = CALayer()
        borderLayer.frame = blurView.bounds
        borderLayer.borderWidth = 1.5
        borderLayer.borderColor = UIColor.white.withAlphaComponent(0.15).cgColor
        borderLayer.cornerRadius = 0
        
        // Add layers to liquid glass view
        vibrantView.layer.addSublayer(gradientLayer)
        liquidGlassView.addSubview(vibrantView)
        liquidGlassView.layer.addSublayer(borderLayer)
        
        blurView.contentView.addSubview(liquidGlassView)
        
        // Add blur view first
        containerView.addSubview(blurView)
        
        // Add the actual view controller's view
        toView.frame = transitionContext.finalFrame(for: toViewController)
        toView.layer.cornerRadius = 20
        toView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        toView.layer.masksToBounds = true
        
        // Add shadow to action sheet for floating effect
        toView.layer.shadowColor = UIColor.black.cgColor
        toView.layer.shadowOffset = CGSize(width: 0, height: -4)
        toView.layer.shadowRadius = 16
        toView.layer.shadowOpacity = 0.15
        
        containerView.addSubview(toView)
        
        // Start with views off screen
        toView.transform = CGAffineTransform(translationX: 0, y: UIScreen.main.bounds.height)
        blurView.alpha = 0
        
        // Animate liquid glass blur effect with multi-stage animation
        UIView.animate(withDuration: duration * 0.4, delay: 0, options: .curveEaseOut, animations: {
            blurView.effect = blurEffect
            blurView.alpha = 0.5
            liquidGlassView.alpha = 0.7
        }, completion: nil)
        
        // Animate sheet presentation
        UIView.animate(withDuration: duration,
                       delay: delay,
                       usingSpringWithDamping: springWithDamping,
                       initialSpringVelocity: springVelocity,
                       options: .curveEaseInOut, animations: {
            toView.transform = CGAffineTransform.identity
            
            // Animate liquid glass properties
            UIView.animate(withDuration: self.duration * 0.6, delay: self.delay * 0.5, options: .curveEaseInOut, animations: {
                vibrantView.backgroundColor = UIColor.white.withAlphaComponent(0.12)
                borderLayer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
            }, completion: nil)
        }) { (finished) in
            transitionContext.completeTransition(finished)
        }
    }
}

open class ActionSheetDismissAnimation: NSObject, UIViewControllerAnimatedTransitioning {
    
    public var duration: TimeInterval = 0.5
    public var delay: TimeInterval = 0.0
    public var blurAlpha: CGFloat = 0.30
    
    open func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return duration
    }
    
    open func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        guard let fromView = transitionContext.view(forKey: UITransitionContextViewKey.from),
              let toView = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to)?.view
        else {
            return
        }
        
        // Find the blur view and liquid glass components
        let containerView = transitionContext.containerView
        let blurView = containerView.subviews.first(where: { $0 is UIVisualEffectView }) as? UIVisualEffectView
        
        // Find liquid glass subviews
        let liquidGlassView = blurView?.contentView.subviews.first
        let vibrantView = liquidGlassView?.subviews.first
        let borderLayer = liquidGlassView?.layer.sublayers?.first(where: { $0.borderWidth > 0 })
        
        UIView.animate(withDuration: duration,
                       delay: delay,
                       options: .curveEaseInOut,
                       animations: {
            // Move sheet down
            fromView.transform = CGAffineTransform(translationX: 0, y: UIScreen.main.bounds.height)
            
            // Fade out liquid glass effect
            blurView?.alpha = 0
            blurView?.effect = nil
            
            // Animate liquid glass components fading
            vibrantView?.alpha = 0
            borderLayer?.borderColor = UIColor.white.withAlphaComponent(0).cgColor
            
        }) { (finished) in
            fromView.transform = CGAffineTransform.identity
            fromView.alpha = 1.0
            
            // Remove blur view and all its subviews
            blurView?.removeFromSuperview()
            
            transitionContext.completeTransition(finished)
        }
    }
}
